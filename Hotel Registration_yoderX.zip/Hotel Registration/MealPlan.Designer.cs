﻿namespace Hotel_Registration
{
    partial class frmMealPlan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpMealPlans = new System.Windows.Forms.GroupBox();
            this.lblMealTotal = new System.Windows.Forms.Label();
            this.lblLabel = new System.Windows.Forms.Label();
            this.grpServiceDinner = new System.Windows.Forms.GroupBox();
            this.cbxTimeD = new System.Windows.Forms.ComboBox();
            this.lblTimeD = new System.Windows.Forms.Label();
            this.rdoDiningD = new System.Windows.Forms.RadioButton();
            this.rdoRoomD = new System.Windows.Forms.RadioButton();
            this.grpServiceLunch = new System.Windows.Forms.GroupBox();
            this.cbxTimeL = new System.Windows.Forms.ComboBox();
            this.TimeL = new System.Windows.Forms.Label();
            this.rdoDiningL = new System.Windows.Forms.RadioButton();
            this.rdoRoomL = new System.Windows.Forms.RadioButton();
            this.grpServiceBreakfast = new System.Windows.Forms.GroupBox();
            this.cbxTimeB = new System.Windows.Forms.ComboBox();
            this.lblTimeB = new System.Windows.Forms.Label();
            this.rdoDiningB = new System.Windows.Forms.RadioButton();
            this.rdoRoomB = new System.Windows.Forms.RadioButton();
            this.chkDinner = new System.Windows.Forms.CheckBox();
            this.chkLunch = new System.Windows.Forms.CheckBox();
            this.chkBreakfast = new System.Windows.Forms.CheckBox();
            this.grpSnacks = new System.Windows.Forms.GroupBox();
            this.rdoNone = new System.Windows.Forms.RadioButton();
            this.rdoBoth = new System.Windows.Forms.RadioButton();
            this.rdoEvening = new System.Windows.Forms.RadioButton();
            this.rdoAfternoon = new System.Windows.Forms.RadioButton();
            this.lblSnakTotal = new System.Windows.Forms.Label();
            this.lblSubLabel = new System.Windows.Forms.Label();
            this.lblLabelGrand = new System.Windows.Forms.Label();
            this.lblGrandTotal = new System.Windows.Forms.Label();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.picFood = new System.Windows.Forms.PictureBox();
            this.btnUncheck = new System.Windows.Forms.Button();
            this.grpMealPlans.SuspendLayout();
            this.grpServiceDinner.SuspendLayout();
            this.grpServiceLunch.SuspendLayout();
            this.grpServiceBreakfast.SuspendLayout();
            this.grpSnacks.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFood)).BeginInit();
            this.SuspendLayout();
            // 
            // grpMealPlans
            // 
            this.grpMealPlans.Controls.Add(this.lblMealTotal);
            this.grpMealPlans.Controls.Add(this.lblLabel);
            this.grpMealPlans.Controls.Add(this.grpServiceDinner);
            this.grpMealPlans.Controls.Add(this.grpServiceLunch);
            this.grpMealPlans.Controls.Add(this.grpServiceBreakfast);
            this.grpMealPlans.Controls.Add(this.chkDinner);
            this.grpMealPlans.Controls.Add(this.chkLunch);
            this.grpMealPlans.Controls.Add(this.chkBreakfast);
            this.grpMealPlans.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpMealPlans.ForeColor = System.Drawing.Color.White;
            this.grpMealPlans.Location = new System.Drawing.Point(1, 12);
            this.grpMealPlans.Name = "grpMealPlans";
            this.grpMealPlans.Size = new System.Drawing.Size(227, 364);
            this.grpMealPlans.TabIndex = 0;
            this.grpMealPlans.TabStop = false;
            this.grpMealPlans.Text = "Select Meals:";
            // 
            // lblMealTotal
            // 
            this.lblMealTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMealTotal.ForeColor = System.Drawing.Color.White;
            this.lblMealTotal.Location = new System.Drawing.Point(72, 337);
            this.lblMealTotal.Name = "lblMealTotal";
            this.lblMealTotal.Size = new System.Drawing.Size(149, 18);
            this.lblMealTotal.TabIndex = 7;
            // 
            // lblLabel
            // 
            this.lblLabel.AutoSize = true;
            this.lblLabel.ForeColor = System.Drawing.Color.White;
            this.lblLabel.Location = new System.Drawing.Point(6, 339);
            this.lblLabel.Name = "lblLabel";
            this.lblLabel.Size = new System.Drawing.Size(60, 16);
            this.lblLabel.TabIndex = 6;
            this.lblLabel.Text = "Subtotal:";
            // 
            // grpServiceDinner
            // 
            this.grpServiceDinner.Controls.Add(this.cbxTimeD);
            this.grpServiceDinner.Controls.Add(this.lblTimeD);
            this.grpServiceDinner.Controls.Add(this.rdoDiningD);
            this.grpServiceDinner.Controls.Add(this.rdoRoomD);
            this.grpServiceDinner.Enabled = false;
            this.grpServiceDinner.ForeColor = System.Drawing.Color.White;
            this.grpServiceDinner.Location = new System.Drawing.Point(6, 256);
            this.grpServiceDinner.Name = "grpServiceDinner";
            this.grpServiceDinner.Size = new System.Drawing.Size(215, 78);
            this.grpServiceDinner.TabIndex = 5;
            this.grpServiceDinner.TabStop = false;
            this.grpServiceDinner.Text = "Service Options";
            // 
            // cbxTimeD
            // 
            this.cbxTimeD.Enabled = false;
            this.cbxTimeD.FormattingEnabled = true;
            this.cbxTimeD.Location = new System.Drawing.Point(54, 47);
            this.cbxTimeD.Name = "cbxTimeD";
            this.cbxTimeD.Size = new System.Drawing.Size(121, 24);
            this.cbxTimeD.TabIndex = 3;
            // 
            // lblTimeD
            // 
            this.lblTimeD.AutoSize = true;
            this.lblTimeD.Location = new System.Drawing.Point(6, 50);
            this.lblTimeD.Name = "lblTimeD";
            this.lblTimeD.Size = new System.Drawing.Size(42, 16);
            this.lblTimeD.TabIndex = 2;
            this.lblTimeD.Text = "Time:";
            // 
            // rdoDiningD
            // 
            this.rdoDiningD.Checked = true;
            this.rdoDiningD.ForeColor = System.Drawing.Color.White;
            this.rdoDiningD.Location = new System.Drawing.Point(116, 21);
            this.rdoDiningD.Name = "rdoDiningD";
            this.rdoDiningD.Size = new System.Drawing.Size(93, 20);
            this.rdoDiningD.TabIndex = 1;
            this.rdoDiningD.TabStop = true;
            this.rdoDiningD.Text = "Dining Hall";
            this.rdoDiningD.UseVisualStyleBackColor = true;
            // 
            // rdoRoomD
            // 
            this.rdoRoomD.AutoSize = true;
            this.rdoRoomD.ForeColor = System.Drawing.Color.White;
            this.rdoRoomD.Location = new System.Drawing.Point(6, 21);
            this.rdoRoomD.Name = "rdoRoomD";
            this.rdoRoomD.Size = new System.Drawing.Size(112, 20);
            this.rdoRoomD.TabIndex = 0;
            this.rdoRoomD.Text = "Room Service";
            this.rdoRoomD.UseVisualStyleBackColor = true;
            this.rdoRoomD.CheckedChanged += new System.EventHandler(this.enableTime);
            // 
            // grpServiceLunch
            // 
            this.grpServiceLunch.Controls.Add(this.cbxTimeL);
            this.grpServiceLunch.Controls.Add(this.TimeL);
            this.grpServiceLunch.Controls.Add(this.rdoDiningL);
            this.grpServiceLunch.Controls.Add(this.rdoRoomL);
            this.grpServiceLunch.Enabled = false;
            this.grpServiceLunch.ForeColor = System.Drawing.Color.White;
            this.grpServiceLunch.Location = new System.Drawing.Point(6, 146);
            this.grpServiceLunch.Name = "grpServiceLunch";
            this.grpServiceLunch.Size = new System.Drawing.Size(215, 78);
            this.grpServiceLunch.TabIndex = 4;
            this.grpServiceLunch.TabStop = false;
            this.grpServiceLunch.Text = "Service Options";
            // 
            // cbxTimeL
            // 
            this.cbxTimeL.Enabled = false;
            this.cbxTimeL.FormattingEnabled = true;
            this.cbxTimeL.Location = new System.Drawing.Point(54, 47);
            this.cbxTimeL.Name = "cbxTimeL";
            this.cbxTimeL.Size = new System.Drawing.Size(121, 24);
            this.cbxTimeL.TabIndex = 3;
            // 
            // TimeL
            // 
            this.TimeL.AutoSize = true;
            this.TimeL.Location = new System.Drawing.Point(6, 50);
            this.TimeL.Name = "TimeL";
            this.TimeL.Size = new System.Drawing.Size(42, 16);
            this.TimeL.TabIndex = 2;
            this.TimeL.Text = "Time:";
            // 
            // rdoDiningL
            // 
            this.rdoDiningL.AutoSize = true;
            this.rdoDiningL.Checked = true;
            this.rdoDiningL.ForeColor = System.Drawing.Color.White;
            this.rdoDiningL.Location = new System.Drawing.Point(116, 21);
            this.rdoDiningL.Name = "rdoDiningL";
            this.rdoDiningL.Size = new System.Drawing.Size(91, 20);
            this.rdoDiningL.TabIndex = 1;
            this.rdoDiningL.TabStop = true;
            this.rdoDiningL.Text = "Dining Hall";
            this.rdoDiningL.UseVisualStyleBackColor = true;
            // 
            // rdoRoomL
            // 
            this.rdoRoomL.AutoSize = true;
            this.rdoRoomL.ForeColor = System.Drawing.Color.White;
            this.rdoRoomL.Location = new System.Drawing.Point(6, 21);
            this.rdoRoomL.Name = "rdoRoomL";
            this.rdoRoomL.Size = new System.Drawing.Size(112, 20);
            this.rdoRoomL.TabIndex = 0;
            this.rdoRoomL.Text = "Room Service";
            this.rdoRoomL.UseVisualStyleBackColor = true;
            this.rdoRoomL.CheckedChanged += new System.EventHandler(this.enableTime);
            // 
            // grpServiceBreakfast
            // 
            this.grpServiceBreakfast.Controls.Add(this.cbxTimeB);
            this.grpServiceBreakfast.Controls.Add(this.lblTimeB);
            this.grpServiceBreakfast.Controls.Add(this.rdoDiningB);
            this.grpServiceBreakfast.Controls.Add(this.rdoRoomB);
            this.grpServiceBreakfast.Enabled = false;
            this.grpServiceBreakfast.ForeColor = System.Drawing.Color.White;
            this.grpServiceBreakfast.Location = new System.Drawing.Point(6, 36);
            this.grpServiceBreakfast.Name = "grpServiceBreakfast";
            this.grpServiceBreakfast.Size = new System.Drawing.Size(215, 78);
            this.grpServiceBreakfast.TabIndex = 3;
            this.grpServiceBreakfast.TabStop = false;
            this.grpServiceBreakfast.Text = "Service Options";
            // 
            // cbxTimeB
            // 
            this.cbxTimeB.Enabled = false;
            this.cbxTimeB.FormattingEnabled = true;
            this.cbxTimeB.Location = new System.Drawing.Point(54, 47);
            this.cbxTimeB.Name = "cbxTimeB";
            this.cbxTimeB.Size = new System.Drawing.Size(121, 24);
            this.cbxTimeB.TabIndex = 3;
            // 
            // lblTimeB
            // 
            this.lblTimeB.AutoSize = true;
            this.lblTimeB.Location = new System.Drawing.Point(6, 50);
            this.lblTimeB.Name = "lblTimeB";
            this.lblTimeB.Size = new System.Drawing.Size(42, 16);
            this.lblTimeB.TabIndex = 2;
            this.lblTimeB.Text = "Time:";
            // 
            // rdoDiningB
            // 
            this.rdoDiningB.AutoSize = true;
            this.rdoDiningB.Checked = true;
            this.rdoDiningB.ForeColor = System.Drawing.Color.White;
            this.rdoDiningB.Location = new System.Drawing.Point(116, 21);
            this.rdoDiningB.Name = "rdoDiningB";
            this.rdoDiningB.Size = new System.Drawing.Size(91, 20);
            this.rdoDiningB.TabIndex = 1;
            this.rdoDiningB.TabStop = true;
            this.rdoDiningB.Text = "Dining Hall";
            this.rdoDiningB.UseVisualStyleBackColor = true;
            // 
            // rdoRoomB
            // 
            this.rdoRoomB.AutoSize = true;
            this.rdoRoomB.ForeColor = System.Drawing.Color.White;
            this.rdoRoomB.Location = new System.Drawing.Point(6, 21);
            this.rdoRoomB.Name = "rdoRoomB";
            this.rdoRoomB.Size = new System.Drawing.Size(112, 20);
            this.rdoRoomB.TabIndex = 0;
            this.rdoRoomB.Text = "Room Service";
            this.rdoRoomB.UseVisualStyleBackColor = true;
            this.rdoRoomB.CheckedChanged += new System.EventHandler(this.enableTime);
            // 
            // chkDinner
            // 
            this.chkDinner.AutoSize = true;
            this.chkDinner.ForeColor = System.Drawing.Color.White;
            this.chkDinner.Location = new System.Drawing.Point(6, 230);
            this.chkDinner.Name = "chkDinner";
            this.chkDinner.Size = new System.Drawing.Size(98, 20);
            this.chkDinner.TabIndex = 2;
            this.chkDinner.Text = "Dinner ($20)";
            this.chkDinner.UseVisualStyleBackColor = true;
            this.chkDinner.CheckedChanged += new System.EventHandler(this.UpdateChckboxInfo);
            // 
            // chkLunch
            // 
            this.chkLunch.AutoSize = true;
            this.chkLunch.ForeColor = System.Drawing.Color.White;
            this.chkLunch.Location = new System.Drawing.Point(6, 120);
            this.chkLunch.Name = "chkLunch";
            this.chkLunch.Size = new System.Drawing.Size(94, 20);
            this.chkLunch.TabIndex = 1;
            this.chkLunch.Text = "Lunch ($15)";
            this.chkLunch.UseVisualStyleBackColor = true;
            this.chkLunch.CheckedChanged += new System.EventHandler(this.UpdateChckboxInfo);
            // 
            // chkBreakfast
            // 
            this.chkBreakfast.AutoSize = true;
            this.chkBreakfast.ForeColor = System.Drawing.Color.White;
            this.chkBreakfast.Location = new System.Drawing.Point(6, 17);
            this.chkBreakfast.Name = "chkBreakfast";
            this.chkBreakfast.Size = new System.Drawing.Size(116, 20);
            this.chkBreakfast.TabIndex = 0;
            this.chkBreakfast.Text = "Breakfast ($10)";
            this.chkBreakfast.UseVisualStyleBackColor = true;
            this.chkBreakfast.CheckedChanged += new System.EventHandler(this.UpdateChckboxInfo);
            // 
            // grpSnacks
            // 
            this.grpSnacks.Controls.Add(this.rdoNone);
            this.grpSnacks.Controls.Add(this.rdoBoth);
            this.grpSnacks.Controls.Add(this.rdoEvening);
            this.grpSnacks.Controls.Add(this.rdoAfternoon);
            this.grpSnacks.Controls.Add(this.lblSnakTotal);
            this.grpSnacks.Controls.Add(this.lblSubLabel);
            this.grpSnacks.ForeColor = System.Drawing.Color.White;
            this.grpSnacks.Location = new System.Drawing.Point(235, 71);
            this.grpSnacks.Name = "grpSnacks";
            this.grpSnacks.Size = new System.Drawing.Size(174, 91);
            this.grpSnacks.TabIndex = 2;
            this.grpSnacks.TabStop = false;
            this.grpSnacks.Text = "Snacks";
            // 
            // rdoNone
            // 
            this.rdoNone.AutoSize = true;
            this.rdoNone.Checked = true;
            this.rdoNone.Location = new System.Drawing.Point(86, 42);
            this.rdoNone.Name = "rdoNone";
            this.rdoNone.Size = new System.Drawing.Size(78, 17);
            this.rdoNone.TabIndex = 8;
            this.rdoNone.TabStop = true;
            this.rdoNone.Text = "No Snacks";
            this.rdoNone.UseVisualStyleBackColor = true;
            this.rdoNone.CheckedChanged += new System.EventHandler(this.updateSnacks);
            // 
            // rdoBoth
            // 
            this.rdoBoth.AutoSize = true;
            this.rdoBoth.Location = new System.Drawing.Point(9, 42);
            this.rdoBoth.Name = "rdoBoth";
            this.rdoBoth.Size = new System.Drawing.Size(47, 17);
            this.rdoBoth.TabIndex = 7;
            this.rdoBoth.Text = "Both";
            this.rdoBoth.UseVisualStyleBackColor = true;
            this.rdoBoth.CheckedChanged += new System.EventHandler(this.updateSnacks);
            // 
            // rdoEvening
            // 
            this.rdoEvening.AutoSize = true;
            this.rdoEvening.Location = new System.Drawing.Point(86, 19);
            this.rdoEvening.Name = "rdoEvening";
            this.rdoEvening.Size = new System.Drawing.Size(64, 17);
            this.rdoEvening.TabIndex = 6;
            this.rdoEvening.Text = "Evening";
            this.rdoEvening.UseVisualStyleBackColor = true;
            this.rdoEvening.CheckedChanged += new System.EventHandler(this.updateSnacks);
            // 
            // rdoAfternoon
            // 
            this.rdoAfternoon.AutoSize = true;
            this.rdoAfternoon.Location = new System.Drawing.Point(9, 19);
            this.rdoAfternoon.Name = "rdoAfternoon";
            this.rdoAfternoon.Size = new System.Drawing.Size(71, 17);
            this.rdoAfternoon.TabIndex = 5;
            this.rdoAfternoon.Text = "Afternoon";
            this.rdoAfternoon.UseVisualStyleBackColor = true;
            this.rdoAfternoon.CheckedChanged += new System.EventHandler(this.updateSnacks);
            // 
            // lblSnakTotal
            // 
            this.lblSnakTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSnakTotal.Location = new System.Drawing.Point(62, 63);
            this.lblSnakTotal.Name = "lblSnakTotal";
            this.lblSnakTotal.Size = new System.Drawing.Size(106, 18);
            this.lblSnakTotal.TabIndex = 4;
            // 
            // lblSubLabel
            // 
            this.lblSubLabel.AutoSize = true;
            this.lblSubLabel.Location = new System.Drawing.Point(7, 64);
            this.lblSubLabel.Name = "lblSubLabel";
            this.lblSubLabel.Size = new System.Drawing.Size(49, 13);
            this.lblSubLabel.TabIndex = 3;
            this.lblSubLabel.Text = "Subtotal:";
            // 
            // lblLabelGrand
            // 
            this.lblLabelGrand.AutoSize = true;
            this.lblLabelGrand.ForeColor = System.Drawing.Color.White;
            this.lblLabelGrand.Location = new System.Drawing.Point(241, 363);
            this.lblLabelGrand.Name = "lblLabelGrand";
            this.lblLabelGrand.Size = new System.Drawing.Size(66, 13);
            this.lblLabelGrand.TabIndex = 4;
            this.lblLabelGrand.Text = "Grand Total:";
            // 
            // lblGrandTotal
            // 
            this.lblGrandTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblGrandTotal.ForeColor = System.Drawing.Color.White;
            this.lblGrandTotal.Location = new System.Drawing.Point(313, 361);
            this.lblGrandTotal.Name = "lblGrandTotal";
            this.lblGrandTotal.Size = new System.Drawing.Size(106, 18);
            this.lblGrandTotal.TabIndex = 5;
            // 
            // picLogo
            // 
            this.picLogo.Image = global::Hotel_Registration.Properties.Resources.HotelLogo;
            this.picLogo.Location = new System.Drawing.Point(228, 13);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(369, 47);
            this.picLogo.TabIndex = 6;
            this.picLogo.TabStop = false;
            // 
            // picFood
            // 
            this.picFood.Location = new System.Drawing.Point(234, 168);
            this.picFood.Name = "picFood";
            this.picFood.Size = new System.Drawing.Size(363, 190);
            this.picFood.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picFood.TabIndex = 3;
            this.picFood.TabStop = false;
            // 
            // btnUncheck
            // 
            this.btnUncheck.Location = new System.Drawing.Point(431, 71);
            this.btnUncheck.Name = "btnUncheck";
            this.btnUncheck.Size = new System.Drawing.Size(158, 91);
            this.btnUncheck.TabIndex = 7;
            this.btnUncheck.Text = "Uncheck All";
            this.btnUncheck.UseVisualStyleBackColor = true;
            this.btnUncheck.Click += new System.EventHandler(this.btnUncheck_Click);
            // 
            // frmMealPlan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(56)))), ((int)(((byte)(101)))));
            this.ClientSize = new System.Drawing.Size(601, 389);
            this.Controls.Add(this.btnUncheck);
            this.Controls.Add(this.picLogo);
            this.Controls.Add(this.lblGrandTotal);
            this.Controls.Add(this.lblLabelGrand);
            this.Controls.Add(this.picFood);
            this.Controls.Add(this.grpSnacks);
            this.Controls.Add(this.grpMealPlans);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmMealPlan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Meal Costs";
            this.Load += new System.EventHandler(this.frmMealPlan_Load);
            this.grpMealPlans.ResumeLayout(false);
            this.grpMealPlans.PerformLayout();
            this.grpServiceDinner.ResumeLayout(false);
            this.grpServiceDinner.PerformLayout();
            this.grpServiceLunch.ResumeLayout(false);
            this.grpServiceLunch.PerformLayout();
            this.grpServiceBreakfast.ResumeLayout(false);
            this.grpServiceBreakfast.PerformLayout();
            this.grpSnacks.ResumeLayout(false);
            this.grpSnacks.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFood)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpMealPlans;
        private System.Windows.Forms.Label lblMealTotal;
        private System.Windows.Forms.Label lblLabel;
        private System.Windows.Forms.GroupBox grpServiceDinner;
        private System.Windows.Forms.ComboBox cbxTimeD;
        private System.Windows.Forms.Label lblTimeD;
        private System.Windows.Forms.RadioButton rdoDiningD;
        private System.Windows.Forms.RadioButton rdoRoomD;
        private System.Windows.Forms.GroupBox grpServiceLunch;
        private System.Windows.Forms.ComboBox cbxTimeL;
        private System.Windows.Forms.Label TimeL;
        private System.Windows.Forms.RadioButton rdoDiningL;
        private System.Windows.Forms.RadioButton rdoRoomL;
        private System.Windows.Forms.GroupBox grpServiceBreakfast;
        private System.Windows.Forms.ComboBox cbxTimeB;
        private System.Windows.Forms.Label lblTimeB;
        private System.Windows.Forms.RadioButton rdoDiningB;
        private System.Windows.Forms.RadioButton rdoRoomB;
        private System.Windows.Forms.CheckBox chkDinner;
        private System.Windows.Forms.CheckBox chkLunch;
        private System.Windows.Forms.CheckBox chkBreakfast;
        private System.Windows.Forms.GroupBox grpSnacks;
        private System.Windows.Forms.RadioButton rdoBoth;
        private System.Windows.Forms.RadioButton rdoEvening;
        private System.Windows.Forms.RadioButton rdoAfternoon;
        private System.Windows.Forms.Label lblSnakTotal;
        private System.Windows.Forms.Label lblSubLabel;
        private System.Windows.Forms.Label lblLabelGrand;
        private System.Windows.Forms.Label lblGrandTotal;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.PictureBox picFood;
        private System.Windows.Forms.Button btnUncheck;
        private System.Windows.Forms.RadioButton rdoNone;
    }
}