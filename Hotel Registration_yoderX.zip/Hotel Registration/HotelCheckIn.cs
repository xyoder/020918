﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotel_Registration
{
    /*Notes for future release
     * messagebox and better validating/restrictions for pay bill form
     * clean up and streamline code for extras
     * display costs on pay bill form
     */
    public partial class HotelCheckIn : Form
    {

        //Name: Xavier Yoder
        //Date: 11/18/2019

        //create global variables
        string clientFirstName, clientLastName, clientAddress, clientState, clientZipCode, clientPhone;
        decimal roomRate, memberDiscount, mealTotal, extraCosts, subTotal;
        int daysForStay;


        private void cbxState_Leave(object sender, EventArgs e)
        {
            //sets the client's info for state when they leave the combobox
            clientState = cbxState.SelectedItem.ToString();
        }

        private void mtxZipCode_Leave(object sender, EventArgs e)
        {
            //sets the client's info for zip code when they leave the masked textbox
            clientZipCode = mtxZipCode.Text;
        }

        private void btnPayBill_Click(object sender, EventArgs e)
        {
            //Open the pay bill form
            frmPay payForm = new frmPay();
            payForm.Show();
        }

        private decimal calculateDiscountTotals(decimal subCost)
        {
            //returns the amount of the client's discount
            return (subCost * memberDiscount);
        }   

        private void UpdateMeal(decimal meals)
        {
            //method to receive the meal total
            mealTotal = meals;

            //update total with the meal total
            updateAmountDue();
        }

        private void UpdateExtras(decimal extras)
        {
            //method to receive the extra total
            extraCosts = extras;

            //Update total with extras total
            updateAmountDue();
        }

        private void updateAmountDue()
        {
            //method that updates the output labels based on the user's input
            subTotal = ((roomRate * daysForStay) + mealTotal + extraCosts);
            lblAmtDays.Text = daysForStay.ToString();
            lblAmtRoomRate.Text = roomRate.ToString("C2");
            lblAmtDiscountRate.Text = calculatePercent();
            lblAmtMeal.Text = mealTotal.ToString("C2");
            lblAmtExtra.Text = extraCosts.ToString("C2");
            lblAmtDiscount.Text = calculateDiscountTotals(subTotal).ToString("C2");
            lblAmtDue.Text = (subTotal - calculateDiscountTotals(subTotal)).ToString("C2");
        }
        
        private string calculatePercent()
        {
            //if structure that determines and show the client's discount rate based on their type of membership
            if (memberDiscount == 0)
                return "0%";
            else if (memberDiscount == .2m)
                return "20%";
            else
                return "30%";
        }

        private void rdbSingleBed_CheckedChanged(object sender, EventArgs e)
        {
            //updates the room rate for single bed
            roomRate = 100;
            updateAmountDue();
        }

        private void rdbDouble_CheckedChanged(object sender, EventArgs e)
        {
            //updates the room rate for double bed
            roomRate = 150;
            updateAmountDue();
        }

        private void rdbQueen_CheckedChanged(object sender, EventArgs e)
        {
            //updates the room rate for queen bed
            roomRate = 200;
            updateAmountDue();
        }

        private void btnMeal_Click(object sender, EventArgs e)
        {
            //Open the meal plan form
            frmMealPlan mealForm = new frmMealPlan();

            //set location to the right
            mealForm.StartPosition = FormStartPosition.Manual;
            mealForm.Location = new Point(this.Location.X + 690, this.Location.Y);

            //create delegate trigger 
            mealForm.SendMeals += UpdateMeal;
            
            //show the meal form
            mealForm.Show();
        }

        private void btnExtra_Click(object sender, EventArgs e)
        {
            //Open the extras form
            frmExtras extraCosts = new frmExtras();

            //set form to the left
            extraCosts.StartPosition = FormStartPosition.Manual;
            extraCosts.Location = new Point(this.Location.X - 526, this.Location.Y);

            //create delegate trigger
            extraCosts.SendExtras += UpdateExtras;

            //show the form
            extraCosts.Show();
        }

        private void rdbKing_CheckedChanged(object sender, EventArgs e)
        {
            //updates the room rate for king bed
            roomRate = 250;
            updateAmountDue();
        }

        private void cbxDays_SelectedIndexChanged(object sender, EventArgs e)
        {
            //what index is selected, then determine number of days
            if (cbxDays.SelectedIndex >= 0 && cbxDays.SelectedIndex <= 5)
                daysForStay = int.Parse(cbxDays.SelectedItem.ToString());
            else if (cbxDays.SelectedIndex == 6)
                daysForStay = 7;
            else if (cbxDays.SelectedIndex == 7)
                daysForStay = 14;
            else if (cbxDays.SelectedIndex == 8)
                daysForStay = 21;
            else
                daysForStay = 30;
            updateAmountDue();
            //check routine (errpr checking should be commented out once in production
            //MessageBox.Show($"{daysForStay}");
        }

        //modularization for setting the discount amount
        private void SetMembershipDiscount(object sender, EventArgs e)
        {
            //create a radio button variabel to determine which radio button is checked
            RadioButton whichRadio = (RadioButton)sender;

            //determines and updates the discount amount based on which 
            switch (whichRadio.Name)
            {
                case "rdbNoneMember":
                    memberDiscount = 0;
                    break;
                case "rdbGoldMember":
                    memberDiscount = .2m;
                    break;
                case "rdbPlatinumMember":
                    memberDiscount = .3m;
                    break;
            }
            updateAmountDue();
        }

        private void mtxPhone_Leave(object sender, EventArgs e)
        {
            //sets the client's info for phone number when they leave the masked textbox
            clientPhone = mtxPhone.Text;
        }

        private void txtAddress_Leave(object sender, EventArgs e)
        {
            //sets the client's info for address when they leave the masked textbox
            clientAddress = txtAddress.Text;
        }

        private void txtLastName_Leave(object sender, EventArgs e)
        {
            //sets the client's info for last name when they leave the textbox
            clientLastName = txtLastName.Text;
        }

        private void txtFirstName_Leave(object sender, EventArgs e)
        {
            //sets the client's info for first name when they leave the textbox
            clientFirstName = txtFirstName.Text;
        }

        public HotelCheckIn()
        {
            InitializeComponent();
        }

        private void SetDefaults()
        {
            //Load items into the state combobox
            cbxState.Items.Add("IN");
            cbxState.Items.Add("OH");
            cbxState.Items.Add("MI");
            cbxState.SelectedIndex = 0;

            //set program defaults
            roomRate = 100m;
            rdbSingleBed.Checked = true;

            //set discount default
            memberDiscount = 0m;
            rdbNoneMember.Checked = true;

            //Load days options
            cbxDays.Items.Add("1");
            cbxDays.Items.Add("2");
            cbxDays.Items.Add("3");
            cbxDays.Items.Add("4");
            cbxDays.Items.Add("5");
            cbxDays.Items.Add("6");
            cbxDays.Items.Add("1 week");
            cbxDays.Items.Add("2 weeks");
            cbxDays.Items.Add("3 weeks");
            cbxDays.Items.Add("1 month");

            cbxDays.SelectedIndex = 0;

            //set total cost labels
            lblAmtDays.Text = "1";
            lblAmtRoomRate.Text = (100).ToString("C2");
            lblAmtDiscountRate.Text = "0%";
            lblAmtMeal.Text = (0).ToString("C2");
            lblAmtExtra.Text = (0).ToString("C2");
            lblAmtDiscount.Text = (0).ToString("C2");
            lblAmtDue.Text = (100).ToString("C2");
        }

        private void HotelCheckIn_Load(object sender, EventArgs e)
        {
            //loads in and sets defaults
            SetDefaults();
        }
    }
}
