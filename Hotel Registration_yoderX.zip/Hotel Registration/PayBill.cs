﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotel_Registration
{
    public partial class frmPay : Form
    {
        //Name: Xavier Yoder
        //Date: 11/19/2019
        public frmPay()
        {
            InitializeComponent();
        }

        private void PaymentMehtodChoice(object sender, EventArgs e)
        {
            //this is the easy part
            //check whether the user selected cash or credit and enable the next option
            if (rdoCash.Checked == true)
                btnPay.Enabled = true;
            else if (rdoCredit.Checked == true)
            {
                grpCreditInfo.Enabled = true;
            }
        }

        private void JustMakeSureTheClientHasStuffInTheseFields(object sender, CancelEventArgs e)
        {
            //don't know how to validate that the masked textboxes are filled 
            //if the user puts in some data for all fields open the pay button. i don't know how to make sure the fields are full
           // if (mtxNumber.Text != "" && mtxCV.Text != "" && cbxType.Text != "")
              //  btnPay.Enabled = true;
        }

        private void BtnPay_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmPay_Load(object sender, EventArgs e)
        {
            //set default for combobox
            cbxType.SelectedIndex = 0;
        }
    }
}
