﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotel_Registration
{
    public partial class frmExtras : Form
    {
        //Name: Xavier Yoder
        //Date: 11/18/2019


        //setup delegate
        public delegate void ExtrasUpdate(decimal extraCosts);
        public ExtrasUpdate SendExtras;

        //gloabal variable declaration
        decimal roomsSub = 0, outSub = 0, grandTotal = 0, console = 0, tickets = 0, daycareSub = 0, ticketSub;
       
        private void UpdateCostForRoomExtras(object sender, EventArgs e)
        {
            //create a checkbox variable to check and add or subtract the total for room extras
            CheckBox chk2Check = (CheckBox)sender;

            //switch statement that upadtes totals for room extras and enables any neccessary group boxes
            //within the switch cases there are if structures to determine whether to add or subtract from the total bease don if the box is checked or unchecked
            switch(chk2Check.Name)
            {
                case "chkMiniBar":
                    if (chkMiniBar.Checked == true)
                        roomsSub += 10m;
                    else
                        roomsSub -= 10m;
                    break;
                case "chkStreaming":
                    if (chkStreaming.Checked == true)
                        roomsSub += 5m;
                    else
                        roomsSub -= 5m;
                    break;
                case "chkSafe":
                    if (chkSafe.Checked == true)
                        roomsSub += 15;
                    else
                        roomsSub -= 15;
                    break;
                case "chkRobe":
                    if (chkRobe.Checked == true)
                        roomsSub += 3;
                    else
                        roomsSub -= 3;
                    break;
                case "chkRoomChoice":
                    if (chkRoomChoice.Checked == true)
                        roomsSub += 30;
                    else
                        roomsSub -= 30;
                    break;
                case "chkShare":
                    if (chkShare.Checked == true)
                    {
                        MessageBox.Show("Wow! You must be pretty brave!");
                        roomsSub += 50;
                    }
                    else
                        roomsSub -= 50;
                    break;
                case "chkConsole":
                    if (chkConsole.Checked == true)
                    {
                        cbxConsole.Enabled = true;
                        cbxConsole.SelectedIndex = 0;
                    }
                    else
                    {
                        cbxConsole.Enabled = false;
                        roomsSub -= console;
                    }
                    break;
                case "chkButler":
                    if (chkButler.Checked == true)
                        roomsSub += 35;
                    else
                        roomsSub -= 35;
                    break;
                case "chkInternet":
                    if (chkInternet.Checked == true)
                        roomsSub += 5;
                    else
                        roomsSub -= 5;
                    break;
                case "chkStudy":
                    if (chkStudy.Checked == true)
                        roomsSub += 2;
                    else
                        roomsSub -= 2;
                    break;
            }

            //update the totals at the end
            UpdateTotals();
        }

        public frmExtras()
        {
            InitializeComponent();
        }

        private void MtxTicketAmount_TextChanged(object sender, EventArgs e)
        {
            //set up an if structure to prevent the program from crashing if the client deltes their text
            //then go through and receive the amount of tickets requested
            if (mtxTicketAmount.Text == "" || mtxTicketAmount.Text == " " || mtxTicketAmount.Text == "  ")
                tickets = 0;
            else
            {
                tickets = decimal.Parse(mtxTicketAmount.Text);
            }

            //calculate the ticket costs
            ticketSub = tickets * 2;

            //update the totals
            UpdateTotals();

            //reset ticket amount
            tickets = 0;
        }

        private void UpdateDaycare(object sender, EventArgs e)
        {
            //if structure that determines the price for daycare based on which radio button is checked
            if (rdoMorning.Checked == true)
                daycareSub = 15;
            else if (rdoAfternoon.Checked == true)
                daycareSub = 20;
            else if (rdoEvening.Checked == true)
                daycareSub = 25;
            else
                daycareSub = 0;

            //update the totals
            UpdateTotals();
        }

        private void UpdateOutings(object sender, EventArgs e)
        {
            //create a checkbox variable to check and add or subtract the total for outing extras
            CheckBox chk2Check = (CheckBox)sender;

            //switch statement that upadtes totals for outing extras and enables any neccessary group boxes
            //within the switch cases there are if structures to determine whether to add or subtract from the total bease don if the box is checked or unchecked
            switch (chk2Check.Name)
            {
                case "chkTrainerAndGym":
                    if (chkTrainerAndGym.Checked == true)
                        outSub += 45;
                    else
                        outSub -= 45;
                    break;
                case "chkHelicopter":
                    if (chkHelicopter.Checked == true)
                        outSub += 150;
                    else
                        outSub -= 150;
                    break;
                case "chkTour":
                    if (chkTour.Checked == true)
                        outSub += .01m;
                    else
                        outSub -= .01m;
                    break;
                case "chkBoatRide":
                    if (chkBoatRide.Checked == true)
                        outSub += 10;
                    else
                        outSub -= 10;
                    break;
                case "chkDaycare":
                    if (chkDaycare.Checked == true)
                        //enable the services groupbox code for those checkboxes will be a part of a different method
                        grpServices.Enabled = true;
                    else
                        //disable the services groupboxes
                        grpServices.Enabled = false;
                    break;
                case "chkPool":
                    if (chkPool.Checked == true)
                        outSub += 5;
                    else
                        outSub -= 5;
                    break;
                case "chkTickets":
                    if (chkTickets.Checked == true)
                        //same as the daycare but for tickets
                        grpAmountOfTickets.Enabled = true;
                    else
                    {
                        grpAmountOfTickets.Enabled = false;
                       
                        //clears the amount due for tickets for the client
                        mtxTicketAmount.Text = "0";
                    }
                    break;
                case "chkWaterPark":
                    if (chkWaterPark.Checked == true)
                        outSub += 10;
                    else
                        outSub -= 10;
                    break;
            }

            //update the totals
            UpdateTotals();
        }


        private void CbxConsole_SelectedIndexChanged(object sender, EventArgs e)
        {
            //update the cost depending on which console is selected and add to the room extras subtotal
            if (cbxConsole.SelectedIndex == 0)
            {
                //this code is used to "reset the rooms extras cost when switching console
                roomsSub -= console;

                console = 25;
                roomsSub += console;
            }
            else if (cbxConsole.SelectedIndex == 1)
            {
                roomsSub -= console;
                console = 35;
                roomsSub += console;
            }
            else if (cbxConsole.SelectedIndex == 2)
            {
                roomsSub -= console;
                console = 40;
                roomsSub += console;
            }
            else
            {
                roomsSub -= console;
                console = 30;
                roomsSub += console;
            }

            UpdateTotals();
        }

       
        private void UpdateTotals()
        {
            //add the ticket and daycare cost to the outSub
            outSub += daycareSub + ticketSub;

            //display the subtotals for room extras and outing extras
            lblroomTotal.Text = roomsSub.ToString("C2");
            lblOutingTotal.Text = outSub.ToString("C2");

            //calculate and display total for extras
            grandTotal = roomsSub + outSub;
            lblExtrasTotal.Text = grandTotal.ToString("C2");

            //call delegate
            SendExtras(grandTotal);

            //reset the outSub for changes in daycare and ticket amounts
            outSub -= daycareSub;
            outSub -= ticketSub;
        }

        private void BtnUncheck_Click(object sender, EventArgs e)
        {
            //uncheck all the checkboxes
            chkBoatRide.Checked = chkButler.Checked = chkConsole.Checked = chkDaycare.Checked = chkHelicopter.Checked = chkInternet.Checked = chkMiniBar.Checked
                = chkRobe.Checked = chkRoomChoice.Checked = chkSafe.Checked = chkShare.Checked = chkStreaming.Checked = chkStudy.Checked =rdoAfternoon.Checked = rdoEvening.Checked = rdoMorning.Checked 
                = chkTour.Checked = chkTrainerAndGym.Checked = chkWaterPark.Checked = chkPool.Checked = chkTickets.Checked = false;
        }
    }
}
