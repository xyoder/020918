﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotel_Registration
{
    public partial class frmMealPlan : Form
    {
        //Name: Xavier Yoder
        //Date: 11/18/2109

        //setup delegate
        public delegate void MealUpdate(decimal mealTotal);
        public MealUpdate SendMeals;
        
        //gloabal variable declaration
        decimal mealSub = 0, snackSub = 0, grandTotal = 0;
        

        public frmMealPlan()
        {
            InitializeComponent();
        }

        private void LoadTimes(ComboBox cbx2Load, char mealType)
        {
            //create variabels for start and end times for room service
            DateTime startTime;
            DateTime endTime;
            //Define Start Time based on Meal Type
            switch (mealType)
            {
                case 'B':
                    startTime = DateTime.Parse("06:00 AM");
                    endTime = DateTime.Parse("11:00 AM");
                    break;
                case 'L':
                    startTime = DateTime.Parse("11:00 AM");
                    endTime = DateTime.Parse("05:00 PM");
                    break;
                default:
                    startTime = DateTime.Parse("05:00 PM");
                    endTime = DateTime.Parse("11:30 PM");
                    break;
            }

            //load in the reaming times for each meal type
            while (startTime != endTime)
            {
                cbx2Load.Items.Add(startTime.ToString("h:mm tt"));

                //Add 30 Mintues
                startTime = startTime.AddMinutes(30);
            }

            //selects the first time as the default
            cbx2Load.SelectedIndex = 0;
        }

        private void frmMealPlan_Load(object sender, EventArgs e)
        {
            //loads in the times for room service for each meal type
            LoadTimes(cbxTimeB, 'B');
            LoadTimes(cbxTimeL, 'L');
            LoadTimes(cbxTimeD, 'D');

            //updates the totals
            updateTotals();
        }

        private void UpdateChckboxInfo(object sender, EventArgs e)
        {
            //create a checkbox variabel to check and determine meal prices
            CheckBox chkClicked = (CheckBox)sender;

            /*switch statement that checks which meal checkbox is select 
             * also displays a picture of whichever meal is sleceted and removes the picture if a checkbox is unselected
             * also enables and disables the groupbox for the client to select dining hall or rome service for the checkbox the client selects and unselects respectively
             * lastly: updates the meals subtotal
             */
            switch (chkClicked.Name)
            {
                case "chkBreakfast":
                    picFood.Image = Hotel_Registration.Properties.Resources.Breakfast;
                    if (grpServiceBreakfast.Enabled == false)
                    {
                        grpServiceBreakfast.Enabled = true;
                        mealSub += 10;
                    }
                    else
                    {
                        picFood.Image = null;
                        grpServiceBreakfast.Enabled = false;
                        mealSub -= 10;
                        if (rdoRoomB.Checked == true)
                            mealSub -= 3.5M;
                    }
                    break;
                case "chkLunch":
                    picFood.Image = Hotel_Registration.Properties.Resources.Lunch;
                    if (grpServiceLunch.Enabled == false)
                    {
                        grpServiceLunch.Enabled = true;
                        mealSub += 15;
                    }
                    else
                    {
                        grpServiceLunch.Enabled = false;
                        picFood.Image = null;
                        mealSub -= 15;
                        if (rdoRoomL.Checked == true)
                            mealSub -= 3.5M;
                    }
                    break;
                default:
                    picFood.Image = Hotel_Registration.Properties.Resources.Dinner;
                    if (grpServiceDinner.Enabled == false)
                    {
                        grpServiceDinner.Enabled = true;
                        mealSub += 20;
                    }
                    else
                    {
                        grpServiceDinner.Enabled = false;
                        picFood.Image = null;
                        mealSub -= 20;
                        if (rdoRoomD.Checked == true)
                            mealSub -= 3.5M;
                    }
                    break;
            }

            //updates the totals
            updateTotals();
        }

        private void enableTime(object sender, EventArgs e)
        {
            //create a radio button variable to check and determine room service prices
            RadioButton rdoChecked = (RadioButton)sender;

            //swtich statement that enables the time comboboxes when the room service radio button is selected and the oppposite. 
            //Also adds or subtracts from total when the client changes the checked status of the radio buttons
            switch (rdoChecked.Name)
            {
                case "rdoRoomB":
                    if (rdoRoomB.Checked == false)
                    {
                        cbxTimeB.Enabled = false;
                        mealSub -= 3.5M;
                    }
                    else
                    {
                        cbxTimeB.Enabled = true;
                        mealSub += 3.5M;
                    }
                    break;
                case "rdoRoomL":
                    if (rdoRoomL.Checked == false)
                    {
                        cbxTimeL.Enabled = false;
                        mealSub -= 3.5M;
                    }
                    else
                    {
                        cbxTimeL.Enabled = true;
                        mealSub += 3.5M;
                    }
                    break;
                default:
                    if (rdoRoomD.Checked == false)
                    {
                        cbxTimeD.Enabled = false;
                        mealSub -= 3.5M;
                    }
                    else
                    {
                        cbxTimeD.Enabled = true;
                        mealSub += 3.5M;
                    }
                    break;
            }

            //updates the totals
            updateTotals();
        }

        private void updateSnacks(object sender, EventArgs e)
        {
            //if structure that determines the price for snacks based on which radio button is checked
            if (rdoAfternoon.Checked == true)
                snackSub = 2;
            else if (rdoEvening.Checked == true)
                snackSub = 2;
            else if (rdoBoth.Checked == true)
                snackSub = 3;
            else
                snackSub = 0;

            //update the totals
            updateTotals();
        }

        private void btnUncheck_Click(object sender, EventArgs e)
        {
            //Uncheck and reset times, checkboxes, and radiobuttons
            chkBreakfast.Checked = chkDinner.Checked = chkLunch.Checked = rdoAfternoon.Checked = rdoBoth.Checked =
                rdoEvening.Checked = rdoRoomB.Checked = rdoRoomD.Checked = rdoRoomL.Checked 
                = false;
            rdoDiningB.Checked = rdoDiningD.Checked = rdoDiningL.Checked = rdoNone.Checked = true;
            LoadTimes(cbxTimeB, 'B');
            LoadTimes(cbxTimeL, 'L');
            LoadTimes(cbxTimeD, 'D');
        }

        private void updateTotals()
        {
            //display the meal and snack subtotals
            lblMealTotal.Text = mealSub.ToString("C2");
            lblSnakTotal.Text = snackSub.ToString("C2");

            //calculate and display the grand total for meals
            grandTotal = mealSub + snackSub;
            lblGrandTotal.Text = grandTotal.ToString("C2");

            //Call delegate
            SendMeals(grandTotal);
        }
    }
}
