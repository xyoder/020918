﻿namespace Hotel_Registration
{
    partial class frmPay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.grpPaymentMethod = new System.Windows.Forms.GroupBox();
            this.grpCreditInfo = new System.Windows.Forms.GroupBox();
            this.mtxCV = new System.Windows.Forms.MaskedTextBox();
            this.mtxNumber = new System.Windows.Forms.MaskedTextBox();
            this.lblCV = new System.Windows.Forms.Label();
            this.lblNumber = new System.Windows.Forms.Label();
            this.lblType = new System.Windows.Forms.Label();
            this.cbxType = new System.Windows.Forms.ComboBox();
            this.rdoCredit = new System.Windows.Forms.RadioButton();
            this.rdoCash = new System.Windows.Forms.RadioButton();
            this.btnPay = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.grpPaymentMethod.SuspendLayout();
            this.grpCreditInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // picLogo
            // 
            this.picLogo.Image = global::Hotel_Registration.Properties.Resources.HotelLogo;
            this.picLogo.Location = new System.Drawing.Point(8, 8);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(189, 47);
            this.picLogo.TabIndex = 8;
            this.picLogo.TabStop = false;
            // 
            // grpPaymentMethod
            // 
            this.grpPaymentMethod.Controls.Add(this.grpCreditInfo);
            this.grpPaymentMethod.Controls.Add(this.rdoCredit);
            this.grpPaymentMethod.Controls.Add(this.rdoCash);
            this.grpPaymentMethod.ForeColor = System.Drawing.Color.White;
            this.grpPaymentMethod.Location = new System.Drawing.Point(8, 59);
            this.grpPaymentMethod.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grpPaymentMethod.Name = "grpPaymentMethod";
            this.grpPaymentMethod.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grpPaymentMethod.Size = new System.Drawing.Size(227, 164);
            this.grpPaymentMethod.TabIndex = 9;
            this.grpPaymentMethod.TabStop = false;
            this.grpPaymentMethod.Text = "Payment Method";
            // 
            // grpCreditInfo
            // 
            this.grpCreditInfo.Controls.Add(this.mtxCV);
            this.grpCreditInfo.Controls.Add(this.mtxNumber);
            this.grpCreditInfo.Controls.Add(this.lblCV);
            this.grpCreditInfo.Controls.Add(this.lblNumber);
            this.grpCreditInfo.Controls.Add(this.lblType);
            this.grpCreditInfo.Controls.Add(this.cbxType);
            this.grpCreditInfo.Enabled = false;
            this.grpCreditInfo.ForeColor = System.Drawing.Color.White;
            this.grpCreditInfo.Location = new System.Drawing.Point(18, 64);
            this.grpCreditInfo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grpCreditInfo.Name = "grpCreditInfo";
            this.grpCreditInfo.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grpCreditInfo.Size = new System.Drawing.Size(200, 90);
            this.grpCreditInfo.TabIndex = 2;
            this.grpCreditInfo.TabStop = false;
            this.grpCreditInfo.Text = "Credit Card Info";
            // 
            // mtxCV
            // 
            this.mtxCV.Location = new System.Drawing.Point(79, 65);
            this.mtxCV.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.mtxCV.Mask = "###";
            this.mtxCV.Name = "mtxCV";
            this.mtxCV.Size = new System.Drawing.Size(114, 20);
            this.mtxCV.TabIndex = 5;
            // 
            // mtxNumber
            // 
            this.mtxNumber.Location = new System.Drawing.Point(79, 44);
            this.mtxNumber.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.mtxNumber.Mask = "#### #### #### ####";
            this.mtxNumber.Name = "mtxNumber";
            this.mtxNumber.Size = new System.Drawing.Size(114, 20);
            this.mtxNumber.TabIndex = 4;
            // 
            // lblCV
            // 
            this.lblCV.AutoSize = true;
            this.lblCV.Location = new System.Drawing.Point(12, 67);
            this.lblCV.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCV.Name = "lblCV";
            this.lblCV.Size = new System.Drawing.Size(64, 13);
            this.lblCV.TabIndex = 3;
            this.lblCV.Text = "CV Number:";
            // 
            // lblNumber
            // 
            this.lblNumber.AutoSize = true;
            this.lblNumber.Location = new System.Drawing.Point(3, 45);
            this.lblNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNumber.Name = "lblNumber";
            this.lblNumber.Size = new System.Drawing.Size(72, 13);
            this.lblNumber.TabIndex = 2;
            this.lblNumber.Text = "Card Number:";
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(17, 23);
            this.lblType.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(59, 13);
            this.lblType.TabIndex = 1;
            this.lblType.Text = "Card Type:";
            // 
            // cbxType
            // 
            this.cbxType.FormattingEnabled = true;
            this.cbxType.Items.AddRange(new object[] {
            "Visa",
            "MasterCard",
            "Discover",
            "American Express"});
            this.cbxType.Location = new System.Drawing.Point(79, 21);
            this.cbxType.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cbxType.Name = "cbxType";
            this.cbxType.Size = new System.Drawing.Size(114, 21);
            this.cbxType.TabIndex = 0;
            this.cbxType.Validating += new System.ComponentModel.CancelEventHandler(this.JustMakeSureTheClientHasStuffInTheseFields);
            // 
            // rdoCredit
            // 
            this.rdoCredit.AutoSize = true;
            this.rdoCredit.Location = new System.Drawing.Point(18, 46);
            this.rdoCredit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rdoCredit.Name = "rdoCredit";
            this.rdoCredit.Size = new System.Drawing.Size(77, 17);
            this.rdoCredit.TabIndex = 1;
            this.rdoCredit.TabStop = true;
            this.rdoCredit.Text = "Credit Card";
            this.rdoCredit.UseVisualStyleBackColor = true;
            // 
            // rdoCash
            // 
            this.rdoCash.AutoSize = true;
            this.rdoCash.Location = new System.Drawing.Point(18, 28);
            this.rdoCash.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rdoCash.Name = "rdoCash";
            this.rdoCash.Size = new System.Drawing.Size(49, 17);
            this.rdoCash.TabIndex = 0;
            this.rdoCash.TabStop = true;
            this.rdoCash.Text = "Cash";
            this.rdoCash.UseVisualStyleBackColor = true;
            this.rdoCash.CheckedChanged += new System.EventHandler(this.PaymentMehtodChoice);
            // 
            // btnPay
            // 
            this.btnPay.Enabled = false;
            this.btnPay.Location = new System.Drawing.Point(62, 226);
            this.btnPay.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnPay.Name = "btnPay";
            this.btnPay.Size = new System.Drawing.Size(108, 37);
            this.btnPay.TabIndex = 10;
            this.btnPay.Text = "Pay";
            this.btnPay.UseVisualStyleBackColor = true;
            this.btnPay.Click += new System.EventHandler(this.BtnPay_Click);
            // 
            // frmPay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(56)))), ((int)(((byte)(101)))));
            this.ClientSize = new System.Drawing.Size(242, 269);
            this.Controls.Add(this.btnPay);
            this.Controls.Add(this.grpPaymentMethod);
            this.Controls.Add(this.picLogo);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmPay";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pay Bill";
            this.Load += new System.EventHandler(this.frmPay_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.grpPaymentMethod.ResumeLayout(false);
            this.grpPaymentMethod.PerformLayout();
            this.grpCreditInfo.ResumeLayout(false);
            this.grpCreditInfo.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.GroupBox grpPaymentMethod;
        private System.Windows.Forms.GroupBox grpCreditInfo;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.ComboBox cbxType;
        private System.Windows.Forms.RadioButton rdoCredit;
        private System.Windows.Forms.RadioButton rdoCash;
        private System.Windows.Forms.MaskedTextBox mtxCV;
        private System.Windows.Forms.MaskedTextBox mtxNumber;
        private System.Windows.Forms.Label lblCV;
        private System.Windows.Forms.Label lblNumber;
        private System.Windows.Forms.Button btnPay;
    }
}