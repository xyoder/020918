﻿namespace Hotel_Registration
{
    partial class frmExtras
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.grpRoomExtras = new System.Windows.Forms.GroupBox();
            this.lblroomTotal = new System.Windows.Forms.Label();
            this.lblLabel3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbxConsole = new System.Windows.Forms.ComboBox();
            this.chkStudy = new System.Windows.Forms.CheckBox();
            this.chkInternet = new System.Windows.Forms.CheckBox();
            this.chkButler = new System.Windows.Forms.CheckBox();
            this.chkConsole = new System.Windows.Forms.CheckBox();
            this.chkShare = new System.Windows.Forms.CheckBox();
            this.chkRoomChoice = new System.Windows.Forms.CheckBox();
            this.chkRobe = new System.Windows.Forms.CheckBox();
            this.chkSafe = new System.Windows.Forms.CheckBox();
            this.chkStreaming = new System.Windows.Forms.CheckBox();
            this.chkMiniBar = new System.Windows.Forms.CheckBox();
            this.grpOutingExtras = new System.Windows.Forms.GroupBox();
            this.lblOutingTotal = new System.Windows.Forms.Label();
            this.lblLabel2 = new System.Windows.Forms.Label();
            this.grpAmountOfTickets = new System.Windows.Forms.GroupBox();
            this.mtxTicketAmount = new System.Windows.Forms.MaskedTextBox();
            this.grpServices = new System.Windows.Forms.GroupBox();
            this.chkWaterPark = new System.Windows.Forms.CheckBox();
            this.chkTickets = new System.Windows.Forms.CheckBox();
            this.chkPool = new System.Windows.Forms.CheckBox();
            this.chkDaycare = new System.Windows.Forms.CheckBox();
            this.chkBoatRide = new System.Windows.Forms.CheckBox();
            this.chkTour = new System.Windows.Forms.CheckBox();
            this.chkHelicopter = new System.Windows.Forms.CheckBox();
            this.chkTrainerAndGym = new System.Windows.Forms.CheckBox();
            this.btnUncheck = new System.Windows.Forms.Button();
            this.lblLabel = new System.Windows.Forms.Label();
            this.lblExtrasTotal = new System.Windows.Forms.Label();
            this.rdoMorning = new System.Windows.Forms.RadioButton();
            this.rdoAfternoon = new System.Windows.Forms.RadioButton();
            this.rdoEvening = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.grpRoomExtras.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grpOutingExtras.SuspendLayout();
            this.grpAmountOfTickets.SuspendLayout();
            this.grpServices.SuspendLayout();
            this.SuspendLayout();
            // 
            // picLogo
            // 
            this.picLogo.Image = global::Hotel_Registration.Properties.Resources.HotelLogo;
            this.picLogo.Location = new System.Drawing.Point(24, 23);
            this.picLogo.Margin = new System.Windows.Forms.Padding(6);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(738, 90);
            this.picLogo.TabIndex = 7;
            this.picLogo.TabStop = false;
            // 
            // grpRoomExtras
            // 
            this.grpRoomExtras.Controls.Add(this.lblroomTotal);
            this.grpRoomExtras.Controls.Add(this.lblLabel3);
            this.grpRoomExtras.Controls.Add(this.groupBox1);
            this.grpRoomExtras.Controls.Add(this.chkStudy);
            this.grpRoomExtras.Controls.Add(this.chkInternet);
            this.grpRoomExtras.Controls.Add(this.chkButler);
            this.grpRoomExtras.Controls.Add(this.chkConsole);
            this.grpRoomExtras.Controls.Add(this.chkShare);
            this.grpRoomExtras.Controls.Add(this.chkRoomChoice);
            this.grpRoomExtras.Controls.Add(this.chkRobe);
            this.grpRoomExtras.Controls.Add(this.chkSafe);
            this.grpRoomExtras.Controls.Add(this.chkStreaming);
            this.grpRoomExtras.Controls.Add(this.chkMiniBar);
            this.grpRoomExtras.ForeColor = System.Drawing.Color.White;
            this.grpRoomExtras.Location = new System.Drawing.Point(24, 125);
            this.grpRoomExtras.Margin = new System.Windows.Forms.Padding(6);
            this.grpRoomExtras.Name = "grpRoomExtras";
            this.grpRoomExtras.Padding = new System.Windows.Forms.Padding(6);
            this.grpRoomExtras.Size = new System.Drawing.Size(490, 616);
            this.grpRoomExtras.TabIndex = 8;
            this.grpRoomExtras.TabStop = false;
            this.grpRoomExtras.Text = "Extras For Room Available";
            // 
            // lblroomTotal
            // 
            this.lblroomTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblroomTotal.Location = new System.Drawing.Point(312, 571);
            this.lblroomTotal.Name = "lblroomTotal";
            this.lblroomTotal.Size = new System.Drawing.Size(169, 33);
            this.lblroomTotal.TabIndex = 12;
            // 
            // lblLabel3
            // 
            this.lblLabel3.AutoSize = true;
            this.lblLabel3.Location = new System.Drawing.Point(117, 572);
            this.lblLabel3.Name = "lblLabel3";
            this.lblLabel3.Size = new System.Drawing.Size(189, 25);
            this.lblLabel3.TabIndex = 11;
            this.lblLabel3.Text = "Room Extras Total";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbxConsole);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(12, 346);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(6);
            this.groupBox1.Size = new System.Drawing.Size(400, 79);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Console Choices";
            // 
            // cbxConsole
            // 
            this.cbxConsole.Enabled = false;
            this.cbxConsole.FormattingEnabled = true;
            this.cbxConsole.Items.AddRange(new object[] {
            "Nintendo Switch ($25)",
            "Playstation 4 ($35)",
            "X-Box One ($40)",
            "PC ($30)"});
            this.cbxConsole.Location = new System.Drawing.Point(12, 27);
            this.cbxConsole.Margin = new System.Windows.Forms.Padding(6);
            this.cbxConsole.Name = "cbxConsole";
            this.cbxConsole.Size = new System.Drawing.Size(372, 33);
            this.cbxConsole.TabIndex = 0;
            this.cbxConsole.SelectedIndexChanged += new System.EventHandler(this.CbxConsole_SelectedIndexChanged);
            // 
            // chkStudy
            // 
            this.chkStudy.AutoSize = true;
            this.chkStudy.Location = new System.Drawing.Point(12, 525);
            this.chkStudy.Margin = new System.Windows.Forms.Padding(6);
            this.chkStudy.Name = "chkStudy";
            this.chkStudy.Size = new System.Drawing.Size(205, 29);
            this.chkStudy.TabIndex = 9;
            this.chkStudy.Text = "Study Room ($2)";
            this.chkStudy.UseVisualStyleBackColor = true;
            this.chkStudy.CheckedChanged += new System.EventHandler(this.UpdateCostForRoomExtras);
            // 
            // chkInternet
            // 
            this.chkInternet.AutoSize = true;
            this.chkInternet.Location = new System.Drawing.Point(12, 481);
            this.chkInternet.Margin = new System.Windows.Forms.Padding(6);
            this.chkInternet.Name = "chkInternet";
            this.chkInternet.Size = new System.Drawing.Size(236, 29);
            this.chkInternet.TabIndex = 8;
            this.chkInternet.Text = "Internet Access ($5)";
            this.chkInternet.UseVisualStyleBackColor = true;
            this.chkInternet.CheckedChanged += new System.EventHandler(this.UpdateCostForRoomExtras);
            // 
            // chkButler
            // 
            this.chkButler.AutoSize = true;
            this.chkButler.Location = new System.Drawing.Point(12, 437);
            this.chkButler.Margin = new System.Windows.Forms.Padding(6);
            this.chkButler.Name = "chkButler";
            this.chkButler.Size = new System.Drawing.Size(156, 29);
            this.chkButler.TabIndex = 7;
            this.chkButler.Text = "Butler ($35)";
            this.chkButler.UseVisualStyleBackColor = true;
            this.chkButler.CheckedChanged += new System.EventHandler(this.UpdateCostForRoomExtras);
            // 
            // chkConsole
            // 
            this.chkConsole.AutoSize = true;
            this.chkConsole.Location = new System.Drawing.Point(12, 302);
            this.chkConsole.Margin = new System.Windows.Forms.Padding(6);
            this.chkConsole.Name = "chkConsole";
            this.chkConsole.Size = new System.Drawing.Size(271, 29);
            this.chkConsole.TabIndex = 6;
            this.chkConsole.Text = "Gaming Console Rental";
            this.chkConsole.UseVisualStyleBackColor = true;
            this.chkConsole.CheckedChanged += new System.EventHandler(this.UpdateCostForRoomExtras);
            // 
            // chkShare
            // 
            this.chkShare.AutoSize = true;
            this.chkShare.Location = new System.Drawing.Point(12, 258);
            this.chkShare.Margin = new System.Windows.Forms.Padding(6);
            this.chkShare.Name = "chkShare";
            this.chkShare.Size = new System.Drawing.Size(466, 29);
            this.chkShare.TabIndex = 5;
            this.chkShare.Text = "Share Your Room w/An Actual Cougar ($50)";
            this.chkShare.UseVisualStyleBackColor = true;
            this.chkShare.CheckedChanged += new System.EventHandler(this.UpdateCostForRoomExtras);
            // 
            // chkRoomChoice
            // 
            this.chkRoomChoice.AutoSize = true;
            this.chkRoomChoice.Location = new System.Drawing.Point(12, 213);
            this.chkRoomChoice.Margin = new System.Windows.Forms.Padding(6);
            this.chkRoomChoice.Name = "chkRoomChoice";
            this.chkRoomChoice.Size = new System.Drawing.Size(229, 29);
            this.chkRoomChoice.TabIndex = 4;
            this.chkRoomChoice.Text = "Room Choice ($30)";
            this.chkRoomChoice.UseVisualStyleBackColor = true;
            this.chkRoomChoice.CheckedChanged += new System.EventHandler(this.UpdateCostForRoomExtras);
            // 
            // chkRobe
            // 
            this.chkRobe.AutoSize = true;
            this.chkRobe.Location = new System.Drawing.Point(12, 169);
            this.chkRobe.Margin = new System.Windows.Forms.Padding(6);
            this.chkRobe.Name = "chkRobe";
            this.chkRobe.Size = new System.Drawing.Size(139, 29);
            this.chkRobe.TabIndex = 3;
            this.chkRobe.Text = "Robe ($3)";
            this.chkRobe.UseVisualStyleBackColor = true;
            this.chkRobe.CheckedChanged += new System.EventHandler(this.UpdateCostForRoomExtras);
            // 
            // chkSafe
            // 
            this.chkSafe.AutoSize = true;
            this.chkSafe.Location = new System.Drawing.Point(12, 125);
            this.chkSafe.Margin = new System.Windows.Forms.Padding(6);
            this.chkSafe.Name = "chkSafe";
            this.chkSafe.Size = new System.Drawing.Size(144, 29);
            this.chkSafe.TabIndex = 2;
            this.chkSafe.Text = "Safe ($15)";
            this.chkSafe.UseVisualStyleBackColor = true;
            this.chkSafe.CheckedChanged += new System.EventHandler(this.UpdateCostForRoomExtras);
            // 
            // chkStreaming
            // 
            this.chkStreaming.AutoSize = true;
            this.chkStreaming.Location = new System.Drawing.Point(12, 81);
            this.chkStreaming.Margin = new System.Windows.Forms.Padding(6);
            this.chkStreaming.Name = "chkStreaming";
            this.chkStreaming.Size = new System.Drawing.Size(263, 29);
            this.chkStreaming.TabIndex = 1;
            this.chkStreaming.Text = "Streaming Service ($5)";
            this.chkStreaming.UseVisualStyleBackColor = true;
            this.chkStreaming.CheckedChanged += new System.EventHandler(this.UpdateCostForRoomExtras);
            // 
            // chkMiniBar
            // 
            this.chkMiniBar.AutoSize = true;
            this.chkMiniBar.Location = new System.Drawing.Point(12, 37);
            this.chkMiniBar.Margin = new System.Windows.Forms.Padding(6);
            this.chkMiniBar.Name = "chkMiniBar";
            this.chkMiniBar.Size = new System.Drawing.Size(262, 29);
            this.chkMiniBar.TabIndex = 0;
            this.chkMiniBar.Text = "Mini -Bar Access ($10)";
            this.chkMiniBar.UseVisualStyleBackColor = true;
            this.chkMiniBar.CheckedChanged += new System.EventHandler(this.UpdateCostForRoomExtras);
            // 
            // grpOutingExtras
            // 
            this.grpOutingExtras.Controls.Add(this.lblOutingTotal);
            this.grpOutingExtras.Controls.Add(this.lblLabel2);
            this.grpOutingExtras.Controls.Add(this.grpAmountOfTickets);
            this.grpOutingExtras.Controls.Add(this.grpServices);
            this.grpOutingExtras.Controls.Add(this.chkWaterPark);
            this.grpOutingExtras.Controls.Add(this.chkTickets);
            this.grpOutingExtras.Controls.Add(this.chkPool);
            this.grpOutingExtras.Controls.Add(this.chkDaycare);
            this.grpOutingExtras.Controls.Add(this.chkBoatRide);
            this.grpOutingExtras.Controls.Add(this.chkTour);
            this.grpOutingExtras.Controls.Add(this.chkHelicopter);
            this.grpOutingExtras.Controls.Add(this.chkTrainerAndGym);
            this.grpOutingExtras.ForeColor = System.Drawing.Color.White;
            this.grpOutingExtras.Location = new System.Drawing.Point(526, 125);
            this.grpOutingExtras.Margin = new System.Windows.Forms.Padding(6);
            this.grpOutingExtras.Name = "grpOutingExtras";
            this.grpOutingExtras.Padding = new System.Windows.Forms.Padding(6);
            this.grpOutingExtras.Size = new System.Drawing.Size(512, 696);
            this.grpOutingExtras.TabIndex = 10;
            this.grpOutingExtras.TabStop = false;
            this.grpOutingExtras.Text = "Extras For Outings Available";
            // 
            // lblOutingTotal
            // 
            this.lblOutingTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOutingTotal.Location = new System.Drawing.Point(334, 651);
            this.lblOutingTotal.Name = "lblOutingTotal";
            this.lblOutingTotal.Size = new System.Drawing.Size(169, 33);
            this.lblOutingTotal.TabIndex = 14;
            // 
            // lblLabel2
            // 
            this.lblLabel2.AutoSize = true;
            this.lblLabel2.Location = new System.Drawing.Point(132, 652);
            this.lblLabel2.Name = "lblLabel2";
            this.lblLabel2.Size = new System.Drawing.Size(196, 25);
            this.lblLabel2.TabIndex = 13;
            this.lblLabel2.Text = "Outing Extras Total";
            // 
            // grpAmountOfTickets
            // 
            this.grpAmountOfTickets.Controls.Add(this.mtxTicketAmount);
            this.grpAmountOfTickets.Enabled = false;
            this.grpAmountOfTickets.ForeColor = System.Drawing.Color.White;
            this.grpAmountOfTickets.Location = new System.Drawing.Point(12, 525);
            this.grpAmountOfTickets.Margin = new System.Windows.Forms.Padding(6);
            this.grpAmountOfTickets.Name = "grpAmountOfTickets";
            this.grpAmountOfTickets.Padding = new System.Windows.Forms.Padding(6);
            this.grpAmountOfTickets.Size = new System.Drawing.Size(400, 79);
            this.grpAmountOfTickets.TabIndex = 12;
            this.grpAmountOfTickets.TabStop = false;
            this.grpAmountOfTickets.Text = "Amount of Tickets Needed";
            // 
            // mtxTicketAmount
            // 
            this.mtxTicketAmount.Location = new System.Drawing.Point(12, 29);
            this.mtxTicketAmount.Margin = new System.Windows.Forms.Padding(6);
            this.mtxTicketAmount.Mask = "###";
            this.mtxTicketAmount.Name = "mtxTicketAmount";
            this.mtxTicketAmount.Size = new System.Drawing.Size(248, 31);
            this.mtxTicketAmount.TabIndex = 0;
            this.mtxTicketAmount.ValidatingType = typeof(int);
            this.mtxTicketAmount.TextChanged += new System.EventHandler(this.MtxTicketAmount_TextChanged);
            // 
            // grpServices
            // 
            this.grpServices.Controls.Add(this.rdoEvening);
            this.grpServices.Controls.Add(this.rdoAfternoon);
            this.grpServices.Controls.Add(this.rdoMorning);
            this.grpServices.Enabled = false;
            this.grpServices.ForeColor = System.Drawing.Color.White;
            this.grpServices.Location = new System.Drawing.Point(12, 258);
            this.grpServices.Margin = new System.Windows.Forms.Padding(6);
            this.grpServices.Name = "grpServices";
            this.grpServices.Padding = new System.Windows.Forms.Padding(6);
            this.grpServices.Size = new System.Drawing.Size(400, 167);
            this.grpServices.TabIndex = 11;
            this.grpServices.TabStop = false;
            this.grpServices.Text = "Services Available";
            // 
            // chkWaterPark
            // 
            this.chkWaterPark.AutoSize = true;
            this.chkWaterPark.Location = new System.Drawing.Point(12, 615);
            this.chkWaterPark.Margin = new System.Windows.Forms.Padding(6);
            this.chkWaterPark.Name = "chkWaterPark";
            this.chkWaterPark.Size = new System.Drawing.Size(283, 29);
            this.chkWaterPark.TabIndex = 7;
            this.chkWaterPark.Text = "Water Park Access ($10)";
            this.chkWaterPark.UseVisualStyleBackColor = true;
            this.chkWaterPark.CheckedChanged += new System.EventHandler(this.UpdateOutings);
            // 
            // chkTickets
            // 
            this.chkTickets.AutoSize = true;
            this.chkTickets.Location = new System.Drawing.Point(12, 481);
            this.chkTickets.Margin = new System.Windows.Forms.Padding(6);
            this.chkTickets.Name = "chkTickets";
            this.chkTickets.Size = new System.Drawing.Size(494, 29);
            this.chkTickets.TabIndex = 6;
            this.chkTickets.Text = "Tickets to USF Performance Hall ($2 per ticket)";
            this.chkTickets.UseVisualStyleBackColor = true;
            this.chkTickets.CheckedChanged += new System.EventHandler(this.UpdateOutings);
            // 
            // chkPool
            // 
            this.chkPool.AutoSize = true;
            this.chkPool.Location = new System.Drawing.Point(12, 437);
            this.chkPool.Margin = new System.Windows.Forms.Padding(6);
            this.chkPool.Name = "chkPool";
            this.chkPool.Size = new System.Drawing.Size(207, 29);
            this.chkPool.TabIndex = 5;
            this.chkPool.Text = "Pool Access ($5)";
            this.chkPool.UseVisualStyleBackColor = true;
            this.chkPool.CheckedChanged += new System.EventHandler(this.UpdateOutings);
            // 
            // chkDaycare
            // 
            this.chkDaycare.AutoSize = true;
            this.chkDaycare.Location = new System.Drawing.Point(12, 213);
            this.chkDaycare.Margin = new System.Windows.Forms.Padding(6);
            this.chkDaycare.Name = "chkDaycare";
            this.chkDaycare.Size = new System.Drawing.Size(213, 29);
            this.chkDaycare.TabIndex = 4;
            this.chkDaycare.Text = "Daycare Services";
            this.chkDaycare.UseVisualStyleBackColor = true;
            this.chkDaycare.CheckedChanged += new System.EventHandler(this.UpdateOutings);
            // 
            // chkBoatRide
            // 
            this.chkBoatRide.AutoSize = true;
            this.chkBoatRide.Location = new System.Drawing.Point(12, 169);
            this.chkBoatRide.Margin = new System.Windows.Forms.Padding(6);
            this.chkBoatRide.Name = "chkBoatRide";
            this.chkBoatRide.Size = new System.Drawing.Size(309, 29);
            this.chkBoatRide.TabIndex = 3;
            this.chkBoatRide.Text = "Mirror Lake Boat Ride ($10)";
            this.chkBoatRide.UseVisualStyleBackColor = true;
            this.chkBoatRide.CheckedChanged += new System.EventHandler(this.UpdateOutings);
            // 
            // chkTour
            // 
            this.chkTour.AutoSize = true;
            this.chkTour.Location = new System.Drawing.Point(12, 125);
            this.chkTour.Margin = new System.Windows.Forms.Padding(6);
            this.chkTour.Name = "chkTour";
            this.chkTour.Size = new System.Drawing.Size(210, 29);
            this.chkTour.TabIndex = 2;
            this.chkTour.Text = "USF Tour ($0.01)";
            this.chkTour.UseVisualStyleBackColor = true;
            this.chkTour.CheckedChanged += new System.EventHandler(this.UpdateOutings);
            // 
            // chkHelicopter
            // 
            this.chkHelicopter.AutoSize = true;
            this.chkHelicopter.Location = new System.Drawing.Point(12, 81);
            this.chkHelicopter.Margin = new System.Windows.Forms.Padding(6);
            this.chkHelicopter.Name = "chkHelicopter";
            this.chkHelicopter.Size = new System.Drawing.Size(259, 29);
            this.chkHelicopter.TabIndex = 1;
            this.chkHelicopter.Text = "Helicopter Ride ($150)";
            this.chkHelicopter.UseVisualStyleBackColor = true;
            this.chkHelicopter.CheckedChanged += new System.EventHandler(this.UpdateOutings);
            // 
            // chkTrainerAndGym
            // 
            this.chkTrainerAndGym.AutoSize = true;
            this.chkTrainerAndGym.Location = new System.Drawing.Point(12, 37);
            this.chkTrainerAndGym.Margin = new System.Windows.Forms.Padding(6);
            this.chkTrainerAndGym.Name = "chkTrainerAndGym";
            this.chkTrainerAndGym.Size = new System.Drawing.Size(451, 29);
            this.chkTrainerAndGym.TabIndex = 0;
            this.chkTrainerAndGym.Text = "Personal Trainer and Access to Gym ($45)";
            this.chkTrainerAndGym.UseVisualStyleBackColor = true;
            this.chkTrainerAndGym.CheckedChanged += new System.EventHandler(this.UpdateOutings);
            // 
            // btnUncheck
            // 
            this.btnUncheck.Location = new System.Drawing.Point(773, 23);
            this.btnUncheck.Name = "btnUncheck";
            this.btnUncheck.Size = new System.Drawing.Size(267, 90);
            this.btnUncheck.TabIndex = 11;
            this.btnUncheck.Text = "Uncheck all";
            this.btnUncheck.UseVisualStyleBackColor = true;
            this.btnUncheck.Click += new System.EventHandler(this.BtnUncheck_Click);
            // 
            // lblLabel
            // 
            this.lblLabel.AutoSize = true;
            this.lblLabel.ForeColor = System.Drawing.Color.White;
            this.lblLabel.Location = new System.Drawing.Point(101, 777);
            this.lblLabel.Name = "lblLabel";
            this.lblLabel.Size = new System.Drawing.Size(229, 25);
            this.lblLabel.TabIndex = 12;
            this.lblLabel.Text = "Grand Total for Extras:";
            // 
            // lblExtrasTotal
            // 
            this.lblExtrasTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblExtrasTotal.ForeColor = System.Drawing.Color.White;
            this.lblExtrasTotal.Location = new System.Drawing.Point(336, 776);
            this.lblExtrasTotal.Name = "lblExtrasTotal";
            this.lblExtrasTotal.Size = new System.Drawing.Size(169, 33);
            this.lblExtrasTotal.TabIndex = 13;
            // 
            // rdoMorning
            // 
            this.rdoMorning.AutoSize = true;
            this.rdoMorning.Location = new System.Drawing.Point(13, 37);
            this.rdoMorning.Name = "rdoMorning";
            this.rdoMorning.Size = new System.Drawing.Size(177, 29);
            this.rdoMorning.TabIndex = 3;
            this.rdoMorning.TabStop = true;
            this.rdoMorning.Text = "Morning ($15)";
            this.rdoMorning.UseVisualStyleBackColor = true;
            this.rdoMorning.CheckedChanged += new System.EventHandler(this.UpdateDaycare);
            // 
            // rdoAfternoon
            // 
            this.rdoAfternoon.AutoSize = true;
            this.rdoAfternoon.Location = new System.Drawing.Point(13, 74);
            this.rdoAfternoon.Name = "rdoAfternoon";
            this.rdoAfternoon.Size = new System.Drawing.Size(192, 29);
            this.rdoAfternoon.TabIndex = 4;
            this.rdoAfternoon.TabStop = true;
            this.rdoAfternoon.Text = "Afternoon ($20)";
            this.rdoAfternoon.UseVisualStyleBackColor = true;
            this.rdoAfternoon.CheckedChanged += new System.EventHandler(this.UpdateDaycare);
            // 
            // rdoEvening
            // 
            this.rdoEvening.AutoSize = true;
            this.rdoEvening.Location = new System.Drawing.Point(13, 111);
            this.rdoEvening.Name = "rdoEvening";
            this.rdoEvening.Size = new System.Drawing.Size(177, 29);
            this.rdoEvening.TabIndex = 5;
            this.rdoEvening.TabStop = true;
            this.rdoEvening.Text = "Evening ($25)";
            this.rdoEvening.UseVisualStyleBackColor = true;
            this.rdoEvening.CheckedChanged += new System.EventHandler(this.UpdateDaycare);
            // 
            // frmExtras
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(56)))), ((int)(((byte)(101)))));
            this.ClientSize = new System.Drawing.Size(1052, 829);
            this.Controls.Add(this.lblExtrasTotal);
            this.Controls.Add(this.lblLabel);
            this.Controls.Add(this.btnUncheck);
            this.Controls.Add(this.grpOutingExtras);
            this.Controls.Add(this.grpRoomExtras);
            this.Controls.Add(this.picLogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmExtras";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Extras";
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.grpRoomExtras.ResumeLayout(false);
            this.grpRoomExtras.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.grpOutingExtras.ResumeLayout(false);
            this.grpOutingExtras.PerformLayout();
            this.grpAmountOfTickets.ResumeLayout(false);
            this.grpAmountOfTickets.PerformLayout();
            this.grpServices.ResumeLayout(false);
            this.grpServices.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.GroupBox grpRoomExtras;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbxConsole;
        private System.Windows.Forms.CheckBox chkStudy;
        private System.Windows.Forms.CheckBox chkInternet;
        private System.Windows.Forms.CheckBox chkButler;
        private System.Windows.Forms.CheckBox chkConsole;
        private System.Windows.Forms.CheckBox chkShare;
        private System.Windows.Forms.CheckBox chkRoomChoice;
        private System.Windows.Forms.CheckBox chkRobe;
        private System.Windows.Forms.CheckBox chkSafe;
        private System.Windows.Forms.CheckBox chkStreaming;
        private System.Windows.Forms.CheckBox chkMiniBar;
        private System.Windows.Forms.GroupBox grpOutingExtras;
        private System.Windows.Forms.CheckBox chkWaterPark;
        private System.Windows.Forms.CheckBox chkTickets;
        private System.Windows.Forms.CheckBox chkPool;
        private System.Windows.Forms.CheckBox chkDaycare;
        private System.Windows.Forms.CheckBox chkBoatRide;
        private System.Windows.Forms.CheckBox chkTour;
        private System.Windows.Forms.CheckBox chkHelicopter;
        private System.Windows.Forms.CheckBox chkTrainerAndGym;
        private System.Windows.Forms.GroupBox grpAmountOfTickets;
        private System.Windows.Forms.GroupBox grpServices;
        private System.Windows.Forms.MaskedTextBox mtxTicketAmount;
        private System.Windows.Forms.Button btnUncheck;
        private System.Windows.Forms.Label lblroomTotal;
        private System.Windows.Forms.Label lblLabel3;
        private System.Windows.Forms.Label lblOutingTotal;
        private System.Windows.Forms.Label lblLabel2;
        private System.Windows.Forms.Label lblLabel;
        private System.Windows.Forms.Label lblExtrasTotal;
        private System.Windows.Forms.RadioButton rdoEvening;
        private System.Windows.Forms.RadioButton rdoAfternoon;
        private System.Windows.Forms.RadioButton rdoMorning;
    }
}