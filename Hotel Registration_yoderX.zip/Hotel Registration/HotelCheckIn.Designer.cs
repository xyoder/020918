﻿namespace Hotel_Registration
{
    partial class HotelCheckIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpClientInfo = new System.Windows.Forms.GroupBox();
            this.mtxZipCode = new System.Windows.Forms.MaskedTextBox();
            this.mtxPhone = new System.Windows.Forms.MaskedTextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.lblZipCode = new System.Windows.Forms.Label();
            this.lblState = new System.Windows.Forms.Label();
            this.lblStreet = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.cbxState = new System.Windows.Forms.ComboBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.grpRoomType = new System.Windows.Forms.GroupBox();
            this.rdbKing = new System.Windows.Forms.RadioButton();
            this.rdbQueen = new System.Windows.Forms.RadioButton();
            this.rdbDouble = new System.Windows.Forms.RadioButton();
            this.rdbSingleBed = new System.Windows.Forms.RadioButton();
            this.grpMembership = new System.Windows.Forms.GroupBox();
            this.rdbPlatinumMember = new System.Windows.Forms.RadioButton();
            this.rdbGoldMember = new System.Windows.Forms.RadioButton();
            this.rdbNoneMember = new System.Windows.Forms.RadioButton();
            this.grpTotalCost = new System.Windows.Forms.GroupBox();
            this.lblAmtDue = new System.Windows.Forms.Label();
            this.lblAmtDiscount = new System.Windows.Forms.Label();
            this.lblAmtExtra = new System.Windows.Forms.Label();
            this.lblAmtMeal = new System.Windows.Forms.Label();
            this.lblAmtDiscountRate = new System.Windows.Forms.Label();
            this.lblAmtRoomRate = new System.Windows.Forms.Label();
            this.lblAmtDays = new System.Windows.Forms.Label();
            this.lblTotalDue = new System.Windows.Forms.Label();
            this.lblExtraCost = new System.Windows.Forms.Label();
            this.lblMealCost = new System.Windows.Forms.Label();
            this.lblDiscountCost = new System.Windows.Forms.Label();
            this.lblDiscountRate = new System.Windows.Forms.Label();
            this.lblRoom = new System.Windows.Forms.Label();
            this.lblDays = new System.Windows.Forms.Label();
            this.btnMeal = new System.Windows.Forms.Button();
            this.grpDays = new System.Windows.Forms.GroupBox();
            this.cbxDays = new System.Windows.Forms.ComboBox();
            this.btnExtra = new System.Windows.Forms.Button();
            this.btnPayBill = new System.Windows.Forms.Button();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.grpClientInfo.SuspendLayout();
            this.grpRoomType.SuspendLayout();
            this.grpMembership.SuspendLayout();
            this.grpTotalCost.SuspendLayout();
            this.grpDays.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // grpClientInfo
            // 
            this.grpClientInfo.Controls.Add(this.mtxZipCode);
            this.grpClientInfo.Controls.Add(this.mtxPhone);
            this.grpClientInfo.Controls.Add(this.lblPhone);
            this.grpClientInfo.Controls.Add(this.lblZipCode);
            this.grpClientInfo.Controls.Add(this.lblState);
            this.grpClientInfo.Controls.Add(this.lblStreet);
            this.grpClientInfo.Controls.Add(this.lblLastName);
            this.grpClientInfo.Controls.Add(this.lblFirstName);
            this.grpClientInfo.Controls.Add(this.cbxState);
            this.grpClientInfo.Controls.Add(this.txtAddress);
            this.grpClientInfo.Controls.Add(this.txtLastName);
            this.grpClientInfo.Controls.Add(this.txtFirstName);
            this.grpClientInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpClientInfo.ForeColor = System.Drawing.Color.White;
            this.grpClientInfo.Location = new System.Drawing.Point(12, 83);
            this.grpClientInfo.Name = "grpClientInfo";
            this.grpClientInfo.Size = new System.Drawing.Size(451, 173);
            this.grpClientInfo.TabIndex = 0;
            this.grpClientInfo.TabStop = false;
            this.grpClientInfo.Text = "Client";
            // 
            // mtxZipCode
            // 
            this.mtxZipCode.BeepOnError = true;
            this.mtxZipCode.Location = new System.Drawing.Point(83, 137);
            this.mtxZipCode.Mask = "00000";
            this.mtxZipCode.Name = "mtxZipCode";
            this.mtxZipCode.Size = new System.Drawing.Size(46, 22);
            this.mtxZipCode.TabIndex = 5;
            this.mtxZipCode.ValidatingType = typeof(int);
            this.mtxZipCode.Leave += new System.EventHandler(this.mtxZipCode_Leave);
            // 
            // mtxPhone
            // 
            this.mtxPhone.BeepOnError = true;
            this.mtxPhone.Location = new System.Drawing.Point(333, 137);
            this.mtxPhone.Mask = "(999) 000-0000";
            this.mtxPhone.Name = "mtxPhone";
            this.mtxPhone.Size = new System.Drawing.Size(100, 22);
            this.mtxPhone.TabIndex = 6;
            this.mtxPhone.Leave += new System.EventHandler(this.mtxPhone_Leave);
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(226, 140);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(101, 16);
            this.lblPhone.TabIndex = 12;
            this.lblPhone.Text = "Phone Number:";
            // 
            // lblZipCode
            // 
            this.lblZipCode.AutoSize = true;
            this.lblZipCode.Location = new System.Drawing.Point(14, 140);
            this.lblZipCode.Name = "lblZipCode";
            this.lblZipCode.Size = new System.Drawing.Size(63, 16);
            this.lblZipCode.TabIndex = 10;
            this.lblZipCode.Text = "ZipCode:";
            // 
            // lblState
            // 
            this.lblState.AutoSize = true;
            this.lblState.Location = new System.Drawing.Point(35, 113);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(42, 16);
            this.lblState.TabIndex = 9;
            this.lblState.Text = "State:";
            // 
            // lblStreet
            // 
            this.lblStreet.AutoSize = true;
            this.lblStreet.Location = new System.Drawing.Point(31, 87);
            this.lblStreet.Name = "lblStreet";
            this.lblStreet.Size = new System.Drawing.Size(46, 16);
            this.lblStreet.TabIndex = 8;
            this.lblStreet.Text = "Street:";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(6, 60);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(76, 16);
            this.lblLastName.TabIndex = 7;
            this.lblLastName.Text = "Last Name:";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(6, 33);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(76, 16);
            this.lblFirstName.TabIndex = 6;
            this.lblFirstName.Text = "First Name:";
            // 
            // cbxState
            // 
            this.cbxState.FormattingEnabled = true;
            this.cbxState.Location = new System.Drawing.Point(83, 110);
            this.cbxState.Name = "cbxState";
            this.cbxState.Size = new System.Drawing.Size(121, 24);
            this.cbxState.TabIndex = 4;
            this.cbxState.Leave += new System.EventHandler(this.cbxState_Leave);
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(83, 84);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(350, 22);
            this.txtAddress.TabIndex = 2;
            this.txtAddress.Leave += new System.EventHandler(this.txtAddress_Leave);
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(83, 57);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(174, 22);
            this.txtLastName.TabIndex = 1;
            this.txtLastName.Leave += new System.EventHandler(this.txtLastName_Leave);
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(83, 30);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(174, 22);
            this.txtFirstName.TabIndex = 0;
            this.txtFirstName.Leave += new System.EventHandler(this.txtFirstName_Leave);
            // 
            // grpRoomType
            // 
            this.grpRoomType.Controls.Add(this.rdbKing);
            this.grpRoomType.Controls.Add(this.rdbQueen);
            this.grpRoomType.Controls.Add(this.rdbDouble);
            this.grpRoomType.Controls.Add(this.rdbSingleBed);
            this.grpRoomType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpRoomType.ForeColor = System.Drawing.Color.White;
            this.grpRoomType.Location = new System.Drawing.Point(12, 262);
            this.grpRoomType.Name = "grpRoomType";
            this.grpRoomType.Size = new System.Drawing.Size(147, 140);
            this.grpRoomType.TabIndex = 1;
            this.grpRoomType.TabStop = false;
            this.grpRoomType.Text = "Select Room Type";
            // 
            // rdbKing
            // 
            this.rdbKing.AutoSize = true;
            this.rdbKing.Location = new System.Drawing.Point(17, 103);
            this.rdbKing.Name = "rdbKing";
            this.rdbKing.Size = new System.Drawing.Size(94, 20);
            this.rdbKing.TabIndex = 3;
            this.rdbKing.TabStop = true;
            this.rdbKing.Text = "King ($ 250)";
            this.rdbKing.UseVisualStyleBackColor = true;
            this.rdbKing.CheckedChanged += new System.EventHandler(this.rdbKing_CheckedChanged);
            // 
            // rdbQueen
            // 
            this.rdbQueen.AutoSize = true;
            this.rdbQueen.Location = new System.Drawing.Point(17, 76);
            this.rdbQueen.Name = "rdbQueen";
            this.rdbQueen.Size = new System.Drawing.Size(108, 20);
            this.rdbQueen.TabIndex = 2;
            this.rdbQueen.TabStop = true;
            this.rdbQueen.Text = "Queen ($ 200)";
            this.rdbQueen.UseVisualStyleBackColor = true;
            this.rdbQueen.CheckedChanged += new System.EventHandler(this.rdbQueen_CheckedChanged);
            // 
            // rdbDouble
            // 
            this.rdbDouble.AutoSize = true;
            this.rdbDouble.Location = new System.Drawing.Point(17, 49);
            this.rdbDouble.Name = "rdbDouble";
            this.rdbDouble.Size = new System.Drawing.Size(112, 20);
            this.rdbDouble.TabIndex = 1;
            this.rdbDouble.TabStop = true;
            this.rdbDouble.Text = "Double ($ 150)";
            this.rdbDouble.UseVisualStyleBackColor = true;
            this.rdbDouble.CheckedChanged += new System.EventHandler(this.rdbDouble_CheckedChanged);
            // 
            // rdbSingleBed
            // 
            this.rdbSingleBed.AutoSize = true;
            this.rdbSingleBed.Location = new System.Drawing.Point(17, 22);
            this.rdbSingleBed.Name = "rdbSingleBed";
            this.rdbSingleBed.Size = new System.Drawing.Size(106, 20);
            this.rdbSingleBed.TabIndex = 0;
            this.rdbSingleBed.TabStop = true;
            this.rdbSingleBed.Text = "Single ($ 100)";
            this.rdbSingleBed.UseVisualStyleBackColor = true;
            this.rdbSingleBed.CheckedChanged += new System.EventHandler(this.rdbSingleBed_CheckedChanged);
            // 
            // grpMembership
            // 
            this.grpMembership.Controls.Add(this.rdbPlatinumMember);
            this.grpMembership.Controls.Add(this.rdbGoldMember);
            this.grpMembership.Controls.Add(this.rdbNoneMember);
            this.grpMembership.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpMembership.ForeColor = System.Drawing.Color.White;
            this.grpMembership.Location = new System.Drawing.Point(200, 262);
            this.grpMembership.Name = "grpMembership";
            this.grpMembership.Size = new System.Drawing.Size(223, 110);
            this.grpMembership.TabIndex = 2;
            this.grpMembership.TabStop = false;
            this.grpMembership.Text = "Select Membership";
            // 
            // rdbPlatinumMember
            // 
            this.rdbPlatinumMember.AutoSize = true;
            this.rdbPlatinumMember.Location = new System.Drawing.Point(7, 76);
            this.rdbPlatinumMember.Name = "rdbPlatinumMember";
            this.rdbPlatinumMember.Size = new System.Drawing.Size(169, 20);
            this.rdbPlatinumMember.TabIndex = 2;
            this.rdbPlatinumMember.TabStop = true;
            this.rdbPlatinumMember.Text = "Platinum (30% Discount)";
            this.rdbPlatinumMember.UseVisualStyleBackColor = true;
            this.rdbPlatinumMember.CheckedChanged += new System.EventHandler(this.SetMembershipDiscount);
            // 
            // rdbGoldMember
            // 
            this.rdbGoldMember.AutoSize = true;
            this.rdbGoldMember.Location = new System.Drawing.Point(7, 49);
            this.rdbGoldMember.Name = "rdbGoldMember";
            this.rdbGoldMember.Size = new System.Drawing.Size(145, 20);
            this.rdbGoldMember.TabIndex = 1;
            this.rdbGoldMember.TabStop = true;
            this.rdbGoldMember.Text = "Gold (20% discount)";
            this.rdbGoldMember.UseVisualStyleBackColor = true;
            this.rdbGoldMember.CheckedChanged += new System.EventHandler(this.SetMembershipDiscount);
            // 
            // rdbNoneMember
            // 
            this.rdbNoneMember.AutoSize = true;
            this.rdbNoneMember.Location = new System.Drawing.Point(7, 22);
            this.rdbNoneMember.Name = "rdbNoneMember";
            this.rdbNoneMember.Size = new System.Drawing.Size(205, 20);
            this.rdbNoneMember.TabIndex = 0;
            this.rdbNoneMember.TabStop = true;
            this.rdbNoneMember.Text = "No Membership (0% discount)";
            this.rdbNoneMember.UseVisualStyleBackColor = true;
            this.rdbNoneMember.CheckedChanged += new System.EventHandler(this.SetMembershipDiscount);
            // 
            // grpTotalCost
            // 
            this.grpTotalCost.Controls.Add(this.lblAmtDue);
            this.grpTotalCost.Controls.Add(this.lblAmtDiscount);
            this.grpTotalCost.Controls.Add(this.lblAmtExtra);
            this.grpTotalCost.Controls.Add(this.lblAmtMeal);
            this.grpTotalCost.Controls.Add(this.lblAmtDiscountRate);
            this.grpTotalCost.Controls.Add(this.lblAmtRoomRate);
            this.grpTotalCost.Controls.Add(this.lblAmtDays);
            this.grpTotalCost.Controls.Add(this.lblTotalDue);
            this.grpTotalCost.Controls.Add(this.lblExtraCost);
            this.grpTotalCost.Controls.Add(this.lblMealCost);
            this.grpTotalCost.Controls.Add(this.lblDiscountCost);
            this.grpTotalCost.Controls.Add(this.lblDiscountRate);
            this.grpTotalCost.Controls.Add(this.lblRoom);
            this.grpTotalCost.Controls.Add(this.lblDays);
            this.grpTotalCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpTotalCost.ForeColor = System.Drawing.Color.White;
            this.grpTotalCost.Location = new System.Drawing.Point(469, 83);
            this.grpTotalCost.Name = "grpTotalCost";
            this.grpTotalCost.Size = new System.Drawing.Size(200, 424);
            this.grpTotalCost.TabIndex = 4;
            this.grpTotalCost.TabStop = false;
            this.grpTotalCost.Text = "Total Cost";
            // 
            // lblAmtDue
            // 
            this.lblAmtDue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblAmtDue.Location = new System.Drawing.Point(23, 381);
            this.lblAmtDue.Name = "lblAmtDue";
            this.lblAmtDue.Size = new System.Drawing.Size(160, 32);
            this.lblAmtDue.TabIndex = 13;
            this.lblAmtDue.Text = "label1";
            this.lblAmtDue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAmtDiscount
            // 
            this.lblAmtDiscount.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblAmtDiscount.Location = new System.Drawing.Point(23, 323);
            this.lblAmtDiscount.Name = "lblAmtDiscount";
            this.lblAmtDiscount.Size = new System.Drawing.Size(160, 32);
            this.lblAmtDiscount.TabIndex = 12;
            this.lblAmtDiscount.Text = "label1";
            this.lblAmtDiscount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAmtExtra
            // 
            this.lblAmtExtra.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblAmtExtra.Location = new System.Drawing.Point(23, 270);
            this.lblAmtExtra.Name = "lblAmtExtra";
            this.lblAmtExtra.Size = new System.Drawing.Size(160, 32);
            this.lblAmtExtra.TabIndex = 11;
            this.lblAmtExtra.Text = "label1";
            this.lblAmtExtra.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAmtMeal
            // 
            this.lblAmtMeal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblAmtMeal.Location = new System.Drawing.Point(23, 216);
            this.lblAmtMeal.Name = "lblAmtMeal";
            this.lblAmtMeal.Size = new System.Drawing.Size(160, 32);
            this.lblAmtMeal.TabIndex = 10;
            this.lblAmtMeal.Text = "label1";
            this.lblAmtMeal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAmtDiscountRate
            // 
            this.lblAmtDiscountRate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblAmtDiscountRate.Location = new System.Drawing.Point(23, 158);
            this.lblAmtDiscountRate.Name = "lblAmtDiscountRate";
            this.lblAmtDiscountRate.Size = new System.Drawing.Size(160, 32);
            this.lblAmtDiscountRate.TabIndex = 9;
            this.lblAmtDiscountRate.Text = "label1";
            this.lblAmtDiscountRate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAmtRoomRate
            // 
            this.lblAmtRoomRate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblAmtRoomRate.Location = new System.Drawing.Point(23, 93);
            this.lblAmtRoomRate.Name = "lblAmtRoomRate";
            this.lblAmtRoomRate.Size = new System.Drawing.Size(160, 32);
            this.lblAmtRoomRate.TabIndex = 8;
            this.lblAmtRoomRate.Text = "label1";
            this.lblAmtRoomRate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAmtDays
            // 
            this.lblAmtDays.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblAmtDays.Location = new System.Drawing.Point(23, 38);
            this.lblAmtDays.Name = "lblAmtDays";
            this.lblAmtDays.Size = new System.Drawing.Size(160, 32);
            this.lblAmtDays.TabIndex = 7;
            this.lblAmtDays.Text = "label1";
            this.lblAmtDays.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTotalDue
            // 
            this.lblTotalDue.AutoSize = true;
            this.lblTotalDue.Location = new System.Drawing.Point(6, 364);
            this.lblTotalDue.Name = "lblTotalDue";
            this.lblTotalDue.Size = new System.Drawing.Size(70, 16);
            this.lblTotalDue.TabIndex = 6;
            this.lblTotalDue.Text = "Total Due:";
            // 
            // lblExtraCost
            // 
            this.lblExtraCost.AutoSize = true;
            this.lblExtraCost.Location = new System.Drawing.Point(5, 248);
            this.lblExtraCost.Name = "lblExtraCost";
            this.lblExtraCost.Size = new System.Drawing.Size(71, 16);
            this.lblExtraCost.TabIndex = 5;
            this.lblExtraCost.Text = "Extra Cost:";
            // 
            // lblMealCost
            // 
            this.lblMealCost.AutoSize = true;
            this.lblMealCost.Location = new System.Drawing.Point(5, 190);
            this.lblMealCost.Name = "lblMealCost";
            this.lblMealCost.Size = new System.Drawing.Size(71, 16);
            this.lblMealCost.TabIndex = 4;
            this.lblMealCost.Text = "Meal Cost:";
            // 
            // lblDiscountCost
            // 
            this.lblDiscountCost.AutoSize = true;
            this.lblDiscountCost.Location = new System.Drawing.Point(6, 303);
            this.lblDiscountCost.Name = "lblDiscountCost";
            this.lblDiscountCost.Size = new System.Drawing.Size(60, 16);
            this.lblDiscountCost.TabIndex = 3;
            this.lblDiscountCost.Text = "Discount";
            // 
            // lblDiscountRate
            // 
            this.lblDiscountRate.AutoSize = true;
            this.lblDiscountRate.Location = new System.Drawing.Point(5, 137);
            this.lblDiscountRate.Name = "lblDiscountRate";
            this.lblDiscountRate.Size = new System.Drawing.Size(95, 16);
            this.lblDiscountRate.TabIndex = 2;
            this.lblDiscountRate.Text = "Discount Rate:";
            // 
            // lblRoom
            // 
            this.lblRoom.AutoSize = true;
            this.lblRoom.Location = new System.Drawing.Point(6, 73);
            this.lblRoom.Name = "lblRoom";
            this.lblRoom.Size = new System.Drawing.Size(80, 16);
            this.lblRoom.TabIndex = 1;
            this.lblRoom.Text = "Room Rate:";
            // 
            // lblDays
            // 
            this.lblDays.AutoSize = true;
            this.lblDays.Location = new System.Drawing.Point(6, 18);
            this.lblDays.Name = "lblDays";
            this.lblDays.Size = new System.Drawing.Size(43, 16);
            this.lblDays.TabIndex = 0;
            this.lblDays.Text = "Days:";
            // 
            // btnMeal
            // 
            this.btnMeal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMeal.Location = new System.Drawing.Point(262, 456);
            this.btnMeal.Name = "btnMeal";
            this.btnMeal.Size = new System.Drawing.Size(141, 49);
            this.btnMeal.TabIndex = 5;
            this.btnMeal.Text = "Select Meal Plan";
            this.btnMeal.UseVisualStyleBackColor = true;
            this.btnMeal.Click += new System.EventHandler(this.btnMeal_Click);
            // 
            // grpDays
            // 
            this.grpDays.Controls.Add(this.cbxDays);
            this.grpDays.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpDays.ForeColor = System.Drawing.Color.White;
            this.grpDays.Location = new System.Drawing.Point(200, 378);
            this.grpDays.Name = "grpDays";
            this.grpDays.Size = new System.Drawing.Size(223, 60);
            this.grpDays.TabIndex = 4;
            this.grpDays.TabStop = false;
            this.grpDays.Text = "Select Number of Days";
            // 
            // cbxDays
            // 
            this.cbxDays.FormattingEnabled = true;
            this.cbxDays.Location = new System.Drawing.Point(7, 22);
            this.cbxDays.Name = "cbxDays";
            this.cbxDays.Size = new System.Drawing.Size(205, 24);
            this.cbxDays.TabIndex = 0;
            this.cbxDays.SelectedIndexChanged += new System.EventHandler(this.cbxDays_SelectedIndexChanged);
            // 
            // btnExtra
            // 
            this.btnExtra.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExtra.Location = new System.Drawing.Point(46, 456);
            this.btnExtra.Name = "btnExtra";
            this.btnExtra.Size = new System.Drawing.Size(141, 49);
            this.btnExtra.TabIndex = 8;
            this.btnExtra.Text = "Select Extras";
            this.btnExtra.UseVisualStyleBackColor = true;
            this.btnExtra.Click += new System.EventHandler(this.btnExtra_Click);
            // 
            // btnPayBill
            // 
            this.btnPayBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPayBill.Location = new System.Drawing.Point(492, 513);
            this.btnPayBill.Name = "btnPayBill";
            this.btnPayBill.Size = new System.Drawing.Size(141, 49);
            this.btnPayBill.TabIndex = 9;
            this.btnPayBill.Text = "Pay Bill";
            this.btnPayBill.UseVisualStyleBackColor = true;
            this.btnPayBill.Click += new System.EventHandler(this.btnPayBill_Click);
            // 
            // picLogo
            // 
            this.picLogo.Image = global::Hotel_Registration.Properties.Resources.HotelLogo;
            this.picLogo.Location = new System.Drawing.Point(12, 12);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(657, 65);
            this.picLogo.TabIndex = 1;
            this.picLogo.TabStop = false;
            // 
            // HotelCheckIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(56)))), ((int)(((byte)(101)))));
            this.ClientSize = new System.Drawing.Size(688, 577);
            this.Controls.Add(this.btnPayBill);
            this.Controls.Add(this.btnExtra);
            this.Controls.Add(this.grpDays);
            this.Controls.Add(this.btnMeal);
            this.Controls.Add(this.grpTotalCost);
            this.Controls.Add(this.grpMembership);
            this.Controls.Add(this.grpRoomType);
            this.Controls.Add(this.picLogo);
            this.Controls.Add(this.grpClientInfo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "HotelCheckIn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "USF Hotel Check In";
            this.Load += new System.EventHandler(this.HotelCheckIn_Load);
            this.grpClientInfo.ResumeLayout(false);
            this.grpClientInfo.PerformLayout();
            this.grpRoomType.ResumeLayout(false);
            this.grpRoomType.PerformLayout();
            this.grpMembership.ResumeLayout(false);
            this.grpMembership.PerformLayout();
            this.grpTotalCost.ResumeLayout(false);
            this.grpTotalCost.PerformLayout();
            this.grpDays.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpClientInfo;
        private System.Windows.Forms.Label lblState;
        private System.Windows.Forms.Label lblStreet;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.ComboBox cbxState;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.GroupBox grpRoomType;
        private System.Windows.Forms.Label lblZipCode;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.RadioButton rdbKing;
        private System.Windows.Forms.RadioButton rdbQueen;
        private System.Windows.Forms.RadioButton rdbDouble;
        private System.Windows.Forms.RadioButton rdbSingleBed;
        private System.Windows.Forms.GroupBox grpMembership;
        private System.Windows.Forms.RadioButton rdbPlatinumMember;
        private System.Windows.Forms.RadioButton rdbGoldMember;
        private System.Windows.Forms.RadioButton rdbNoneMember;
        private System.Windows.Forms.GroupBox grpTotalCost;
        private System.Windows.Forms.Button btnMeal;
        private System.Windows.Forms.GroupBox grpDays;
        private System.Windows.Forms.ComboBox cbxDays;
        private System.Windows.Forms.Label lblAmtDays;
        private System.Windows.Forms.Label lblTotalDue;
        private System.Windows.Forms.Label lblExtraCost;
        private System.Windows.Forms.Label lblMealCost;
        private System.Windows.Forms.Label lblDiscountCost;
        private System.Windows.Forms.Label lblDiscountRate;
        private System.Windows.Forms.Label lblRoom;
        private System.Windows.Forms.Label lblDays;
        private System.Windows.Forms.Label lblAmtDiscountRate;
        private System.Windows.Forms.Label lblAmtRoomRate;
        private System.Windows.Forms.Label lblAmtDue;
        private System.Windows.Forms.Label lblAmtDiscount;
        private System.Windows.Forms.Label lblAmtExtra;
        private System.Windows.Forms.Label lblAmtMeal;
        private System.Windows.Forms.Button btnExtra;
        private System.Windows.Forms.Button btnPayBill;
        private System.Windows.Forms.MaskedTextBox mtxPhone;
        private System.Windows.Forms.MaskedTextBox mtxZipCode;
    }
}

