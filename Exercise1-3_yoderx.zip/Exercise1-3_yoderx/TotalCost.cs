﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercises_Ch1
{
    public partial class TotalCost : Form
    {
        /*Name: Xavier Yoder
         * Date: September 26, 2019
         * Purpose: create a total cost calculator with a sales tax rate of 6% and adding the costs for labor and materials
         */


        //declare global variables to share between the compute click event and text change validation
        decimal labor, material;
        public TotalCost()
        {
            InitializeComponent();
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            //clsoe the form
            this.Close();
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            //clear all input and output
            txtLabor.Text = "";
            txtMaterial.Text = "";
            lblSalesTax.Text = "";
            lblSubtotal.Text = "";
            lblTotalCost.Text = "";
        }

        private void BtnCompute_Click(object sender, EventArgs e)
        {
            if (txtLabor.Text == "" || txtMaterial.Text == "")
            {
                MessageBox.Show("Must put a number inside Labor cost and Material cost");
            }
            else
            {
                //Declare variables
                const decimal Tax = .06M;
                decimal subTotal, salesTax, totalCost;

                //Convert the input strings to decimals
                material = Convert.ToDecimal(txtMaterial.Text);
                labor = Convert.ToDecimal(txtLabor.Text);

                subTotal = Convert.ToDecimal(labor + material);
                salesTax = subTotal * Tax;
                totalCost = subTotal + salesTax;

                lblSubtotal.Text = $"{subTotal:C}";
                lblSalesTax.Text = $"{salesTax:C}";
                lblTotalCost.Text = $"{totalCost:C}";
                btnClear.Focus();
            }
        }

        private void TxtLabor_Validating(object sender, CancelEventArgs e)
        {
            //validate input when the user leaves the textbox
            try
            {
                labor = Convert.ToDecimal(txtLabor.Text);
            }
            catch
            {
                MessageBox.Show("Input for labor cost must be a number.");
                txtLabor.Text = "";
                txtLabor.Focus();
            }
        }

        private void TxtMaterial_Validating(object sender, CancelEventArgs e)
        {
            //validate input when the use leaves the textbox
            try
            {
                material = Convert.ToDecimal(txtMaterial.Text);
            }
            catch
            {
                MessageBox.Show("Input for material cost must be a number.");
                txtMaterial.Text = "";
                txtMaterial.Focus();
            }
        }
    }
}
