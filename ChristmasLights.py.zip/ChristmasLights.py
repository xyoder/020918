import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(21,GPIO.OUT)
GPIO.setup(20,GPIO.OUT)
GPIO.setup(16,GPIO.OUT)
GPIO.setup(25,GPIO.OUT)
GPIO.setup(24,GPIO.OUT)
GPIO.setup(23,GPIO.OUT)
GPIO.setup(18,GPIO.OUT)


print("Please enjoy this visual representation of a shortened version of Carol of the Bells by the Trans-Siberian Orchestra")

for x in range(4):
	GPIO.output(21,GPIO.HIGH)
	time.sleep(.3)
	GPIO.output(20,GPIO.HIGH)
	GPIO.output(21,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(25,GPIO.HIGH)
	GPIO.output(20,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(16,GPIO.HIGH)
	GPIO.output(25,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(16,GPIO.LOW)

GPIO.output(21,GPIO.HIGH)

time.sleep(.3)

GPIO.output(20,GPIO.HIGH)
GPIO.output(21,GPIO.LOW)

time.sleep(.3)

GPIO.output(23,GPIO.HIGH)
GPIO.output(20,GPIO.LOW)

time.sleep(.15)

GPIO.output(23,GPIO.LOW)

time.sleep (.15)

GPIO.output(23,GPIO.HIGH)

time.sleep(.3)

GPIO.output(24,GPIO.HIGH)
GPIO.output(23,GPIO.LOW)

time.sleep(.3)

GPIO.output(25,GPIO.HIGH)
GPIO.output(24,GPIO.LOW)

time.sleep(.3)

GPIO.output(16,GPIO.HIGH)
GPIO.output(25,GPIO.LOW)

time.sleep(.3)

GPIO.output(20,GPIO.HIGH)
GPIO.output(16,GPIO.LOW)

time.sleep(.3)

GPIO.output(21,GPIO.HIGH)
GPIO.output(20,GPIO.LOW)

time.sleep(.3)

GPIO.output(20,GPIO.HIGH)
GPIO.output(21,GPIO.LOW)

time.sleep(.3)

GPIO.output(16,GPIO.HIGH)
GPIO.output(20,GPIO.LOW)

time.sleep(.3)

GPIO.output(25,GPIO.HIGH)
GPIO.output(16,GPIO.LOW)

time.sleep(.3)

GPIO.output(24,GPIO.HIGH)
GPIO.output(25,GPIO.LOW)

time.sleep(.3)

GPIO.output(23,GPIO.HIGH)
GPIO.output(24,GPIO.LOW)

time.sleep(.3)

GPIO.output(18,GPIO.HIGH)
GPIO.output(23,GPIO.LOW)

time.sleep(1.2)

GPIO.output(18,GPIO.LOW)

for x in range(2):
	GPIO.output(21,GPIO.HIGH)
	time.sleep(.3)
	GPIO.output(20,GPIO.HIGH)
	GPIO.output(21,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(25,GPIO.HIGH)
	GPIO.output(20,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(16,GPIO.HIGH)
	GPIO.output(25,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(16,GPIO.LOW)

for x in range(2):
	GPIO.output(21,GPIO.HIGH)
	GPIO.output(16,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(20,GPIO.HIGH)
	GPIO.output(21,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(23,GPIO.HIGH)
	GPIO.output(20,GPIO.LOW)
	time.sleep(.15)
	GPIO.output(23,GPIO.LOW)
	time.sleep (.15)
	GPIO.output(23,GPIO.HIGH)
	time.sleep(.3)
	GPIO.output(24,GPIO.HIGH)
	GPIO.output(23,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(25,GPIO.HIGH)
	GPIO.output(24,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(16,GPIO.HIGH)
	GPIO.output(25,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(20,GPIO.HIGH)
	GPIO.output(16,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(21,GPIO.HIGH)
	GPIO.output(20,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(20,GPIO.HIGH)
	GPIO.output(21,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(16,GPIO.HIGH)
	GPIO.output(20,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(25,GPIO.HIGH)
	GPIO.output(16,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(24,GPIO.HIGH)
	GPIO.output(25,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(23,GPIO.HIGH)
	GPIO.output(24,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(18,GPIO.HIGH)
	GPIO.output(23,GPIO.LOW)
	time.sleep(.1)
	GPIO.output(16,GPIO.HIGH)
	GPIO.output(18,GPIO.LOW)
	time.sleep(.15)
	GPIO.output(16,GPIO.LOW)
	time.sleep(.15)
	GPIO.output(16,GPIO.HIGH)
	time.sleep(.3)
	GPIO.output(18,GPIO.HIGH)
	GPIO.output(16,GPIO.LOW)
	time.sleep(.15)
	GPIO.output(18,GPIO.LOW)
	time.sleep(.15)
	GPIO.output(18,GPIO.HIGH)
	time.sleep(.3)
	GPIO.output(23,GPIO.HIGH)
	GPIO.output(18,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(24,GPIO.HIGH)
	GPIO.output(23,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(25,GPIO.HIGH)
	GPIO.output(24,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(16,GPIO.HIGH)
	GPIO.output(25,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(20,GPIO.HIGH)
	GPIO.output(16,GPIO.LOW)
	time.sleep(.3)
	GPIO.output(16,GPIO.HIGH)
	GPIO.output(20,GPIO.LOW)
	time.sleep(.1)

time.sleep(.5)
	
	
GPIO.output(16,GPIO.LOW)

time.sleep(.01)

for x in range(2):
	for x in range(3):
		GPIO.output(21,GPIO.HIGH)
		GPIO.output(20,GPIO.HIGH)
		GPIO.output(16,GPIO.HIGH)
		GPIO.output(25,GPIO.HIGH)
		GPIO.output(24,GPIO.HIGH)
		GPIO.output(23,GPIO.HIGH)
		GPIO.output(18,GPIO.HIGH)
		
		time.sleep(.5)
	
		GPIO.output(21,GPIO.LOW)
		GPIO.output(20,GPIO.LOW)
		GPIO.output(16,GPIO.LOW)
		GPIO.output(25,GPIO.LOW)
		GPIO.output(24,GPIO.LOW)
		GPIO.output(23,GPIO.LOW)
		GPIO.output(18,GPIO.LOW)
	
		time.sleep(.15)
	
		GPIO.output(20, GPIO.HIGH)
	
		time.sleep(.15)
	
		GPIO.output(23,GPIO.HIGH)
		GPIO.output(20,GPIO.LOW)
	
		time.sleep(.15)
	
		GPIO.output(20,GPIO.HIGH)
		GPIO.output(23,GPIO.LOW)
	
		time.sleep(.15)
	
		GPIO.output(23,GPIO.HIGH)
		GPIO.output(20,GPIO.LOW)
		
		time.sleep(.05)
		
		GPIO.output(23,GPIO.LOW)
		
		time.sleep(.1)
	
	for x in range(3):
		GPIO.output(20,GPIO.HIGH)
		GPIO.output(23,GPIO.LOW)
	
		time.sleep(.15)
	
		GPIO.output(23,GPIO.HIGH)
		GPIO.output(20,GPIO.LOW)
		
		time.sleep(.05)
		
		GPIO.output(23,GPIO.LOW)
		
		time.sleep(.1)

GPIO.output(21,GPIO.HIGH)

time.sleep(.25)

GPIO.output(21,GPIO.LOW)

time.sleep(.05)

GPIO.output(21,GPIO.HIGH)

time.sleep(.25)

GPIO.output(21,GPIO.LOW)

time.sleep(.35)

GPIO.output(18,GPIO.HIGH)

time.sleep(.25)

GPIO.output(18,GPIO.LOW)

time.sleep(.05)

GPIO.output(18,GPIO.HIGH)

time.sleep(.25)

GPIO.output(18,GPIO.LOW)

time.sleep(.35)

GPIO.output(23,GPIO.HIGH)

time.sleep(.25)

GPIO.output(23,GPIO.LOW)

time.sleep(.05)

GPIO.output(24,GPIO.HIGH)

time.sleep(.25)

GPIO.output(24,GPIO.LOW)

time.sleep(.35)

GPIO.output(16,GPIO.HIGH)

time.sleep(.25)

GPIO.output(16,GPIO.LOW)

time.sleep(.05)

GPIO.output(20,GPIO.HIGH)

time.sleep(.25)

GPIO.output(20,GPIO.LOW)

time.sleep(.35)

GPIO.output(21,GPIO.HIGH)

time.sleep(.25)

GPIO.output(21,GPIO.LOW)

time.sleep(.05)

GPIO.output(21,GPIO.HIGH)

time.sleep(.25)

GPIO.output(21,GPIO.LOW)

time.sleep(.95)
		
for x in range(3):
	GPIO.output(21,GPIO.HIGH)
	GPIO.output(20,GPIO.HIGH)
	GPIO.output(16,GPIO.HIGH)
	GPIO.output(25,GPIO.HIGH)
	GPIO.output(24,GPIO.HIGH)
	GPIO.output(23,GPIO.HIGH)
	GPIO.output(18,GPIO.HIGH)
		
	time.sleep(.5)
	
	GPIO.output(21,GPIO.LOW)
	GPIO.output(20,GPIO.LOW)
	GPIO.output(16,GPIO.LOW)
	GPIO.output(25,GPIO.LOW)
	GPIO.output(24,GPIO.LOW)
	GPIO.output(23,GPIO.LOW)
	GPIO.output(18,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(20, GPIO.HIGH)
	
	time.sleep(.15)

	GPIO.output(23,GPIO.HIGH)
	GPIO.output(20,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(20,GPIO.HIGH)
	GPIO.output(23,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(23,GPIO.HIGH)
	GPIO.output(20,GPIO.LOW)
		
	time.sleep(.05)
	
	GPIO.output(23,GPIO.LOW)
	
	time.sleep(.1)

GPIO.output(21,GPIO.HIGH)

time.sleep(.25)

GPIO.output(21,GPIO.LOW)

time.sleep(.05)

GPIO.output(21,GPIO.HIGH)

time.sleep(.25)

GPIO.output(21,GPIO.LOW)

time.sleep(.35)

GPIO.output(18,GPIO.HIGH)

time.sleep(.25)

GPIO.output(18,GPIO.LOW)

time.sleep(.05)

GPIO.output(18,GPIO.HIGH)

time.sleep(.25)

GPIO.output(18,GPIO.LOW)

time.sleep(.35)

GPIO.output(23,GPIO.HIGH)

time.sleep(.25)

GPIO.output(23,GPIO.LOW)

time.sleep(.05)

GPIO.output(24,GPIO.HIGH)

time.sleep(.25)

GPIO.output(24,GPIO.LOW)

time.sleep(.35)

GPIO.output(16,GPIO.HIGH)

time.sleep(.25)

GPIO.output(16,GPIO.LOW)

time.sleep(.05)

GPIO.output(20,GPIO.HIGH)

time.sleep(.25)

GPIO.output(20,GPIO.LOW)

time.sleep(.35)

GPIO.output(21,GPIO.HIGH)

time.sleep(.25)

GPIO.output(21,GPIO.LOW)

time.sleep(.05)

GPIO.output(21,GPIO.HIGH)

time.sleep(.25)

GPIO.output(21,GPIO.LOW)

time.sleep(.95)

for x in range(3):
	GPIO.output(21,GPIO.HIGH)
	GPIO.output(20,GPIO.HIGH)
	GPIO.output(16,GPIO.HIGH)
	GPIO.output(25,GPIO.HIGH)
	GPIO.output(24,GPIO.HIGH)
	GPIO.output(23,GPIO.HIGH)
	GPIO.output(18,GPIO.HIGH)
		
	time.sleep(.5)
	
	GPIO.output(21,GPIO.LOW)
	GPIO.output(20,GPIO.LOW)
	GPIO.output(16,GPIO.LOW)
	GPIO.output(25,GPIO.LOW)
	GPIO.output(24,GPIO.LOW)
	GPIO.output(23,GPIO.LOW)
	GPIO.output(18,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(20, GPIO.HIGH)
	
	time.sleep(.15)

	GPIO.output(23,GPIO.HIGH)
	GPIO.output(20,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(20,GPIO.HIGH)
	GPIO.output(23,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(23,GPIO.HIGH)
	GPIO.output(20,GPIO.LOW)
		
	time.sleep(.05)
	
	GPIO.output(23,GPIO.LOW)
	
	time.sleep(.1)

for x in range(4):
	GPIO.output(16,GPIO.HIGH)
	
	time.sleep(.25)
	
	GPIO.output(20,GPIO.HIGH)
	GPIO.output(16,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(16,GPIO.HIGH)
	GPIO.output(20,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(21,GPIO.HIGH)
	GPIO.output(16,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(21,GPIO.LOW)
	
	time.sleep(.25)
	
for x in range(4):
	GPIO.output(16,GPIO.HIGH)
	GPIO.output(18,GPIO.HIGH)
	
	time.sleep(.25)
	
	GPIO.output(20,GPIO.HIGH)
	GPIO.output(23,GPIO.HIGH)
	GPIO.output(16,GPIO.LOW)
	GPIO.output(18,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(16,GPIO.HIGH)
	GPIO.output(18,GPIO.HIGH)
	GPIO.output(20,GPIO.LOW)
	GPIO.output(23,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(21,GPIO.HIGH)
	GPIO.output(24,GPIO.HIGH)
	GPIO.output(16,GPIO.LOW)
	GPIO.output(18,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(21,GPIO.LOW)
	GPIO.output(24,GPIO.LOW)
	
	time.sleep(.25)
	
GPIO.output(18,GPIO.HIGH)

time.sleep(.15)

GPIO.output(18,GPIO.LOW)

time.sleep(.1)

GPIO.output(18,GPIO.HIGH)

time.sleep(.05)

GPIO.output(18,GPIO.LOW)

time.sleep(.1)

GPIO.output(18,GPIO.HIGH)

time.sleep(.15)

GPIO.output(18,GPIO.LOW)
GPIO.output(23,GPIO.HIGH)

time.sleep(.15)

GPIO.output(23,GPIO.LOW)
GPIO.output(24,GPIO.HIGH)

time.sleep(.15)

GPIO.output(25,GPIO.HIGH)
GPIO.output(24,GPIO.LOW)

time.sleep(.25)

GPIO.output(25,GPIO.LOW)

time.sleep(.1)

GPIO.output(25,GPIO.HIGH)

time.sleep(.05)

GPIO.output(25,GPIO.LOW)

time.sleep(.1)

GPIO.output(25,GPIO.HIGH)

time.sleep(.05)


GPIO.output(16,GPIO.HIGH)
GPIO.output(25,GPIO.LOW)

time.sleep(.15)

GPIO.output(20,GPIO.HIGH)
GPIO.output(16,GPIO.LOW)

time.sleep(.15)

GPIO.output(16,GPIO.HIGH)
GPIO.output(20,GPIO.LOW)

time.sleep(.15)

GPIO.output(20,GPIO.HIGH)
GPIO.output(16,GPIO.LOW)

time.sleep(.25)

GPIO.output(20,GPIO.LOW)

time.sleep(.1)

GPIO.output(20,GPIO.HIGH)

time.sleep(.05)

GPIO.output(20,GPIO.LOW)

time.sleep(.1)

GPIO.output(20,GPIO.HIGH)

time.sleep(.05)

GPIO.output(16,GPIO.HIGH)
GPIO.output(20,GPIO.LOW)

time.sleep(.15)

GPIO.output(25,GPIO.HIGH)
GPIO.output(16,GPIO.LOW)

time.sleep(.15)

GPIO.output(20,GPIO.HIGH)
GPIO.output(25,GPIO.LOW)

time.sleep(.15)

GPIO.output(20,GPIO.LOW)

time.sleep(.1)

GPIO.output(20,GPIO.HIGH)

time.sleep(.05)

GPIO.output(20,GPIO.HIGH)

time.sleep(.1)

GPIO.output(20,GPIO.LOW)

time.sleep(.05)

GPIO.output(20,GPIO.HIGH)

time.sleep(.2)

GPIO.output(20,GPIO.LOW)

time.sleep(.05)

for x in range(2):
	GPIO.output(18,GPIO.HIGH)
	
	time.sleep(.15)
	
	GPIO.output(23,GPIO.HIGH)
	GPIO.output(18,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(24,GPIO.HIGH)
	GPIO.output(23,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(25,GPIO.HIGH)
	GPIO.output(24,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(16,GPIO.HIGH)
	GPIO.output(25,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(20,GPIO.HIGH)
	GPIO.output(16,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(21,GPIO.HIGH)
	GPIO.output(20,GPIO.LOW)
	
	time.sleep(.05)
	
	GPIO.output(21,GPIO.LOW)
	
	time.sleep(.1)
	
	GPIO.output(21,GPIO.HIGH)
	
	time.sleep(.05)
	
	GPIO.output(21,GPIO.LOW)
	
	time.sleep(.1)
	
	GPIO.output(21,GPIO.HIGH)
	
	time.sleep(.15)
	
	GPIO.output(20,GPIO.HIGH)
	GPIO.output(21,GPIO.LOW)
	
	time.sleep(.25)
	
	GPIO.output(16,GPIO.HIGH)
	GPIO.output(20,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(16,GPIO.LOW)
	
	time.sleep(.1)

for x in range(3):
	GPIO.output(21,GPIO.HIGH)
	GPIO.output(23,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(20,GPIO.HIGH)
	GPIO.output(21,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(16,GPIO.HIGH)
	GPIO.output(20,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(25,GPIO.HIGH)
	GPIO.output(16,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(24,GPIO.HIGH)
	GPIO.output(25,GPIO.LOW)
	
	time.sleep(.15)
	
	GPIO.output(23,GPIO.HIGH)
	GPIO.output(24,GPIO.LOW)
	
	time.sleep(.15)
	
GPIO.output(21,GPIO.HIGH)
GPIO.output(23,GPIO.LOW)
	
time.sleep(.15)
	
GPIO.output(20,GPIO.HIGH)
GPIO.output(21,GPIO.LOW)
	
time.sleep(.15)
	
GPIO.output(16,GPIO.HIGH)
GPIO.output(20,GPIO.LOW)
	
time.sleep(.15)
	
GPIO.output(25,GPIO.HIGH)
GPIO.output(16,GPIO.LOW)
	
time.sleep(.15)
	
GPIO.output(24,GPIO.HIGH)
GPIO.output(25,GPIO.LOW)

time.sleep(.15)
	
GPIO.output(23,GPIO.HIGH)
GPIO.output(24,GPIO.LOW)
	
time.sleep(.05)

GPIO.output(23,GPIO.LOW)

time.sleep(.1)

for x in range(4):
	GPIO.output(21,GPIO.HIGH)

	time.sleep(.02)

	GPIO.output(20,GPIO.HIGH)

	time.sleep(.02)
	
	GPIO.output(16,GPIO.HIGH)
	
	time.sleep(.02)
	
	GPIO.output(25,GPIO.HIGH)
	
	time.sleep(.02)
	
	GPIO.output(24,GPIO.HIGH)
	
	time.sleep(.02)
	
	GPIO.output(23,GPIO.HIGH)
	
	time.sleep(.02)
	
	GPIO.output(18,GPIO.HIGH)
	
	time.sleep(.8)
	
	GPIO.output(18,GPIO.LOW)
	GPIO.output(23,GPIO.LOW)
	GPIO.output(24,GPIO.LOW)
	GPIO.output(25,GPIO.LOW)
	GPIO.output(16,GPIO.LOW)
	GPIO.output(20,GPIO.LOW)
	GPIO.output(21,GPIO.LOW)

	time.sleep(.03)

for x in range(20):
	GPIO.output(18,GPIO.HIGH)
	GPIO.output(23,GPIO.HIGH)
	GPIO.output(24,GPIO.HIGH)
	GPIO.output(25,GPIO.HIGH)
	GPIO.output(16,GPIO.HIGH)
	GPIO.output(20,GPIO.HIGH)
	GPIO.output(21,GPIO.HIGH)
	
	time.sleep(.08)
	
	GPIO.output(18,GPIO.LOW)
	GPIO.output(23,GPIO.LOW)
	GPIO.output(24,GPIO.LOW)
	GPIO.output(25,GPIO.LOW)
	GPIO.output(16,GPIO.LOW)
	GPIO.output(20,GPIO.LOW)
	GPIO.output(21,GPIO.LOW)
	
	time.sleep(.08)
