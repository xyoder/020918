﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Weather_yoderx.zip
{
    public partial class frmMEME : Form
    {
        //The purpose of this form and code are purely for humor and going the extra mile
        //code is from user JdMR on stackoverflow

        public frmMEME()
        {
            InitializeComponent();
        }

       
        private void BtnYes_Click(object sender, EventArgs e)
        {
            //closes this form
            this.Close();
        }

        private void FrmMEME_Load(object sender, EventArgs e)
        {
            //When this form loads, plays audio 
            //Idea from Alex R.
            //Code from user Evan Mulawski on stackoverflow
            //pulls wav file from the project resource to play
            System.IO.Stream str = Properties.Resources.WEATHER_BOY;
            System.Media.SoundPlayer snd = new System.Media.SoundPlayer(str);
            snd.Play();
        }
    }
}
