﻿namespace Weather_yoderx.zip
{
    partial class frmWeatherBoy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCity1 = new System.Windows.Forms.TextBox();
            this.txtCity2 = new System.Windows.Forms.TextBox();
            this.lblCity1 = new System.Windows.Forms.Label();
            this.lblCity2 = new System.Windows.Forms.Label();
            this.lstWeather = new System.Windows.Forms.ListBox();
            this.btnGet = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtCity1
            // 
            this.txtCity1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCity1.Location = new System.Drawing.Point(70, 6);
            this.txtCity1.Margin = new System.Windows.Forms.Padding(4);
            this.txtCity1.Name = "txtCity1";
            this.txtCity1.Size = new System.Drawing.Size(214, 44);
            this.txtCity1.TabIndex = 0;
            this.txtCity1.Text = "Fort Wayne";
            this.txtCity1.Validating += new System.ComponentModel.CancelEventHandler(this.TxtCity1_Validating);
            // 
            // txtCity2
            // 
            this.txtCity2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCity2.Location = new System.Drawing.Point(70, 46);
            this.txtCity2.Margin = new System.Windows.Forms.Padding(4);
            this.txtCity2.Name = "txtCity2";
            this.txtCity2.Size = new System.Drawing.Size(214, 44);
            this.txtCity2.TabIndex = 1;
            this.txtCity2.Text = "Auburn";
            this.txtCity2.Validating += new System.ComponentModel.CancelEventHandler(this.TxtCity2_Validating);
            // 
            // lblCity1
            // 
            this.lblCity1.AutoSize = true;
            this.lblCity1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCity1.Location = new System.Drawing.Point(13, 9);
            this.lblCity1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCity1.Name = "lblCity1";
            this.lblCity1.Size = new System.Drawing.Size(102, 36);
            this.lblCity1.TabIndex = 3;
            this.lblCity1.Text = "City 1:";
            // 
            // lblCity2
            // 
            this.lblCity2.AutoSize = true;
            this.lblCity2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCity2.Location = new System.Drawing.Point(13, 49);
            this.lblCity2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCity2.Name = "lblCity2";
            this.lblCity2.Size = new System.Drawing.Size(102, 36);
            this.lblCity2.TabIndex = 4;
            this.lblCity2.Text = "City 2:";
            // 
            // lstWeather
            // 
            this.lstWeather.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstWeather.FormattingEnabled = true;
            this.lstWeather.HorizontalScrollbar = true;
            this.lstWeather.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lstWeather.ItemHeight = 36;
            this.lstWeather.Location = new System.Drawing.Point(13, 80);
            this.lstWeather.Margin = new System.Windows.Forms.Padding(4);
            this.lstWeather.Name = "lstWeather";
            this.lstWeather.ScrollAlwaysVisible = true;
            this.lstWeather.Size = new System.Drawing.Size(505, 256);
            this.lstWeather.TabIndex = 10;
            // 
            // btnGet
            // 
            this.btnGet.BackColor = System.Drawing.Color.White;
            this.btnGet.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGet.Location = new System.Drawing.Point(13, 357);
            this.btnGet.Margin = new System.Windows.Forms.Padding(4);
            this.btnGet.Name = "btnGet";
            this.btnGet.Size = new System.Drawing.Size(129, 50);
            this.btnGet.TabIndex = 6;
            this.btnGet.Text = "&Get Weather";
            this.btnGet.UseVisualStyleBackColor = false;
            this.btnGet.Click += new System.EventHandler(this.BtnGet_Click);
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.White;
            this.btnReset.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(150, 357);
            this.btnReset.Margin = new System.Windows.Forms.Padding(4);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(129, 50);
            this.btnReset.TabIndex = 7;
            this.btnReset.Text = "&Reset";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.BtnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.White;
            this.btnExit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(287, 358);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(129, 50);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // frmWeatherBoy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(18F, 36F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(537, 419);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnGet);
            this.Controls.Add(this.lstWeather);
            this.Controls.Add(this.lblCity2);
            this.Controls.Add(this.lblCity1);
            this.Controls.Add(this.txtCity2);
            this.Controls.Add(this.txtCity1);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmWeatherBoy";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Get Weather";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCity1;
        private System.Windows.Forms.TextBox txtCity2;
        private System.Windows.Forms.Label lblCity1;
        private System.Windows.Forms.Label lblCity2;
        private System.Windows.Forms.ListBox lstWeather;
        private System.Windows.Forms.Button btnGet;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
    }
}

