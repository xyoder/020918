﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;  // Added to use the XDocument class

namespace Weather_yoderx.zip
{
    public partial class frmWeatherBoy : Form
    {
        /*
         * Name:Xavier Yoder
         * Date: October 10, 2019
         * Purpose: give the user data about the weather for two cities of their choice
         */


        /*Note: there are default values for city1 and city2 so that the user can escape the 
        *program without issues with validation.
        */

        //Global variable declaration
        string city1, city2;
        string tempCity1, tempCity2, humidityCity1, humidityCity2, pressureCity1, pressureCity2;
        string unitsCity1, unitsCity2;

        double c1Temp, c2Temp;
        double c1Humidity = 0, c2Humidity = 0;
        double c1Pressure = 0, c2Pressure = 0;


        // Enter your API key here.
        // Get an API key by making a free account at:
        //      http://home.openweathermap.org/users/sign_in
        private const string API_KEY = "61ad9d42b5bf4553aba08ad86af729ee";

        // Query URLs. Replace @LOC@ with the location.
        private const string CurrentUrl =
            "http://api.openweathermap.org/data/2.5/weather?" +
            "q=@LOC@&mode=xml&units=imperial&APPID=" + API_KEY;

        public frmWeatherBoy()
        {
            InitializeComponent();
           
        }

        public bool yesButton;

        static private void GetConditions(string city, ref string temp, ref string units, ref string humidity, ref string pressure)
        {
            // Compose the query URL.
            string url = CurrentUrl.Replace("@LOC@", city);

            // Load the XDocument class with XML file for the requested city
            XDocument X = XDocument.Load(url);

            // Extract the temperature data from the XML file.
            XElement tempData = X.Element("current").Element("temperature");
            XElement humidityData = X.Element("current").Element("humidity");
            XElement pressureData = X.Element("current").Element("pressure");

            // Extract the first attribute which is the temperature and the last which is the units
            temp = tempData.FirstAttribute.ToString();
            units = tempData.LastAttribute.ToString();
            humidity = humidityData.FirstAttribute.ToString();
            pressure = pressureData.FirstAttribute.ToString();
        }

        private void TxtCity1_Validating(object sender, CancelEventArgs e)
        {
            //check to see if the user put in an actual city for input for city1
            try
            {
                city1 = txtCity1.Text;
                GetConditions(city1, ref tempCity1, ref unitsCity1, ref humidityCity1, ref pressureCity1);
            }
            catch
            {
                //if input for city1 isn't a city, clear the textbox for city1, show a messagebox telling the
                //user there is an error and set the focus to that textbox
                txtCity1.Clear();
                MessageBox.Show("City 1 must be an actual city");
                txtCity1.Focus();
            }
        }

        private void BtnReset_Click(object sender, EventArgs e)
        {
            //Resets the textboxes, listbox, and values for city1 and city2
            city1 = "";
            city2 = "";
            txtCity1.Text = "Fort Wayne";
            txtCity2.Text = "Auburn";
            lstWeather.Items.Clear();
            txtCity1.Focus();
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }

        private void BtnGet_Click(object sender, EventArgs e)
        {
            //Get the user's input for city 1
            city1 = txtCity1.Text;

            //Get the current weather for city1
            GetConditions(city1, ref tempCity1, ref unitsCity1, ref humidityCity1, ref pressureCity1);


            //Clean up data
            tempCity1 = tempCity1.Remove(0, 7);
            tempCity1 = tempCity1.TrimEnd('"');
            c1Temp = double.Parse(tempCity1);

            unitsCity1 = unitsCity1.Remove(0, 6);
            unitsCity1 = unitsCity1.TrimEnd('"');

            humidityCity1 = humidityCity1.Remove(0, 7);
            humidityCity1 = humidityCity1.TrimEnd('"');
            c1Humidity = double.Parse(humidityCity1);

            pressureCity1 = pressureCity1.Remove(0, 7);
            pressureCity1 = pressureCity1.TrimEnd('"');
            c1Pressure = double.Parse(pressureCity1);

            //Get the user's input for city 2
            city2 = txtCity2.Text;

            //Get the current weather for city2
            GetConditions(city2, ref tempCity2, ref unitsCity2, ref humidityCity2, ref pressureCity2);


            //Clean up data
            tempCity2 = tempCity2.Remove(0, 7);
            tempCity2 = tempCity2.TrimEnd('"');
            c2Temp = double.Parse(tempCity2);

            unitsCity2 = unitsCity2.Remove(0, 6);
            unitsCity2 = unitsCity2.TrimEnd('"');

            humidityCity2 = (humidityCity2.Remove(0, 7)).TrimEnd('"');
            c2Humidity = double.Parse(humidityCity2);

            c2Pressure = double.Parse((pressureCity2.Remove(0, 7)).TrimEnd('"'));


            //before outputting data, create an instance of a second form with a meme
            //as mentioned in the code for the form this code creates, it is from an outside source
            frmMEME m = new frmMEME();
            m.ShowDialog();


            //enables the horizontal scrollbar
            lstWeather.HorizontalScrollbar = true;

            //Output weather information for both cities to the user
            lstWeather.Items.Add($"{city1}:   " +
                                 $"temp: {c1Temp:N2}   " +
                                 $"units: {unitsCity1}   " +
                                 $"humidity: {c1Humidity:N0}   " +
                                 $"pressure: {c1Pressure:N0}   ");

            lstWeather.Items.Add("");

            lstWeather.Items.Add($"{city2}:   " +
                              $"temp: {c2Temp:N2}   " +
                              $"   units: {unitsCity2}   " +
                              $"humidity: {c2Humidity:N0}   " +
                              $"pressure: {c2Pressure:N0}   ");

            lstWeather.Items.Add("");

            //Compare temperature of the two cities
            lstWeather.Items.Add($"*** Is {city1} hotter, equal to, or cooler than {city2}? ***");

            if (c1Temp > c2Temp)
            {
                lstWeather.Items.Add($"{city1} is hotter than {city2}.");
            }
            else
            {
                if (c1Temp == c2Temp)
                {
                    lstWeather.Items.Add($"{city1} has the same temperature as {city2}.");
                }
                else
                {
                    lstWeather.Items.Add($"{city1} is cooler than {city2}.");
                }
            }

            lstWeather.Items.Add("");

            /*
            * Determine humidty range for city1
            *  Less than or equal to 50
            *  between 51 and 100
            *  greater than or equal to 101
            */

            lstWeather.Items.Add($"*** {city1} humidity range ***");

            if (c1Humidity <= 50)
                lstWeather.Items.Add($"{city1}'s humidty is less than or equal to 50.");
            else if (c1Humidity > 50 && c1Humidity <= 100)
                lstWeather.Items.Add($"{city1}'s humidity is between 51 and 100.");
            else
                lstWeather.Items.Add($"{city1}'s humidity is greater than 100.");

            lstWeather.Items.Add("");

            /*
            * Determine humidty range for city2
            *  Less than or equal to 50
            *  between 51 and 100
            *  greater than or equal to 101
            */

            lstWeather.Items.Add($"*** {city2} humidity range ***");

            if (c2Humidity <= 50)
                lstWeather.Items.Add($"{city2}'s humidty is less than or equal to 50.");
            else if (c2Humidity > 50 && c2Humidity <= 100)
                lstWeather.Items.Add($"{city2}'s humidity is between 51 and 100.");
            else
                lstWeather.Items.Add($"{city2}'s humidity is greater than 100.");

            lstWeather.Items.Add("");

            /*
            * Determine pressure range for city1
            *  Less than or equal to 500
            *  between 501 and 1000
            *  greater than or equal to 1001
            */

            lstWeather.Items.Add($"*** {city1} pressure range ***");

            if (c1Pressure <= 500)
                lstWeather.Items.Add($"{city1}'s pressure is less than or equal to 500.");
            else if (c1Pressure > 500 && c1Pressure <= 1000)
                lstWeather.Items.Add($"{city1}'s pressure is between 501 and 1000.");
            else
                lstWeather.Items.Add($"{city1}'s pressure is greater than 1000.");

            //just because it will bug me, I will determine pressure range for city2 just like city1

            lstWeather.Items.Add("");

            lstWeather.Items.Add($"*** {city2} pressure range ***");

            if (c2Pressure <= 500)
                lstWeather.Items.Add($"{city2}'s pressure is less than or equal to 500.");
            else if (c2Pressure > 500 && c2Pressure <= 1000)
                lstWeather.Items.Add($"{city2}'s pressure is between 501 and 1000.");
            else
                lstWeather.Items.Add($"{city2}'s pressure is greater than 1000.");

            //add a blank line to separate two or more outputs if the user doesn't reset
            lstWeather.Items.Add("");
        }

        private void TxtCity2_Validating(object sender, CancelEventArgs e)
        {
            //check to see if the user put in an actual city for input for city2
            try
            {
                city2 = txtCity2.Text;
                GetConditions(city2, ref tempCity2, ref unitsCity2, ref humidityCity2, ref pressureCity2);
            }
            catch
            {
                //if input for city2 isn't a city, clear the textbox for city2, show a messagebox telling the user there is an error and set the focus to that textbox
                txtCity2.Clear();
                MessageBox.Show("City 2 must be an actual city");
                txtCity2.Focus();
            }
        }
    }
}
