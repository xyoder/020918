﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MenuSystem_YoderX
{

         /*
         * Name: Xavier Yoder
         * Date: October 6, 2019
         * Purpose: calculate damage for a game
         */
    public partial class frmBattleDamage : Form
    {

        //global variable declaration
        decimal wDamage, wSpeed, aPower, dMultiplier, damage;

        public frmBattleDamage()
        {
            InitializeComponent();
        }

        private void TxtAttackPower_Validating(object sender, CancelEventArgs e)
        {
            //runs the created method for attack power
            aPower = NumberValidation(txtAttackPower, 1, 10);
        }

        private void TxtWeaponSpeed_Validating(object sender, CancelEventArgs e)
        {
            //runs the created method for weapon speed
            wSpeed = NumberValidation(txtWeaponSpeed, 1, 5);
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            //close the form
            this.Close();
        }

        private void BtnReset_Click(object sender, EventArgs e)
        {
            //Reset the form
            txtAttackPower.Text = txtDamage.Text = txtMultiplier.Text = txtWeaponDamage.Text = txtWeaponSpeed.Text = "0";
        }

        //make a method that will open a form based on which radio button is clicked
        public void DisplayNewForm()
        {

            //Determine which radio button is checked and open the form correlated with it
            if (rdoFactorials.Checked)
            {
                frmFactorial newForm = new frmFactorial();
                newForm.Show();
            }
            else if (rdoQuadratic.Checked)
            {
                frmQuadratic newForm = new frmQuadratic();
                newForm.Show();
            }
            else if (rdoBMI.Checked)
            {
                frmBMI newForm = new frmBMI();
                newForm.Show();
            }
            else if (rdoDistance.Checked)
            {
                frmDistance newForm = new frmDistance();
                newForm.Show();
            }
        }

        private void BtnDisplay_Click(object sender, EventArgs e)
        {
            //display a new form from this form
            DisplayNewForm();
            this.Close();
        }


        private void TxtMultiplier_Validating(object sender, CancelEventArgs e)
        {
            //use the created method for damage multiplier
            dMultiplier = NumberValidation(txtMultiplier, 1, 4);
        }

        //creating a method for number validation
        private decimal NumberValidation(TextBox txt2Check, int lowRange, int highRange)
        {
            //Validate the user's input for variables as a number within range
            decimal numberGained;
            try
            {
                numberGained = Convert.ToDecimal(txt2Check.Text);
            }
            catch
            {
                MessageBox.Show("Input for weapon damage must be a number.");
                txt2Check.Text = lowRange.ToString();
                txt2Check.Focus();
            }

            //convert number in the textbox to decimal variable
            numberGained = Convert.ToDecimal(txt2Check.Text);

            //catch the number to make sure it's in range
            if (numberGained < lowRange)
            {
                MessageBox.Show($"Number must be greater than or equal to {lowRange}");
                txt2Check.Text = lowRange.ToString();
                txt2Check.Focus();
            }
            else if (numberGained > highRange)
            {
                MessageBox.Show($"Number must be less than or equal to {lowRange}");
                txt2Check.Text = lowRange.ToString();
                txt2Check.Focus();
            }
            
            //return decimal for variable
            return numberGained;
        }

        

        private void BtnCalculate_Click(object sender, EventArgs e)
        {
            //Calculate and output the battle damage
            damage = (wDamage + aPower / 3.5m * wSpeed) * dMultiplier;
            txtDamage.Text = damage.ToString("N2");
        }

        private void TxtWeaponDamage_Validating(object sender, CancelEventArgs e)
        {
            //run the created method for weapon damage
            wDamage = NumberValidation(txtWeaponDamage, 10, 500);
        }
    }
}
