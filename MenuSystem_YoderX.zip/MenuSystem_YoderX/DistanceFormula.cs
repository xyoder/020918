﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MenuSystem_YoderX
{
    //Name: Xavier Yoder
    //Purpose: Calculate and display distance based on user input of X1, X2, Y1, Y2
    //Date: November 7, 2019

    public partial class frmDistance : Form
    {
        //declare global variables
        Double  X1, X2, Y1, Y2;

        public frmDistance()
        {
            InitializeComponent();
        }

        //make a method that will open a form based on which radio button is clicked
        public void DisplayNewForm()
        {

            //Determine which radio button is checked and open the form correlated with it
            if (rdoBattle.Checked)
            {
                frmBattleDamage newForm = new frmBattleDamage();
                newForm.Show();
            }
            else if (rdoFactorials.Checked)
            {
                frmFactorial newForm = new frmFactorial();
                newForm.Show();
            }
            else if (rdoQuadratic.Checked)
            {
                frmQuadratic newForm = new frmQuadratic();
                newForm.Show();
            }
            else if (rdoBMI.Checked)
            {
                frmBMI newForm = new frmBMI();
                newForm.Show();
            }
        }

        private void BtnDisplay_Click(object sender, EventArgs e)
        {
            //display a new form from this form
            DisplayNewForm();
            this.Close();
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            //close the form
            this.Close();
        }

        private void BtnReset_Click(object sender, EventArgs e)
        {
            //reset the textboxes
            txtAnswer.Text = "";
            txtX1.Text = txtX2.Text = txtY1.Text = txtY2.Text = "0";
        }

        private void TxtY1_Validating(object sender, CancelEventArgs e)
        {
            //Get and validate the y1 coordinate
            Y1 = CoordinateValidation(txtY1);
        }

        private void TxtX2_Validating(object sender, CancelEventArgs e)
        {
            //get and validate the x2 coordinate
            X2 = CoordinateValidation(txtX2);
        }

        private void TxtY2_Validating(object sender, CancelEventArgs e)
        {
            //get and validate the y2 coordinate
            Y2 = CoordinateValidation(txtY2);
        }

        //create a validation method
        private Double CoordinateValidation(TextBox txt2Check)
        {
            //create return variable
            Double coordinateToReturn;

            //validate that the input is a number
            try
            {
                coordinateToReturn = Double.Parse(txt2Check.Text);
            }
            catch
            {
                MessageBox.Show("Input must be a number");
                txt2Check.Text = "0";
                txt2Check.Focus();
            }

            //return the coordinate value
            coordinateToReturn = Double.Parse(txt2Check.Text);

            return coordinateToReturn;
        }

        private void BtnCompute_Click(object sender, EventArgs e)
        {
            //create answer variable 
            Double answer;

            //compute and output the distance
            answer = Math.Sqrt((Math.Pow(X1 - X2, 2) + Math.Pow(Y1 - Y2, 2)));

            txtAnswer.Text = $"{answer}";
        }

        private void TxtX1_Validating(object sender, CancelEventArgs e)
        {
            //get and validate the x1 coordinate
            X1 = CoordinateValidation(txtX1);
        }
    }
}
