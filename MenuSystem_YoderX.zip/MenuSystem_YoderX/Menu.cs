﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MenuSystem_YoderX
{

    //Name: Xavier Yoder
    //Date: 11/4/2019
    //purpose: create a program that opens up different programs from previous assignments and use modularization
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
        }

        //Modularization 1
        //make a public method that will open a form based on which radio button is clicked
        public void DisplayNewForm()
        {

            //Determine which radio button is checked and open the form correlated with it
            if (rdoBattle.Checked)
            {
                frmBattleDamage newForm = new frmBattleDamage();
                newForm.Show();
            }
            else if (rdoFactorials.Checked)
            {
                frmFactorial newForm = new frmFactorial();
                newForm.Show();
            }
            else if (rdoQuadratic.Checked)
            {
                frmQuadratic newForm = new frmQuadratic();
                newForm.Show();
            }
            else if (rdoBMI.Checked)
            {
                frmBMI newForm = new frmBMI();
                newForm.Show();
            }
            else if (rdoDistance.Checked)
            {
                frmDistance newForm = new frmDistance();
                newForm.Show();
            }
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            //close the form
            this.Close();
        }

        private void BtnDisplay_Click(object sender, EventArgs e)
        {
            DisplayNewForm();
        }

    }
}
