﻿namespace MenuSystem_YoderX
{
    partial class frmFactorial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEnter = new System.Windows.Forms.Label();
            this.lblFactorial = new System.Windows.Forms.Label();
            this.mskNumber = new System.Windows.Forms.MaskedTextBox();
            this.lblAnswer = new System.Windows.Forms.Label();
            this.btnCompute = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.grpSelect = new System.Windows.Forms.GroupBox();
            this.rdoBattle = new System.Windows.Forms.RadioButton();
            this.rdoDistance = new System.Windows.Forms.RadioButton();
            this.rdoQuadratic = new System.Windows.Forms.RadioButton();
            this.rdoBMI = new System.Windows.Forms.RadioButton();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.grpSelect.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblEnter
            // 
            this.lblEnter.AutoSize = true;
            this.lblEnter.Location = new System.Drawing.Point(12, 9);
            this.lblEnter.Name = "lblEnter";
            this.lblEnter.Size = new System.Drawing.Size(167, 25);
            this.lblEnter.TabIndex = 0;
            this.lblEnter.Text = "Enter An Integer";
            // 
            // lblFactorial
            // 
            this.lblFactorial.AutoSize = true;
            this.lblFactorial.Location = new System.Drawing.Point(84, 61);
            this.lblFactorial.Name = "lblFactorial";
            this.lblFactorial.Size = new System.Drawing.Size(95, 25);
            this.lblFactorial.TabIndex = 1;
            this.lblFactorial.Text = "Factorial";
            // 
            // mskNumber
            // 
            this.mskNumber.Location = new System.Drawing.Point(185, 6);
            this.mskNumber.Mask = "00";
            this.mskNumber.Name = "mskNumber";
            this.mskNumber.Size = new System.Drawing.Size(100, 31);
            this.mskNumber.TabIndex = 2;
            this.mskNumber.ValidatingType = typeof(int);
            // 
            // lblAnswer
            // 
            this.lblAnswer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblAnswer.Location = new System.Drawing.Point(185, 61);
            this.lblAnswer.Name = "lblAnswer";
            this.lblAnswer.Size = new System.Drawing.Size(424, 30);
            this.lblAnswer.TabIndex = 3;
            // 
            // btnCompute
            // 
            this.btnCompute.Location = new System.Drawing.Point(12, 118);
            this.btnCompute.Name = "btnCompute";
            this.btnCompute.Size = new System.Drawing.Size(128, 84);
            this.btnCompute.TabIndex = 4;
            this.btnCompute.Text = "Compute";
            this.btnCompute.UseVisualStyleBackColor = true;
            this.btnCompute.Click += new System.EventHandler(this.BtnCompute_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(249, 118);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(128, 84);
            this.btnReset.TabIndex = 5;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.BtnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(481, 118);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(128, 84);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // grpSelect
            // 
            this.grpSelect.Controls.Add(this.rdoBattle);
            this.grpSelect.Controls.Add(this.rdoDistance);
            this.grpSelect.Controls.Add(this.rdoQuadratic);
            this.grpSelect.Controls.Add(this.rdoBMI);
            this.grpSelect.Location = new System.Drawing.Point(12, 208);
            this.grpSelect.Name = "grpSelect";
            this.grpSelect.Size = new System.Drawing.Size(575, 101);
            this.grpSelect.TabIndex = 7;
            this.grpSelect.TabStop = false;
            this.grpSelect.Text = "Select a Different Type of Calculator";
            // 
            // rdoBattle
            // 
            this.rdoBattle.AutoSize = true;
            this.rdoBattle.Location = new System.Drawing.Point(242, 65);
            this.rdoBattle.Name = "rdoBattle";
            this.rdoBattle.Size = new System.Drawing.Size(287, 29);
            this.rdoBattle.TabIndex = 4;
            this.rdoBattle.TabStop = true;
            this.rdoBattle.Text = "Battle Damage Calculator";
            this.rdoBattle.UseVisualStyleBackColor = true;
            // 
            // rdoDistance
            // 
            this.rdoDistance.AutoSize = true;
            this.rdoDistance.Location = new System.Drawing.Point(6, 65);
            this.rdoDistance.Name = "rdoDistance";
            this.rdoDistance.Size = new System.Drawing.Size(230, 29);
            this.rdoDistance.TabIndex = 2;
            this.rdoDistance.TabStop = true;
            this.rdoDistance.Text = "Distance Calculator";
            this.rdoDistance.UseVisualStyleBackColor = true;
            // 
            // rdoQuadratic
            // 
            this.rdoQuadratic.AutoSize = true;
            this.rdoQuadratic.Location = new System.Drawing.Point(242, 30);
            this.rdoQuadratic.Name = "rdoQuadratic";
            this.rdoQuadratic.Size = new System.Drawing.Size(323, 29);
            this.rdoQuadratic.TabIndex = 1;
            this.rdoQuadratic.TabStop = true;
            this.rdoQuadratic.Text = "Quadratic Formula Calculator";
            this.rdoQuadratic.UseVisualStyleBackColor = true;
            // 
            // rdoBMI
            // 
            this.rdoBMI.AutoSize = true;
            this.rdoBMI.Location = new System.Drawing.Point(6, 30);
            this.rdoBMI.Name = "rdoBMI";
            this.rdoBMI.Size = new System.Drawing.Size(183, 29);
            this.rdoBMI.TabIndex = 0;
            this.rdoBMI.TabStop = true;
            this.rdoBMI.Text = "BMI Calculator";
            this.rdoBMI.UseVisualStyleBackColor = true;
            // 
            // btnDisplay
            // 
            this.btnDisplay.Location = new System.Drawing.Point(89, 315);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(410, 80);
            this.btnDisplay.TabIndex = 12;
            this.btnDisplay.Text = "Display New Calculator";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.BtnDisplay_Click);
            // 
            // frmFactorial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(633, 410);
            this.Controls.Add(this.btnDisplay);
            this.Controls.Add(this.grpSelect);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnCompute);
            this.Controls.Add(this.lblAnswer);
            this.Controls.Add(this.mskNumber);
            this.Controls.Add(this.lblFactorial);
            this.Controls.Add(this.lblEnter);
            this.Name = "frmFactorial";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Factorial";
            this.grpSelect.ResumeLayout(false);
            this.grpSelect.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEnter;
        private System.Windows.Forms.Label lblFactorial;
        private System.Windows.Forms.MaskedTextBox mskNumber;
        private System.Windows.Forms.Label lblAnswer;
        private System.Windows.Forms.Button btnCompute;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.GroupBox grpSelect;
        private System.Windows.Forms.RadioButton rdoBattle;
        private System.Windows.Forms.RadioButton rdoDistance;
        private System.Windows.Forms.RadioButton rdoQuadratic;
        private System.Windows.Forms.RadioButton rdoBMI;
        private System.Windows.Forms.Button btnDisplay;
    }
}