﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MenuSystem_YoderX
{

    //Name: Xavier Yoder
    //Purpose: to calculate the factorial for a number
    //Date: November 4, 2019
    public partial class frmFactorial : Form
    {
        //variable declaration
        int number;

        public frmFactorial()
        {
            InitializeComponent();
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            //Close the Form
            this.Close();
        }

        private void BtnReset_Click(object sender, EventArgs e)
        {
            //Reset the form
            mskNumber.Clear();
            mskNumber.Focus();
            mskNumber.Clear();
            lblAnswer.Text = "";
        }

        private void BtnCompute_Click(object sender, EventArgs e)
        {
            //output the factorial
            number = int.Parse(mskNumber.Text);
            lblAnswer.Text = $"{FactorialComputation(number)}";
        }

        //create a method for calculating the factorial
        private decimal FactorialComputation(int number)
        {
            //calculate the factorial
            //make variable for factorial amount
            decimal factorial = 1;
            for (int counter = 1; counter <= number; counter++)
            {
                factorial *= counter;
            }

            //return the value for the factorial
            return factorial;
        }

        //make a method that will open a form based on which radio button is clicked
        public void DisplayNewForm()
        {

            //Determine which radio button is checked and open the form correlated with it
            if (rdoBattle.Checked)
            {
                frmBattleDamage newForm = new frmBattleDamage();
                newForm.Show();
            }
            else if (rdoQuadratic.Checked)
            {
                frmQuadratic newForm = new frmQuadratic();
                newForm.Show();
            }
            else if (rdoBMI.Checked)
            {
                frmBMI newForm = new frmBMI();
                newForm.Show();
            }
            else if (rdoDistance.Checked)
            {
                frmDistance newForm = new frmDistance();
                newForm.Show();
            }
        }

        private void BtnDisplay_Click(object sender, EventArgs e)
        {
            //display a new form from this form
            DisplayNewForm();
            this.Close();
        }
    }
}
