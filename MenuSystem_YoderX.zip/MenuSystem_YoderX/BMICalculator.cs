﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MenuSystem_YoderX
{
    //Name: Xavier Yoder
    //Purpose: to calculate a person's BMI based on the info given
    //Date: November 7, 2019
    public partial class frmBMI : Form
    {
        //gloabl variable declaration
        decimal height, weight, bmi;
        public frmBMI()
        {
            InitializeComponent();
        }

        private void BtnReset_Click(object sender, EventArgs e)
        {
            //Reset the form
            txtBMI.Text = mtxHeight.Text = mtxWeight.Text = "";
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            //Close this form
            this.Close();
        }

        //method validating that the user put something into the masked textboxes
        private void NumberValidation(MaskedTextBox msk2check)
        {
            //create test variable
            decimal test;

            //validate that the user put some sort of number in for the input
            try
            {
                test = decimal.Parse(msk2check.Text);
            }
            catch
            {
                MessageBox.Show("You must enter a number");
                msk2check.Focus();
                msk2check.Text = "1";
            }

            //check to see if the number is positive
            test = decimal.Parse(msk2check.Text);

            if (test <= 0)
            {
                MessageBox.Show($"You must enter a positve number");
                msk2check.Focus();
                msk2check.Text = "1";
            }
        }

        private void MtxHeight_Validating(object sender, CancelEventArgs e)
        {
            //used the created method for height
            NumberValidation(mtxHeight);
        }

        //make a method that will open a form based on which radio button is clicked
        public void DisplayNewForm()
        {

            //Determine which radio button is checked and open the form correlated with it
            if (rdoBattle.Checked)
            {
                frmBattleDamage newForm = new frmBattleDamage();
                newForm.Show();
            }
            else if (rdoFactorials.Checked)
            {
                frmFactorial newForm = new frmFactorial();
                newForm.Show();
            }
            else if (rdoQuadratic.Checked)
            {
                frmQuadratic newForm = new frmQuadratic();
                newForm.Show();
            }
            else if (rdoDistance.Checked)
            {
                frmDistance newForm = new frmDistance();
                newForm.Show();
            }
        }
        private void BtnDisplay_Click(object sender, EventArgs e)
        {
            //display a new form from this form
            DisplayNewForm();
            this.Close();
        }

        private void BtnCalculate_Click(object sender, EventArgs e)
        {
            //grab the number for weight and height
            weight = Decimal.Parse(mtxWeight.Text);
            height = Decimal.Parse(mtxHeight.Text);

            //Calculate and output the BMI
            bmi = weight / (height * height);

            //Output the BMI
            txtBMI.Text = $"{bmi:N3}";
        }

        private void MtxWeight_Validating(object sender, CancelEventArgs e)
        {
            //used the created method for weight
            NumberValidation(mtxWeight);
        }
    }
}
