﻿namespace MenuSystem_YoderX
{
    partial class frmBMI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblWeight = new System.Windows.Forms.Label();
            this.lblHeight = new System.Windows.Forms.Label();
            this.lblBMI = new System.Windows.Forms.Label();
            this.mtxWeight = new System.Windows.Forms.MaskedTextBox();
            this.mtxHeight = new System.Windows.Forms.MaskedTextBox();
            this.txtBMI = new System.Windows.Forms.TextBox();
            this.grpSelect = new System.Windows.Forms.GroupBox();
            this.rdoBattle = new System.Windows.Forms.RadioButton();
            this.rdoFactorials = new System.Windows.Forms.RadioButton();
            this.rdoDistance = new System.Windows.Forms.RadioButton();
            this.rdoQuadratic = new System.Windows.Forms.RadioButton();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.grpSelect.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(17, 117);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(162, 80);
            this.btnCalculate.TabIndex = 3;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.BtnCalculate_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(252, 18);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(162, 80);
            this.btnReset.TabIndex = 4;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.BtnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(252, 117);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(162, 80);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // lblWeight
            // 
            this.lblWeight.AutoSize = true;
            this.lblWeight.Location = new System.Drawing.Point(12, 9);
            this.lblWeight.Name = "lblWeight";
            this.lblWeight.Size = new System.Drawing.Size(85, 25);
            this.lblWeight.TabIndex = 6;
            this.lblWeight.Text = "Weight:";
            // 
            // lblHeight
            // 
            this.lblHeight.AutoSize = true;
            this.lblHeight.Location = new System.Drawing.Point(17, 46);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.Size = new System.Drawing.Size(80, 25);
            this.lblHeight.TabIndex = 7;
            this.lblHeight.Text = "Height:";
            // 
            // lblBMI
            // 
            this.lblBMI.AutoSize = true;
            this.lblBMI.Location = new System.Drawing.Point(27, 83);
            this.lblBMI.Name = "lblBMI";
            this.lblBMI.Size = new System.Drawing.Size(55, 25);
            this.lblBMI.TabIndex = 8;
            this.lblBMI.Text = "BMI:";
            // 
            // mtxWeight
            // 
            this.mtxWeight.Location = new System.Drawing.Point(103, 6);
            this.mtxWeight.Name = "mtxWeight";
            this.mtxWeight.Size = new System.Drawing.Size(143, 31);
            this.mtxWeight.TabIndex = 0;
            this.mtxWeight.Text = "1";
            this.mtxWeight.Validating += new System.ComponentModel.CancelEventHandler(this.MtxWeight_Validating);
            // 
            // mtxHeight
            // 
            this.mtxHeight.Location = new System.Drawing.Point(103, 43);
            this.mtxHeight.Name = "mtxHeight";
            this.mtxHeight.Size = new System.Drawing.Size(143, 31);
            this.mtxHeight.TabIndex = 1;
            this.mtxHeight.Text = "1";
            this.mtxHeight.Validating += new System.ComponentModel.CancelEventHandler(this.MtxHeight_Validating);
            // 
            // txtBMI
            // 
            this.txtBMI.Enabled = false;
            this.txtBMI.Location = new System.Drawing.Point(103, 80);
            this.txtBMI.Name = "txtBMI";
            this.txtBMI.Size = new System.Drawing.Size(143, 31);
            this.txtBMI.TabIndex = 9;
            // 
            // grpSelect
            // 
            this.grpSelect.Controls.Add(this.rdoBattle);
            this.grpSelect.Controls.Add(this.rdoFactorials);
            this.grpSelect.Controls.Add(this.rdoDistance);
            this.grpSelect.Controls.Add(this.rdoQuadratic);
            this.grpSelect.Location = new System.Drawing.Point(17, 227);
            this.grpSelect.Name = "grpSelect";
            this.grpSelect.Size = new System.Drawing.Size(405, 176);
            this.grpSelect.TabIndex = 10;
            this.grpSelect.TabStop = false;
            this.grpSelect.Text = "Select a Different Type of Calculator";
            // 
            // rdoBattle
            // 
            this.rdoBattle.AutoSize = true;
            this.rdoBattle.Location = new System.Drawing.Point(6, 135);
            this.rdoBattle.Name = "rdoBattle";
            this.rdoBattle.Size = new System.Drawing.Size(287, 29);
            this.rdoBattle.TabIndex = 4;
            this.rdoBattle.TabStop = true;
            this.rdoBattle.Text = "Battle Damage Calculator";
            this.rdoBattle.UseVisualStyleBackColor = true;
            // 
            // rdoFactorials
            // 
            this.rdoFactorials.AutoSize = true;
            this.rdoFactorials.Location = new System.Drawing.Point(6, 65);
            this.rdoFactorials.Name = "rdoFactorials";
            this.rdoFactorials.Size = new System.Drawing.Size(217, 29);
            this.rdoFactorials.TabIndex = 3;
            this.rdoFactorials.TabStop = true;
            this.rdoFactorials.Text = "Factorial Calclator";
            this.rdoFactorials.UseVisualStyleBackColor = true;
            // 
            // rdoDistance
            // 
            this.rdoDistance.AutoSize = true;
            this.rdoDistance.Location = new System.Drawing.Point(6, 30);
            this.rdoDistance.Name = "rdoDistance";
            this.rdoDistance.Size = new System.Drawing.Size(230, 29);
            this.rdoDistance.TabIndex = 2;
            this.rdoDistance.TabStop = true;
            this.rdoDistance.Text = "Distance Calculator";
            this.rdoDistance.UseVisualStyleBackColor = true;
            // 
            // rdoQuadratic
            // 
            this.rdoQuadratic.AutoSize = true;
            this.rdoQuadratic.Location = new System.Drawing.Point(6, 100);
            this.rdoQuadratic.Name = "rdoQuadratic";
            this.rdoQuadratic.Size = new System.Drawing.Size(323, 29);
            this.rdoQuadratic.TabIndex = 1;
            this.rdoQuadratic.TabStop = true;
            this.rdoQuadratic.Text = "Quadratic Formula Calculator";
            this.rdoQuadratic.UseVisualStyleBackColor = true;
            // 
            // btnDisplay
            // 
            this.btnDisplay.Location = new System.Drawing.Point(12, 409);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(410, 80);
            this.btnDisplay.TabIndex = 11;
            this.btnDisplay.Text = "Display New Calculator";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.BtnDisplay_Click);
            // 
            // frmBMI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(425, 503);
            this.Controls.Add(this.btnDisplay);
            this.Controls.Add(this.grpSelect);
            this.Controls.Add(this.txtBMI);
            this.Controls.Add(this.mtxHeight);
            this.Controls.Add(this.mtxWeight);
            this.Controls.Add(this.lblBMI);
            this.Controls.Add(this.lblHeight);
            this.Controls.Add(this.lblWeight);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnCalculate);
            this.Name = "frmBMI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BMI Calculator";
            this.grpSelect.ResumeLayout(false);
            this.grpSelect.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblWeight;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.Label lblBMI;
        private System.Windows.Forms.MaskedTextBox mtxWeight;
        private System.Windows.Forms.MaskedTextBox mtxHeight;
        private System.Windows.Forms.TextBox txtBMI;
        private System.Windows.Forms.GroupBox grpSelect;
        private System.Windows.Forms.RadioButton rdoBattle;
        private System.Windows.Forms.RadioButton rdoFactorials;
        private System.Windows.Forms.RadioButton rdoDistance;
        private System.Windows.Forms.RadioButton rdoQuadratic;
        private System.Windows.Forms.Button btnDisplay;
    }
}