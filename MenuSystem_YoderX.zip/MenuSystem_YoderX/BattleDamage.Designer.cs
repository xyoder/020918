﻿namespace MenuSystem_YoderX
{
    partial class frmBattleDamage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExit = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.lblAnswer = new System.Windows.Forms.Label();
            this.lblMultiplier = new System.Windows.Forms.Label();
            this.lblSpeed = new System.Windows.Forms.Label();
            this.lblAttack = new System.Windows.Forms.Label();
            this.lblWeaponDamage = new System.Windows.Forms.Label();
            this.txtDamage = new System.Windows.Forms.TextBox();
            this.txtMultiplier = new System.Windows.Forms.TextBox();
            this.txtWeaponSpeed = new System.Windows.Forms.TextBox();
            this.txtAttackPower = new System.Windows.Forms.TextBox();
            this.txtWeaponDamage = new System.Windows.Forms.TextBox();
            this.grpSelect = new System.Windows.Forms.GroupBox();
            this.rdoFactorials = new System.Windows.Forms.RadioButton();
            this.rdoDistance = new System.Windows.Forms.RadioButton();
            this.rdoQuadratic = new System.Windows.Forms.RadioButton();
            this.rdoBMI = new System.Windows.Forms.RadioButton();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.grpSelect.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(345, 325);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(157, 66);
            this.btnExit.TabIndex = 25;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // btnReset
            // 
            this.btnReset.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(182, 325);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(157, 66);
            this.btnReset.TabIndex = 24;
            this.btnReset.Text = "&Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.BtnReset_Click);
            // 
            // btnCalculate
            // 
            this.btnCalculate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalculate.Location = new System.Drawing.Point(19, 325);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(157, 66);
            this.btnCalculate.TabIndex = 23;
            this.btnCalculate.Text = "&Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.BtnCalculate_Click);
            // 
            // lblAnswer
            // 
            this.lblAnswer.AutoSize = true;
            this.lblAnswer.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnswer.Location = new System.Drawing.Point(156, 266);
            this.lblAnswer.Name = "lblAnswer";
            this.lblAnswer.Size = new System.Drawing.Size(127, 36);
            this.lblAnswer.TabIndex = 22;
            this.lblAnswer.Text = "Damage:";
            // 
            // lblMultiplier
            // 
            this.lblMultiplier.AutoSize = true;
            this.lblMultiplier.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMultiplier.Location = new System.Drawing.Point(19, 202);
            this.lblMultiplier.Name = "lblMultiplier";
            this.lblMultiplier.Size = new System.Drawing.Size(264, 36);
            this.lblMultiplier.TabIndex = 21;
            this.lblMultiplier.Text = "Damage Multiplier:";
            // 
            // lblSpeed
            // 
            this.lblSpeed.AutoSize = true;
            this.lblSpeed.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSpeed.Location = new System.Drawing.Point(72, 142);
            this.lblSpeed.Name = "lblSpeed";
            this.lblSpeed.Size = new System.Drawing.Size(211, 36);
            this.lblSpeed.TabIndex = 20;
            this.lblSpeed.Text = "Weapon Speed:";
            // 
            // lblAttack
            // 
            this.lblAttack.AutoSize = true;
            this.lblAttack.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAttack.Location = new System.Drawing.Point(85, 81);
            this.lblAttack.Name = "lblAttack";
            this.lblAttack.Size = new System.Drawing.Size(198, 36);
            this.lblAttack.TabIndex = 19;
            this.lblAttack.Text = "Attack Power:";
            // 
            // lblWeaponDamage
            // 
            this.lblWeaponDamage.AutoSize = true;
            this.lblWeaponDamage.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWeaponDamage.Location = new System.Drawing.Point(47, 20);
            this.lblWeaponDamage.Name = "lblWeaponDamage";
            this.lblWeaponDamage.Size = new System.Drawing.Size(236, 36);
            this.lblWeaponDamage.TabIndex = 18;
            this.lblWeaponDamage.Text = "Weapon Damage:";
            // 
            // txtDamage
            // 
            this.txtDamage.Enabled = false;
            this.txtDamage.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDamage.Location = new System.Drawing.Point(289, 263);
            this.txtDamage.Name = "txtDamage";
            this.txtDamage.Size = new System.Drawing.Size(213, 44);
            this.txtDamage.TabIndex = 16;
            // 
            // txtMultiplier
            // 
            this.txtMultiplier.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMultiplier.Location = new System.Drawing.Point(289, 199);
            this.txtMultiplier.Name = "txtMultiplier";
            this.txtMultiplier.Size = new System.Drawing.Size(213, 44);
            this.txtMultiplier.TabIndex = 17;
            this.txtMultiplier.Text = "1";
            this.txtMultiplier.Validating += new System.ComponentModel.CancelEventHandler(this.TxtMultiplier_Validating);
            // 
            // txtWeaponSpeed
            // 
            this.txtWeaponSpeed.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWeaponSpeed.Location = new System.Drawing.Point(289, 139);
            this.txtWeaponSpeed.Name = "txtWeaponSpeed";
            this.txtWeaponSpeed.Size = new System.Drawing.Size(213, 44);
            this.txtWeaponSpeed.TabIndex = 15;
            this.txtWeaponSpeed.Text = "1";
            this.txtWeaponSpeed.Validating += new System.ComponentModel.CancelEventHandler(this.TxtWeaponSpeed_Validating);
            // 
            // txtAttackPower
            // 
            this.txtAttackPower.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAttackPower.Location = new System.Drawing.Point(289, 78);
            this.txtAttackPower.Name = "txtAttackPower";
            this.txtAttackPower.Size = new System.Drawing.Size(213, 44);
            this.txtAttackPower.TabIndex = 14;
            this.txtAttackPower.Text = "1";
            this.txtAttackPower.Validating += new System.ComponentModel.CancelEventHandler(this.TxtAttackPower_Validating);
            // 
            // txtWeaponDamage
            // 
            this.txtWeaponDamage.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWeaponDamage.Location = new System.Drawing.Point(289, 17);
            this.txtWeaponDamage.Name = "txtWeaponDamage";
            this.txtWeaponDamage.Size = new System.Drawing.Size(213, 44);
            this.txtWeaponDamage.TabIndex = 13;
            this.txtWeaponDamage.Text = "10";
            this.txtWeaponDamage.Validating += new System.ComponentModel.CancelEventHandler(this.TxtWeaponDamage_Validating);
            // 
            // grpSelect
            // 
            this.grpSelect.Controls.Add(this.rdoFactorials);
            this.grpSelect.Controls.Add(this.rdoDistance);
            this.grpSelect.Controls.Add(this.rdoQuadratic);
            this.grpSelect.Controls.Add(this.rdoBMI);
            this.grpSelect.Location = new System.Drawing.Point(19, 439);
            this.grpSelect.Name = "grpSelect";
            this.grpSelect.Size = new System.Drawing.Size(483, 175);
            this.grpSelect.TabIndex = 26;
            this.grpSelect.TabStop = false;
            this.grpSelect.Text = "Select a Different Type of Calculator";
            // 
            // rdoFactorials
            // 
            this.rdoFactorials.AutoSize = true;
            this.rdoFactorials.Location = new System.Drawing.Point(6, 100);
            this.rdoFactorials.Name = "rdoFactorials";
            this.rdoFactorials.Size = new System.Drawing.Size(217, 29);
            this.rdoFactorials.TabIndex = 3;
            this.rdoFactorials.TabStop = true;
            this.rdoFactorials.Text = "Factorial Calclator";
            this.rdoFactorials.UseVisualStyleBackColor = true;
            // 
            // rdoDistance
            // 
            this.rdoDistance.AutoSize = true;
            this.rdoDistance.Location = new System.Drawing.Point(6, 65);
            this.rdoDistance.Name = "rdoDistance";
            this.rdoDistance.Size = new System.Drawing.Size(230, 29);
            this.rdoDistance.TabIndex = 2;
            this.rdoDistance.TabStop = true;
            this.rdoDistance.Text = "Distance Calculator";
            this.rdoDistance.UseVisualStyleBackColor = true;
            // 
            // rdoQuadratic
            // 
            this.rdoQuadratic.AutoSize = true;
            this.rdoQuadratic.Location = new System.Drawing.Point(6, 135);
            this.rdoQuadratic.Name = "rdoQuadratic";
            this.rdoQuadratic.Size = new System.Drawing.Size(323, 29);
            this.rdoQuadratic.TabIndex = 1;
            this.rdoQuadratic.TabStop = true;
            this.rdoQuadratic.Text = "Quadratic Formula Calculator";
            this.rdoQuadratic.UseVisualStyleBackColor = true;
            // 
            // rdoBMI
            // 
            this.rdoBMI.AutoSize = true;
            this.rdoBMI.Location = new System.Drawing.Point(6, 30);
            this.rdoBMI.Name = "rdoBMI";
            this.rdoBMI.Size = new System.Drawing.Size(183, 29);
            this.rdoBMI.TabIndex = 0;
            this.rdoBMI.TabStop = true;
            this.rdoBMI.Text = "BMI Calculator";
            this.rdoBMI.UseVisualStyleBackColor = true;
            // 
            // btnDisplay
            // 
            this.btnDisplay.Location = new System.Drawing.Point(53, 620);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(410, 80);
            this.btnDisplay.TabIndex = 27;
            this.btnDisplay.Text = "Display New Calculator";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.BtnDisplay_Click);
            // 
            // frmBattleDamage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LemonChiffon;
            this.ClientSize = new System.Drawing.Size(536, 708);
            this.Controls.Add(this.btnDisplay);
            this.Controls.Add(this.grpSelect);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.lblAnswer);
            this.Controls.Add(this.lblMultiplier);
            this.Controls.Add(this.lblSpeed);
            this.Controls.Add(this.lblAttack);
            this.Controls.Add(this.lblWeaponDamage);
            this.Controls.Add(this.txtDamage);
            this.Controls.Add(this.txtMultiplier);
            this.Controls.Add(this.txtWeaponSpeed);
            this.Controls.Add(this.txtAttackPower);
            this.Controls.Add(this.txtWeaponDamage);
            this.Name = "frmBattleDamage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Battle Damage Calculator";
            this.grpSelect.ResumeLayout(false);
            this.grpSelect.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Label lblAnswer;
        private System.Windows.Forms.Label lblMultiplier;
        private System.Windows.Forms.Label lblSpeed;
        private System.Windows.Forms.Label lblAttack;
        private System.Windows.Forms.Label lblWeaponDamage;
        private System.Windows.Forms.TextBox txtDamage;
        private System.Windows.Forms.TextBox txtMultiplier;
        private System.Windows.Forms.TextBox txtWeaponSpeed;
        private System.Windows.Forms.TextBox txtAttackPower;
        private System.Windows.Forms.TextBox txtWeaponDamage;
        private System.Windows.Forms.GroupBox grpSelect;
        private System.Windows.Forms.RadioButton rdoFactorials;
        private System.Windows.Forms.RadioButton rdoDistance;
        private System.Windows.Forms.RadioButton rdoQuadratic;
        private System.Windows.Forms.RadioButton rdoBMI;
        private System.Windows.Forms.Button btnDisplay;
    }
}