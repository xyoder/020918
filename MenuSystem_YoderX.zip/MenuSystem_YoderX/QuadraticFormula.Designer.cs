﻿namespace MenuSystem_YoderX
{
    partial class frmQuadratic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSolve = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.grpSolutions = new System.Windows.Forms.GroupBox();
            this.txtSolutionX2 = new System.Windows.Forms.Label();
            this.txtSolutionX1 = new System.Windows.Forms.Label();
            this.lblX2 = new System.Windows.Forms.Label();
            this.lblX1 = new System.Windows.Forms.Label();
            this.grpEqTerms = new System.Windows.Forms.GroupBox();
            this.txtTermC = new System.Windows.Forms.TextBox();
            this.lblTermC = new System.Windows.Forms.Label();
            this.txtTermB = new System.Windows.Forms.TextBox();
            this.lblTermB = new System.Windows.Forms.Label();
            this.txtTermA = new System.Windows.Forms.TextBox();
            this.lblTermA = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.grpSelect = new System.Windows.Forms.GroupBox();
            this.rdoBattle = new System.Windows.Forms.RadioButton();
            this.rdoFactorials = new System.Windows.Forms.RadioButton();
            this.rdoDistance = new System.Windows.Forms.RadioButton();
            this.rdoBMI = new System.Windows.Forms.RadioButton();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.grpSolutions.SuspendLayout();
            this.grpEqTerms.SuspendLayout();
            this.grpSelect.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSolve
            // 
            this.btnSolve.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSolve.Location = new System.Drawing.Point(13, 336);
            this.btnSolve.Margin = new System.Windows.Forms.Padding(6);
            this.btnSolve.Name = "btnSolve";
            this.btnSolve.Size = new System.Drawing.Size(362, 75);
            this.btnSolve.TabIndex = 11;
            this.btnSolve.Text = "Solve";
            this.btnSolve.UseVisualStyleBackColor = true;
            this.btnSolve.Click += new System.EventHandler(this.BtnSolve_Click);
            // 
            // btnReset
            // 
            this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(771, 336);
            this.btnReset.Margin = new System.Windows.Forms.Padding(6);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(372, 75);
            this.btnReset.TabIndex = 13;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.BtnReset_Click);
            // 
            // grpSolutions
            // 
            this.grpSolutions.BackColor = System.Drawing.Color.AntiqueWhite;
            this.grpSolutions.Controls.Add(this.txtSolutionX2);
            this.grpSolutions.Controls.Add(this.txtSolutionX1);
            this.grpSolutions.Controls.Add(this.lblX2);
            this.grpSolutions.Controls.Add(this.lblX1);
            this.grpSolutions.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpSolutions.Location = new System.Drawing.Point(497, 15);
            this.grpSolutions.Margin = new System.Windows.Forms.Padding(6);
            this.grpSolutions.Name = "grpSolutions";
            this.grpSolutions.Padding = new System.Windows.Forms.Padding(6);
            this.grpSolutions.Size = new System.Drawing.Size(646, 310);
            this.grpSolutions.TabIndex = 9;
            this.grpSolutions.TabStop = false;
            this.grpSolutions.Text = "Solutions";
            // 
            // txtSolutionX2
            // 
            this.txtSolutionX2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtSolutionX2.Location = new System.Drawing.Point(102, 167);
            this.txtSolutionX2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.txtSolutionX2.Name = "txtSolutionX2";
            this.txtSolutionX2.Size = new System.Drawing.Size(514, 52);
            this.txtSolutionX2.TabIndex = 8;
            this.txtSolutionX2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtSolutionX1
            // 
            this.txtSolutionX1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtSolutionX1.Location = new System.Drawing.Point(102, 104);
            this.txtSolutionX1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.txtSolutionX1.Name = "txtSolutionX1";
            this.txtSolutionX1.Size = new System.Drawing.Size(514, 52);
            this.txtSolutionX1.TabIndex = 7;
            this.txtSolutionX1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblX2
            // 
            this.lblX2.AutoSize = true;
            this.lblX2.Location = new System.Drawing.Point(26, 173);
            this.lblX2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblX2.Name = "lblX2";
            this.lblX2.Size = new System.Drawing.Size(65, 37);
            this.lblX2.TabIndex = 4;
            this.lblX2.Text = "X2:";
            // 
            // lblX1
            // 
            this.lblX1.AutoSize = true;
            this.lblX1.Location = new System.Drawing.Point(26, 110);
            this.lblX1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblX1.Name = "lblX1";
            this.lblX1.Size = new System.Drawing.Size(63, 37);
            this.lblX1.TabIndex = 2;
            this.lblX1.Text = "X1:";
            // 
            // grpEqTerms
            // 
            this.grpEqTerms.BackColor = System.Drawing.Color.AntiqueWhite;
            this.grpEqTerms.Controls.Add(this.txtTermC);
            this.grpEqTerms.Controls.Add(this.lblTermC);
            this.grpEqTerms.Controls.Add(this.txtTermB);
            this.grpEqTerms.Controls.Add(this.lblTermB);
            this.grpEqTerms.Controls.Add(this.txtTermA);
            this.grpEqTerms.Controls.Add(this.lblTermA);
            this.grpEqTerms.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpEqTerms.Location = new System.Drawing.Point(13, 15);
            this.grpEqTerms.Margin = new System.Windows.Forms.Padding(6);
            this.grpEqTerms.Name = "grpEqTerms";
            this.grpEqTerms.Padding = new System.Windows.Forms.Padding(6);
            this.grpEqTerms.Size = new System.Drawing.Size(454, 310);
            this.grpEqTerms.TabIndex = 8;
            this.grpEqTerms.TabStop = false;
            this.grpEqTerms.Text = "Equation Terms";
            // 
            // txtTermC
            // 
            this.txtTermC.Location = new System.Drawing.Point(202, 208);
            this.txtTermC.Margin = new System.Windows.Forms.Padding(6);
            this.txtTermC.Name = "txtTermC";
            this.txtTermC.Size = new System.Drawing.Size(198, 44);
            this.txtTermC.TabIndex = 3;
            this.txtTermC.Text = "0";
            this.txtTermC.Validating += new System.ComponentModel.CancelEventHandler(this.TxtTermC_Validating);
            // 
            // lblTermC
            // 
            this.lblTermC.AutoSize = true;
            this.lblTermC.Location = new System.Drawing.Point(44, 213);
            this.lblTermC.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblTermC.Name = "lblTermC";
            this.lblTermC.Size = new System.Drawing.Size(142, 37);
            this.lblTermC.TabIndex = 4;
            this.lblTermC.Text = "Term C: ";
            // 
            // txtTermB
            // 
            this.txtTermB.Location = new System.Drawing.Point(202, 144);
            this.txtTermB.Margin = new System.Windows.Forms.Padding(6);
            this.txtTermB.Name = "txtTermB";
            this.txtTermB.Size = new System.Drawing.Size(198, 44);
            this.txtTermB.TabIndex = 1;
            this.txtTermB.Text = "0";
            this.txtTermB.Validating += new System.ComponentModel.CancelEventHandler(this.TxtTermB_Validating);
            // 
            // lblTermB
            // 
            this.lblTermB.AutoSize = true;
            this.lblTermB.Location = new System.Drawing.Point(44, 150);
            this.lblTermB.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblTermB.Name = "lblTermB";
            this.lblTermB.Size = new System.Drawing.Size(140, 37);
            this.lblTermB.TabIndex = 2;
            this.lblTermB.Text = "Term B: ";
            // 
            // txtTermA
            // 
            this.txtTermA.Location = new System.Drawing.Point(202, 81);
            this.txtTermA.Margin = new System.Windows.Forms.Padding(6);
            this.txtTermA.Name = "txtTermA";
            this.txtTermA.Size = new System.Drawing.Size(198, 44);
            this.txtTermA.TabIndex = 0;
            this.txtTermA.Text = "0";
            this.txtTermA.Validating += new System.ComponentModel.CancelEventHandler(this.TxtTermA_Validating);
            // 
            // lblTermA
            // 
            this.lblTermA.AutoSize = true;
            this.lblTermA.Location = new System.Drawing.Point(44, 87);
            this.lblTermA.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblTermA.Name = "lblTermA";
            this.lblTermA.Size = new System.Drawing.Size(141, 37);
            this.lblTermA.TabIndex = 0;
            this.lblTermA.Text = "Term A: ";
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(387, 337);
            this.btnExit.Margin = new System.Windows.Forms.Padding(6);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(372, 75);
            this.btnExit.TabIndex = 12;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // grpSelect
            // 
            this.grpSelect.Controls.Add(this.rdoBattle);
            this.grpSelect.Controls.Add(this.rdoFactorials);
            this.grpSelect.Controls.Add(this.rdoDistance);
            this.grpSelect.Controls.Add(this.rdoBMI);
            this.grpSelect.Location = new System.Drawing.Point(13, 421);
            this.grpSelect.Name = "grpSelect";
            this.grpSelect.Size = new System.Drawing.Size(575, 101);
            this.grpSelect.TabIndex = 14;
            this.grpSelect.TabStop = false;
            this.grpSelect.Text = "Select a Different Type of Calculator";
            // 
            // rdoBattle
            // 
            this.rdoBattle.AutoSize = true;
            this.rdoBattle.Location = new System.Drawing.Point(242, 65);
            this.rdoBattle.Name = "rdoBattle";
            this.rdoBattle.Size = new System.Drawing.Size(287, 29);
            this.rdoBattle.TabIndex = 4;
            this.rdoBattle.TabStop = true;
            this.rdoBattle.Text = "Battle Damage Calculator";
            this.rdoBattle.UseVisualStyleBackColor = true;
            // 
            // rdoFactorials
            // 
            this.rdoFactorials.AutoSize = true;
            this.rdoFactorials.Location = new System.Drawing.Point(242, 30);
            this.rdoFactorials.Name = "rdoFactorials";
            this.rdoFactorials.Size = new System.Drawing.Size(217, 29);
            this.rdoFactorials.TabIndex = 3;
            this.rdoFactorials.TabStop = true;
            this.rdoFactorials.Text = "Factorial Calclator";
            this.rdoFactorials.UseVisualStyleBackColor = true;
            // 
            // rdoDistance
            // 
            this.rdoDistance.AutoSize = true;
            this.rdoDistance.Location = new System.Drawing.Point(6, 65);
            this.rdoDistance.Name = "rdoDistance";
            this.rdoDistance.Size = new System.Drawing.Size(230, 29);
            this.rdoDistance.TabIndex = 2;
            this.rdoDistance.TabStop = true;
            this.rdoDistance.Text = "Distance Calculator";
            this.rdoDistance.UseVisualStyleBackColor = true;
            // 
            // rdoBMI
            // 
            this.rdoBMI.AutoSize = true;
            this.rdoBMI.Location = new System.Drawing.Point(6, 30);
            this.rdoBMI.Name = "rdoBMI";
            this.rdoBMI.Size = new System.Drawing.Size(183, 29);
            this.rdoBMI.TabIndex = 0;
            this.rdoBMI.TabStop = true;
            this.rdoBMI.Text = "BMI Calculator";
            this.rdoBMI.UseVisualStyleBackColor = true;
            // 
            // btnDisplay
            // 
            this.btnDisplay.Location = new System.Drawing.Point(594, 442);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(410, 80);
            this.btnDisplay.TabIndex = 15;
            this.btnDisplay.Text = "Display New Calculator";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.BtnDisplay_Click);
            // 
            // frmQuadratic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Moccasin;
            this.ClientSize = new System.Drawing.Size(1164, 533);
            this.Controls.Add(this.btnDisplay);
            this.Controls.Add(this.grpSelect);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSolve);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.grpSolutions);
            this.Controls.Add(this.grpEqTerms);
            this.Name = "frmQuadratic";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quadratic Formula";
            this.grpSolutions.ResumeLayout(false);
            this.grpSolutions.PerformLayout();
            this.grpEqTerms.ResumeLayout(false);
            this.grpEqTerms.PerformLayout();
            this.grpSelect.ResumeLayout(false);
            this.grpSelect.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSolve;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.GroupBox grpSolutions;
        private System.Windows.Forms.Label txtSolutionX2;
        private System.Windows.Forms.Label txtSolutionX1;
        private System.Windows.Forms.Label lblX2;
        private System.Windows.Forms.Label lblX1;
        private System.Windows.Forms.GroupBox grpEqTerms;
        private System.Windows.Forms.TextBox txtTermC;
        private System.Windows.Forms.Label lblTermC;
        private System.Windows.Forms.TextBox txtTermB;
        private System.Windows.Forms.Label lblTermB;
        private System.Windows.Forms.TextBox txtTermA;
        private System.Windows.Forms.Label lblTermA;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.GroupBox grpSelect;
        private System.Windows.Forms.RadioButton rdoBattle;
        private System.Windows.Forms.RadioButton rdoFactorials;
        private System.Windows.Forms.RadioButton rdoDistance;
        private System.Windows.Forms.RadioButton rdoBMI;
        private System.Windows.Forms.Button btnDisplay;
    }
}