﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MenuSystem_YoderX
{
    //Name: Xavier Yoder
    //Purpose: to give the user the two answers for a quadratic equation based on the terms given
    //Date: Novermber, 7 2019
    public partial class frmQuadratic : Form
    {

        //declare global variable
        double termA, termB, termC;

        public frmQuadratic()
        {
            InitializeComponent();
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            //close the form
            this.Close();
        }

        //Create a number validation method
        private double ValidateTerms(TextBox txt2check)
        {
            //create a return variable
            double number2Return;
            try
            {
                number2Return = Convert.ToDouble(txt2check.Text);
            }
            catch
            {
                MessageBox.Show("Input for weapon damage must be a number.");
                txt2check.Text = "0";
                txt2check.Focus();
            }

            //convert the number in the textbox to a variable ready to transfer to term value variables
            number2Return = Convert.ToDouble(txt2check.Text);

            //return value for specified term
            return number2Return;
        }

        private void TxtTermB_Validating(object sender, CancelEventArgs e)
        {
            //use method created for term b
            termB = ValidateTerms(txtTermB);
        }

        private void TxtTermC_Validating(object sender, CancelEventArgs e)
        {
            //use method created for term c
            termC = ValidateTerms(txtTermC);
        }

        private void BtnSolve_Click(object sender, EventArgs e)
        {
            //solve the equation
            double solutionA, solutionB, discriminate, thingBeforeDiscrminateIfIIsInAnswers;

            discriminate = Math.Pow(termB, 2) - (4 * termA * termC);

            //determine if solutions will have i or not and solve
            if (discriminate < 0)
            {
                thingBeforeDiscrminateIfIIsInAnswers = -termB / (termA * 2);

                txtSolutionX1.Text = $"{thingBeforeDiscrminateIfIIsInAnswers} + {Math.Sqrt(Math.Abs(discriminate)) / (2 * termA)}i";
                txtSolutionX2.Text = $"{thingBeforeDiscrminateIfIIsInAnswers} - {Math.Sqrt(Math.Abs(discriminate)) / (2 * termA)}i";
            }
            else
            {
                solutionA = (-termB / (termA * 2)) + Math.Sqrt(discriminate) / 2 * termA;
                solutionB = (-termB / (termA * 2)) - Math.Sqrt(discriminate) / 2 * termA;
                txtSolutionX1.Text = $"{solutionA}";
                txtSolutionX2.Text = $"{solutionB}";
            }
        }

        //make a method that will open a form based on which radio button is clicked
        public void DisplayNewForm()
        {

            //Determine which radio button is checked and open the form correlated with it
            if (rdoBattle.Checked)
            {
                frmBattleDamage newForm = new frmBattleDamage();
                newForm.Show();
            }
            else if (rdoFactorials.Checked)
            {
                frmFactorial newForm = new frmFactorial();
                newForm.Show();
            }
            else if (rdoBMI.Checked)
            {
                frmBMI newForm = new frmBMI();
                newForm.Show();
            }
            else if (rdoDistance.Checked)
            {
                frmDistance newForm = new frmDistance();
                newForm.Show();
            }
        }

        private void BtnDisplay_Click(object sender, EventArgs e)
        {
            //display a new form from this form
            DisplayNewForm();
            this.Close();
        }

        private void BtnReset_Click(object sender, EventArgs e)
        {
            //reset the form
            txtSolutionX1.Text = txtSolutionX2.Text = null;
            txtTermA.Text = txtTermB.Text = txtTermC.Text = "0";
        }

        private void TxtTermA_Validating(object sender, CancelEventArgs e)
        {
            //use method created for term a
            termA = ValidateTerms(txtTermA);
        }
    }
}
