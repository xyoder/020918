﻿namespace MenuSystem_YoderX
{
    partial class frmDistance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpSelect = new System.Windows.Forms.GroupBox();
            this.rdoBattle = new System.Windows.Forms.RadioButton();
            this.rdoFactorials = new System.Windows.Forms.RadioButton();
            this.rdoQuadratic = new System.Windows.Forms.RadioButton();
            this.rdoBMI = new System.Windows.Forms.RadioButton();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.lblX1 = new System.Windows.Forms.Label();
            this.lblY1 = new System.Windows.Forms.Label();
            this.lblX2 = new System.Windows.Forms.Label();
            this.lblY2 = new System.Windows.Forms.Label();
            this.txtX1 = new System.Windows.Forms.TextBox();
            this.txtY1 = new System.Windows.Forms.TextBox();
            this.txtX2 = new System.Windows.Forms.TextBox();
            this.txtY2 = new System.Windows.Forms.TextBox();
            this.lblDistance = new System.Windows.Forms.Label();
            this.txtAnswer = new System.Windows.Forms.TextBox();
            this.btnCompute = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.grpSelect.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpSelect
            // 
            this.grpSelect.Controls.Add(this.rdoBattle);
            this.grpSelect.Controls.Add(this.rdoFactorials);
            this.grpSelect.Controls.Add(this.rdoQuadratic);
            this.grpSelect.Controls.Add(this.rdoBMI);
            this.grpSelect.Location = new System.Drawing.Point(16, 264);
            this.grpSelect.Name = "grpSelect";
            this.grpSelect.Size = new System.Drawing.Size(374, 219);
            this.grpSelect.TabIndex = 20;
            this.grpSelect.TabStop = false;
            this.grpSelect.Text = "Select a Different Type of Calculator";
            // 
            // rdoBattle
            // 
            this.rdoBattle.AutoSize = true;
            this.rdoBattle.Location = new System.Drawing.Point(6, 174);
            this.rdoBattle.Name = "rdoBattle";
            this.rdoBattle.Size = new System.Drawing.Size(287, 29);
            this.rdoBattle.TabIndex = 4;
            this.rdoBattle.TabStop = true;
            this.rdoBattle.Text = "Battle Damage Calculator";
            this.rdoBattle.UseVisualStyleBackColor = true;
            // 
            // rdoFactorials
            // 
            this.rdoFactorials.AutoSize = true;
            this.rdoFactorials.Location = new System.Drawing.Point(6, 104);
            this.rdoFactorials.Name = "rdoFactorials";
            this.rdoFactorials.Size = new System.Drawing.Size(217, 29);
            this.rdoFactorials.TabIndex = 3;
            this.rdoFactorials.TabStop = true;
            this.rdoFactorials.Text = "Factorial Calclator";
            this.rdoFactorials.UseVisualStyleBackColor = true;
            // 
            // rdoQuadratic
            // 
            this.rdoQuadratic.AutoSize = true;
            this.rdoQuadratic.Location = new System.Drawing.Point(6, 139);
            this.rdoQuadratic.Name = "rdoQuadratic";
            this.rdoQuadratic.Size = new System.Drawing.Size(323, 29);
            this.rdoQuadratic.TabIndex = 1;
            this.rdoQuadratic.TabStop = true;
            this.rdoQuadratic.Text = "Quadratic Formula Calculator";
            this.rdoQuadratic.UseVisualStyleBackColor = true;
            // 
            // rdoBMI
            // 
            this.rdoBMI.AutoSize = true;
            this.rdoBMI.Location = new System.Drawing.Point(6, 69);
            this.rdoBMI.Name = "rdoBMI";
            this.rdoBMI.Size = new System.Drawing.Size(183, 29);
            this.rdoBMI.TabIndex = 0;
            this.rdoBMI.TabStop = true;
            this.rdoBMI.Text = "BMI Calculator";
            this.rdoBMI.UseVisualStyleBackColor = true;
            // 
            // btnDisplay
            // 
            this.btnDisplay.Location = new System.Drawing.Point(16, 489);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(374, 80);
            this.btnDisplay.TabIndex = 12;
            this.btnDisplay.Text = "Display New Calculator";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.BtnDisplay_Click);
            // 
            // lblX1
            // 
            this.lblX1.AutoSize = true;
            this.lblX1.Location = new System.Drawing.Point(69, 17);
            this.lblX1.Name = "lblX1";
            this.lblX1.Size = new System.Drawing.Size(44, 25);
            this.lblX1.TabIndex = 13;
            this.lblX1.Text = "X1:";
            // 
            // lblY1
            // 
            this.lblY1.AutoSize = true;
            this.lblY1.Location = new System.Drawing.Point(69, 56);
            this.lblY1.Name = "lblY1";
            this.lblY1.Size = new System.Drawing.Size(45, 25);
            this.lblY1.TabIndex = 14;
            this.lblY1.Text = "Y1:";
            // 
            // lblX2
            // 
            this.lblX2.AutoSize = true;
            this.lblX2.Location = new System.Drawing.Point(69, 95);
            this.lblX2.Name = "lblX2";
            this.lblX2.Size = new System.Drawing.Size(44, 25);
            this.lblX2.TabIndex = 15;
            this.lblX2.Text = "X2:";
            // 
            // lblY2
            // 
            this.lblY2.AutoSize = true;
            this.lblY2.Location = new System.Drawing.Point(68, 134);
            this.lblY2.Name = "lblY2";
            this.lblY2.Size = new System.Drawing.Size(45, 25);
            this.lblY2.TabIndex = 16;
            this.lblY2.Text = "Y2:";
            // 
            // txtX1
            // 
            this.txtX1.Location = new System.Drawing.Point(119, 14);
            this.txtX1.Name = "txtX1";
            this.txtX1.Size = new System.Drawing.Size(236, 31);
            this.txtX1.TabIndex = 0;
            this.txtX1.Text = "0";
            this.txtX1.Validating += new System.ComponentModel.CancelEventHandler(this.TxtX1_Validating);
            // 
            // txtY1
            // 
            this.txtY1.Location = new System.Drawing.Point(119, 53);
            this.txtY1.Name = "txtY1";
            this.txtY1.Size = new System.Drawing.Size(236, 31);
            this.txtY1.TabIndex = 1;
            this.txtY1.Text = "0";
            this.txtY1.Validating += new System.ComponentModel.CancelEventHandler(this.TxtY1_Validating);
            // 
            // txtX2
            // 
            this.txtX2.Location = new System.Drawing.Point(119, 92);
            this.txtX2.Name = "txtX2";
            this.txtX2.Size = new System.Drawing.Size(236, 31);
            this.txtX2.TabIndex = 2;
            this.txtX2.Text = "0";
            this.txtX2.Validating += new System.ComponentModel.CancelEventHandler(this.TxtX2_Validating);
            // 
            // txtY2
            // 
            this.txtY2.Location = new System.Drawing.Point(119, 131);
            this.txtY2.Name = "txtY2";
            this.txtY2.Size = new System.Drawing.Size(236, 31);
            this.txtY2.TabIndex = 3;
            this.txtY2.Text = "0";
            this.txtY2.Validating += new System.ComponentModel.CancelEventHandler(this.TxtY2_Validating);
            // 
            // lblDistance
            // 
            this.lblDistance.AutoSize = true;
            this.lblDistance.Location = new System.Drawing.Point(11, 173);
            this.lblDistance.Name = "lblDistance";
            this.lblDistance.Size = new System.Drawing.Size(102, 25);
            this.lblDistance.TabIndex = 17;
            this.lblDistance.Text = "Distance:";
            // 
            // txtAnswer
            // 
            this.txtAnswer.Enabled = false;
            this.txtAnswer.Location = new System.Drawing.Point(119, 170);
            this.txtAnswer.Name = "txtAnswer";
            this.txtAnswer.Size = new System.Drawing.Size(236, 31);
            this.txtAnswer.TabIndex = 18;
            // 
            // btnCompute
            // 
            this.btnCompute.Location = new System.Drawing.Point(16, 214);
            this.btnCompute.Name = "btnCompute";
            this.btnCompute.Size = new System.Drawing.Size(120, 44);
            this.btnCompute.TabIndex = 19;
            this.btnCompute.Text = "Compute";
            this.btnCompute.UseVisualStyleBackColor = true;
            this.btnCompute.Click += new System.EventHandler(this.BtnCompute_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(142, 214);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(120, 44);
            this.btnReset.TabIndex = 20;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.BtnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(270, 214);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(120, 44);
            this.btnExit.TabIndex = 21;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // frmDistance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.ClientSize = new System.Drawing.Size(401, 585);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnCompute);
            this.Controls.Add(this.txtAnswer);
            this.Controls.Add(this.lblDistance);
            this.Controls.Add(this.txtY2);
            this.Controls.Add(this.txtX2);
            this.Controls.Add(this.txtY1);
            this.Controls.Add(this.txtX1);
            this.Controls.Add(this.lblY2);
            this.Controls.Add(this.lblX2);
            this.Controls.Add(this.lblY1);
            this.Controls.Add(this.lblX1);
            this.Controls.Add(this.btnDisplay);
            this.Controls.Add(this.grpSelect);
            this.Name = "frmDistance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Distance Formula";
            this.grpSelect.ResumeLayout(false);
            this.grpSelect.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpSelect;
        private System.Windows.Forms.RadioButton rdoBattle;
        private System.Windows.Forms.RadioButton rdoFactorials;
        private System.Windows.Forms.RadioButton rdoQuadratic;
        private System.Windows.Forms.RadioButton rdoBMI;
        private System.Windows.Forms.Button btnDisplay;
        private System.Windows.Forms.Label lblX1;
        private System.Windows.Forms.Label lblY1;
        private System.Windows.Forms.Label lblX2;
        private System.Windows.Forms.Label lblY2;
        private System.Windows.Forms.TextBox txtX1;
        private System.Windows.Forms.TextBox txtY1;
        private System.Windows.Forms.TextBox txtX2;
        private System.Windows.Forms.TextBox txtY2;
        private System.Windows.Forms.Label lblDistance;
        private System.Windows.Forms.TextBox txtAnswer;
        private System.Windows.Forms.Button btnCompute;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
    }
}